import numpy as np
import matplotlib.pyplot as plt

def Test_Funct(Funct): 

    # Variables
    P_partial = 3
    P_units_poss = ['Torr','atm','Bar','Pa']
    test_val_poss = ['a','b','c']

    # Create Some Space
    print('\n\n')

    for p in test_val_poss:
        test_val = p
        for i in P_units_poss:
            P_units = i
            # Testing Scalar, Vector, and Range W/ Graph
            if test_val == 'a':
                print(f"SCALAR TEST in {i}")
                T = 300
                P_tot = 10
                X_i = P_partial / P_tot
                result = Funct(T, P_tot, X_i, P_units)
                print(f'in {P_units} the scalar value of this function is:',result)
                print('\n\n')
            elif test_val == 'b':
                print(f"VECTOR TEST in {i}")
                T = np.array([100, 220, 332, 450])
                P_tot = np.array([10, 15, 20, 8])
                X_i = P_partial / P_tot
                result = Funct(T, P_tot, X_i, P_units)
                print(f'in {P_units} the vector value of this function is:\n',result)
                print('\n\n')
            else:
                T = np.linspace(1,1000,num=100)
                P_tot = np.linspace(1,100,num=100)
                X_i = P_partial / P_tot
                result = Funct(T, P_tot, X_i, P_units)
                plt.plot(T,result)
                plt.title(f"PLOT TEST in {i}")
                plt.show()

    print(f'TESTING DONE for {Funct}')