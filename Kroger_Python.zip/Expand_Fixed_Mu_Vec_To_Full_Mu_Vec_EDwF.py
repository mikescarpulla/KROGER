import numpy as np

def Expand_Fixed_Mu_Vec_To_Full_Mu_Vec(EF_fixed_mu_vec_dummy, Tloop_conditions):
    """
    Takes in a reduced EF_fixed_mu_vec and reconstructs the full EF_mu vector
    with chemical potentials for all elements, inserting the fixed mu values
    into the correct positions in the full vector.
    """

    # Strip off EF from the front, leaving only fixed mu values
    fixed_mu_vec = EF_fixed_mu_vec_dummy[1:]

    # Start with all mu values as currently stored in Tloop_conditions['muT_equilibrium']
    full_mu_vec = np.copy(Tloop_conditions['muT_equilibrium'])

    # Overwrite the entries corresponding to fixed elements
    for counter, i18 in enumerate(Tloop_conditions['indices_of_fixed_elements']):
        full_mu_vec[i18] = fixed_mu_vec[counter]  # insert fixed mu into correct position

    # Prepend EF back onto the full vector
    EF_full_mu_vec_out = np.concatenate(([EF_fixed_mu_vec_dummy[0]], full_mu_vec))

    return EF_full_mu_vec_out
