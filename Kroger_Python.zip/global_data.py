# global_data.py
# This script houses all the global data structures that will be built up and updated throughout the calculation.
# It works much the same as a workspace in MATLAB.

# Holds information about the conditions in which the calculation takes place
conditions = {}

# Holds information about the defect for which the calculation takes place
defects = {}

# Equilibrium dark solution dictionary
equilib_dark_sol = {}

# Full quench dark solution dictionary
fullquench_dark_sol = {}

# Optional: reset function to clear everything if needed
def reset():
    global conditions, defects, equilib_dark_sol, fullquench_dark_sol
    conditions = {}
    defects = {}
    equilib_dark_sol = {}
    fullquench_dark_sol = {}
