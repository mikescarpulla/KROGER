import numpy as np

def G0_TiO2_gv(T, P_tot, X_i, P_units):
    """
    This function gives the standard Gibbs energy G0 of a substance as a function of T, P_tot, and mole fraction.
    T and P_tot can be vectors; the output will be a 2D array.
    G0 is computed in kJ/mol and converted to eV/formula unit at the end.
    T in K, P in atm, Torr etc (must put in string argument 'atm' or 'Torr' etc)
    Logical masks are used like step functions vs T, allowing the whole expression to be built up piecewise over the list of T values  
    For a gas/vapor or mechanical mixture of phases such as ideal solution, mu(T,Ptot,Xi) = {Go(T,Pref) from Showmate equation} + kBT[ln(Ptot/Pref) + ln(X_i)]
        the total Gibbs energy of a mixture is Gmixture = Sum(Xi*mu_i) . Note how you end up with the xlnx terms this way, giving the ideal entropy of mixing
    
    Handy preformated Showmate templates
    Go = mask1.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    Go = Go + mask2.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    Go = Go + mask3.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    Go = Go + mask4.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    """

    # Define constants
    q = 1.602176634e-19  # Charge of an electron in Coulombs
    avo = 6.0221409e+23  # Avogadro's number
    kB_eV = 8.617333262e-5  # Boltzmann constant in eV/K

    # Select the reference pressure (P_ref) for specified units of pressure
    if P_units == 'atm':
        P_ref = 1
    elif P_units == 'Torr':
        P_ref = 760
    elif P_units == 'Bar':
        P_ref = 1
    elif P_units == 'Pa':
        P_ref = 1e5
    else:
        raise ValueError("Units of pressure must be 'atm', 'Torr', 'Pa', or 'Bar'.")

    # Ensure T and P_tot are column and row vectors, respectively
    T = np.array(T).reshape(-1, 1)  # Convert T to a column vector
    P_tot = np.array(P_tot).reshape(1, -1)  # Convert P_tot to a row vector

    # Create 2D arrays of T and P_tot for vectorized calculations
    T_matrix = T * np.ones_like(P_tot)
    P_tot_matrix = np.ones_like(T) * P_tot

    # Initialize G0 matrix
    G0_TiO2_gv = np.zeros_like(T_matrix)

    # Define masks for temperature ranges
    mask1 = (T_matrix > 298) & (T_matrix <= 1300)  # gas/vapor
    mask2 = (T_matrix > 1300) & (T_matrix <= 3600)  # gas/vapor

    # gas/vapor
    G0_TiO2_gv = mask1 * (
        -302512.406
        + 183.574648 * T_matrix
        - 388.960000 * T_matrix**0.5
        - 3880.00000 * np.log(T_matrix)
        - 62.6100000 * T_matrix * np.log(T_matrix)
    )
    G0_TiO2_gv += mask2 * (
        -325434.394
        + 121.687350 * T_matrix
        - 3.792000000e-04 * T_matrix**2
        - 55.9400000 * T_matrix * np.log(T_matrix)
    )

    # Convert units to eV per TiO2
    G0_TiO2_gv = G0_TiO2_gv / (avo * q)  # eV/TiO2 molecule

    # Account for P_tot and X_i
    G0_TiO2_gv = G0_TiO2_gv + kB_eV * T_matrix * (np.log(P_tot_matrix / P_ref) + np.log(X_i))

    # Set any zero values caused by masking to infinity for obvious errors
    G0_TiO2_gv[G0_TiO2_gv == 0] = np.inf

    return G0_TiO2_gv

'''
%% for reference, it's nice to copy the original data here in comments to allow proofreading.  For exaple this is the text file from FactSage for H2O.  
% % % 
% % % View Data  TiO2     Units:  T(K) P(atm) Energy(J) Quantity(mol) 
% % % Name: Titanium dioxide
% % % 
% % %   G(T) J/mol - 1 atm  
% % % 
% % %              G(T)                     G(T)                     G(T)                     T(K)        
% % % ____________ ________________________ ________________________ ________________________ ___________ 
% % % 
% % % S1         1 - 976986.650             + 484.740378     T       + 1683920.51     T^-1    298 - 2130  
% % % S1         1 - 67156778.7     T^-2    - 77.8376214     T ln(T)                          298 - 2130  
% % % S1         2 - 1023541.86             + 679.999417     T       - 100.416000     T ln(T) 2130 - 3000 
% % % S2         3 - 961316.130             + 462.559573     T       + 881359.600     T^-1    298 - 2100  
% % % S2         3 - 75.0358560     T ln(T)                                                   298 - 2100  
% % % S2         4 - 1013775.04             + 681.890162     T       - 100.416000     T ln(T) 2100 - 3000 
% % % L1         5 - 930962.650             + 463.132871     T       + 1683920.51     T^-1    298 - 2130  
% % % L1         5 - 67156778.7     T^-2    - 77.8376214     T ln(T)                          298 - 2130  
% % % L1         6 - 977517.858             + 658.391910     T       - 100.416000     T ln(T) 2130 - 3000 
% % % G1         7 - 302512.406             + 183.574648     T       - 388.960000     T^0.5   298 - 1300  
% % % G1         7 - 3880.00000     ln(T)   - 62.6100000     T ln(T)                          298 - 1300  
% % % G1         8 - 325434.394             + 121.687350     T       - 3.792000000E-04 T^ 2   1300 - 3600 
% % % G1         8 - 55.9400000     T ln(T)                                                   1300 - 3600 
% % % G1         9 - 317217.322             + 85.2045306     T       - 9.785000000E-04 T^ 2   3600 - 6000 
% % % G1         9 - 51.5000000     T ln(T)                                                   3600 - 6000 
% % % ____________ ________________________ ________________________ ________________________ ___________ 
% % % 
'''
