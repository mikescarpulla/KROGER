import numpy as np
import scipy.io
import pandas as pd # you'll need to pip install this if not yet downloaded
import global_data

# Reference the data structure to the global database
conditions = global_data.conditions
defects = global_data.defects
equilib_dark_sol = global_data.equilib_dark_sol
fullquench_dark_sol = global_data.fullquench_dark_sol

# %% this has to come after a full equilibrium calculation

# %% compute the stoichiometry and element totals and write it to a file
element_totals_headers = ['T_equilibrium (K)'] + defects['elementnames']
element_totals_out = np.column_stack((
    equilib_dark_sol['T_equilibrium'],
    equilib_dark_sol['element_totals']
))
df_element_totals = pd.DataFrame(element_totals_out, columns=element_totals_headers)
df_element_totals.to_csv(
    conditions['save_pname'] + conditions['elements_save_fname'],
    sep='\t',
    index=False
)
print('wrote element total concentrations to text file')


# %% group defects into categories - so if there are 5 flavors of VGa you can put them all together for convenience
# in the .mat file, each row is a list of column numbers from the main defect database to sum into a group 

if conditions['defect_group_flag'] == 'On':
    temp = scipy.io.loadmat(
        conditions['defect_grouping_pname'] + conditions['defect_grouping_fname']
    )  # this loads variables into a dict 'temp'
    conditions['group_together_columns'] = temp['group_together_columns']
    # convert MATLAB cell array of strings into Python list
    conditions['group_names'] = [n[0] for n in temp['group_names'].flatten()]
    conditions['num_groups'] = int(temp['num_groups'].flatten()[0])

    nT = len(equilib_dark_sol['T_equilibrium'])
    grouped_defects = np.zeros((nT, conditions['num_groups']))

    for idx in range(conditions['num_groups']):
        cols = conditions['group_together_columns'][idx, :]
        # MATLAB is 1-based; convert to 0-based indices and drop zeros
        cols = cols[cols > 0].astype(int) - 1
        grouped_defects[:, idx] = equilib_dark_sol['defects'][:, cols].sum(axis=1)

    equilib_grouped_STH = equilib_dark_sol['sth1'] + equilib_dark_sol['sth2']
    quenched_grouped_STH = fullquench_dark_sol['sth1'] + fullquench_dark_sol['sth2']

    grouping_headers = [
        'T_equilibrium (K)',
        'n equilib (#/cm3)',
        'p equilib (#/cm3)',
        'STH equilib (#/cm3)',
        'n quench (#/cm3)',
        'p quench (#/cm3)',
        'STH quench (#/cm3)'
    ] + conditions['group_names']

    grouping_defects_out = np.column_stack((
        equilib_dark_sol['T_equilibrium'],
        equilib_dark_sol['n'],
        equilib_dark_sol['p'],
        equilib_grouped_STH,
        fullquench_dark_sol['n'],
        fullquench_dark_sol['p'],
        quenched_grouped_STH,
        grouped_defects
    ))
    df_grouping = pd.DataFrame(grouping_defects_out, columns=grouping_headers)
    df_grouping.to_csv(
        conditions['save_pname'] + conditions['grouping_save_fname'],
        sep='\t',
        index=False
    )  # write results with column headers

    # clean up
    del temp, grouped_defects, df_grouping


# %%%%%%%%%%% save the equilibrium outputs
all_defects_out = np.column_stack((
    equilib_dark_sol['T_equilibrium'],
    equilib_dark_sol['charge_bal_err'],
    equilib_dark_sol['element_bal_err'],
    equilib_dark_sol['tot_bal_err'],
    equilib_dark_sol['mu'],
    equilib_dark_sol['element_totals'],
    conditions['EvT_equilibrium'],
    conditions['EcT_equilibrium'],
    equilib_dark_sol['EFn'],
    equilib_dark_sol['EFp'],
    equilib_dark_sol['Nd'],
    equilib_dark_sol['Na'],
    equilib_dark_sol['n'],
    equilib_dark_sol['p'],
    equilib_dark_sol['sth1'],
    equilib_dark_sol['sth2'],
    equilib_dark_sol['defects']
))
all_chargestates_out = np.column_stack((
    equilib_dark_sol['T_equilibrium'],
    equilib_dark_sol['charge_bal_err'],
    equilib_dark_sol['element_bal_err'],
    equilib_dark_sol['tot_bal_err'],
    equilib_dark_sol['mu'],
    equilib_dark_sol['element_totals'],
    conditions['EvT_equilibrium'],
    conditions['EcT_equilibrium'],
    equilib_dark_sol['EFn'],
    equilib_dark_sol['EFp'],
    equilib_dark_sol['Nd'],
    equilib_dark_sol['Na'],
    equilib_dark_sol['n'],
    equilib_dark_sol['p'],
    equilib_dark_sol['sth1'],
    equilib_dark_sol['sth2'],
    equilib_dark_sol['chargestates']
))
all_defect_headers = (
    ['T_equilibrium (K)', 'charge_bal_err', 'element_bal_err', 'tot_bal_err']
    + defects['mu_names_with_units']
    + defects['elementnames']
    + ['Ev(T) (eV)', 'Ec(T) (eV)', 'Efn(eV)', 'Efp (eV)',
       'Nd (#/cm3)', 'Na (#/cm3)', 'n (#/cm3)', 'p (#/cm3)',
       'sth1 (#/cm3)', 'sth2 (#/cm3)']
    + defects['defect_names']
)
all_chargestate_headers = (
    ['T_equilibrium (K)', 'charge_bal_err', 'element_bal_err', 'tot_bal_err']
    + defects['mu_names_with_units']
    + defects['elementnames']
    + ['Ev(T) (eV)', 'Ec(T) (eV)', 'Efn(eV)', 'Efp (eV)',
       'Nd (#/cm3)', 'Na (#/cm3)', 'n (#/cm3)', 'p (#/cm3)',
       'sth1 (#/cm3)', 'sth2 (#/cm3)']
    + defects['chargestate_names']
)

df_all_defects = pd.DataFrame(all_defects_out, columns=all_defect_headers)
df_all_chargestates = pd.DataFrame(all_chargestates_out, columns=all_chargestate_headers)

all_elements_out = np.column_stack((
    equilib_dark_sol['T_equilibrium'],
    equilib_dark_sol['element_totals']
))

# throw out all the ones with insignificant concentrations and save
sig_defects_index = np.where(
    np.max(equilib_dark_sol['defects'], axis=0) >= conditions['save_min']
)[0]
sig_chargestates_index = np.where(
    np.max(equilib_dark_sol['chargestates'], axis=0) >= conditions['save_min']
)[0]

sig_defects_out = np.column_stack((
    equilib_dark_sol['T_equilibrium'],
    equilib_dark_sol['charge_bal_err'],
    equilib_dark_sol['element_bal_err'],
    equilib_dark_sol['tot_bal_err'],
    equilib_dark_sol['mu'],
    conditions['EvT_equilibrium'],
    conditions['EcT_equilibrium'],
    equilib_dark_sol['EFn'],
    equilib_dark_sol['EFp'],
    equilib_dark_sol['Nd'],
    equilib_dark_sol['Na'],
    equilib_dark_sol['n'],
    equilib_dark_sol['p'],
    equilib_dark_sol['sth1'],
    equilib_dark_sol['sth2'],
    equilib_dark_sol['defects'][:, sig_defects_index]
))
sig_chargestates_out = np.column_stack((
    equilib_dark_sol['T_equilibrium'],
    equilib_dark_sol['charge_bal_err'],
    equilib_dark_sol['element_bal_err'],
    equilib_dark_sol['tot_bal_err'],
    equilib_dark_sol['mu'],
    conditions['EvT_equilibrium'],
    conditions['EcT_equilibrium'],
    equilib_dark_sol['EFn'],
    equilib_dark_sol['EFp'],
    equilib_dark_sol['Nd'],
    equilib_dark_sol['Na'],
    equilib_dark_sol['n'],
    equilib_dark_sol['p'],
    equilib_dark_sol['sth1'],
    equilib_dark_sol['sth2'],
    equilib_dark_sol['chargestates'][:, sig_chargestates_index]
))
sig_defect_headers = (
    ['T_equilibrium (K)', 'charge_bal_err', 'element_bal_err', 'tot_bal_err']
    + defects['mu_names_with_units']
    + ['Ev(T) (eV)', 'Ec(T) (eV)', 'Efn(eV)', 'Efp (eV)',
       'Nd (#/cm3)', 'Na (#/cm3)', 'n (#/cm3)', 'p (#/cm3)',
       'sth1 (#/cm3)', 'sth2 (#/cm3)']
    + [defects['defect_names'][i] for i in sig_defects_index]
)
sig_chargestate_headers = (
    ['T_equilibrium (K)', 'charge_bal_err', 'element_bal_err', 'tot_bal_err']
    + defects['mu_names_with_units']
    + ['Ev(T) (eV)', 'Ec(T) (eV)', 'Efn(eV)', 'Efp (eV)',
       'Nd (#/cm3)', 'Na (#/cm3)', 'n (#/cm3)', 'p (#/cm3)',
       'sth1 (#/cm3)', 'sth2 (#/cm3)']
    + [defects['chargestate_names'][i] for i in sig_chargestates_index]
)

df_sig_defects = pd.DataFrame(sig_defects_out, columns=sig_defect_headers)
df_sig_chargestates = pd.DataFrame(sig_chargestates_out, columns=sig_chargestate_headers)

if conditions['save_files_flag'] == 'All':
    df_all_defects.to_csv(
        conditions['save_pname'] + conditions['equilib_save_fname'] + '_all_defects',
        sep='\t',
        index=False
    )
    df_all_chargestates.to_csv(
        conditions['save_pname'] + conditions['equilib_save_fname'] + '_all_chargestates',
        sep='\t',
        index=False
    )
elif conditions['save_files_flag'] == 'Sig_Only':
    df_sig_defects.to_csv(
        conditions['save_pname'] + conditions['equilib_save_fname'] + '_sig_defects',
        sep='\t',
        index=False
    )
    df_sig_chargestates.to_csv(
        conditions['save_pname'] + conditions['equilib_save_fname'] + '_sig_chargestates',
        sep='\t',
        index=False
    )
print('Wrote equilibrium dark solution to text files')

# write the whole solution structure to a .mat file
scipy.io.savemat(
    conditions['save_pname'] + conditions['equilib_save_fname'],
    {'equilib_dark_sol': equilib_dark_sol}
)
print('Wrote equilibrium dark solution to .mat file')

# clean up memory
del (
    all_defects_out, all_chargestates_out,
    df_all_defects, df_all_chargestates,
    sig_defects_index, sig_chargestates_index,
    sig_defects_out, sig_chargestates_out,
    df_sig_defects, df_sig_chargestates
)
