# this function calculates the defect equilibrium Energies entered in eV,
# concentrations entered in and come out in #/cm3 Defect charge state
# formation enthalpy is assumed to be in the form dH = dHo + q*EF don't
# mess with the location of the "end" for the main function - it is placed
# so the subrouties are nested functions and thus can access the workspace
# of the main function - letting them see the conditions, material, and
# defects variables without having those as explicit input arguments.
# 1/14/21  - implemented Fermi Dirac approximations rather than direct
# integration. 12/23/22 - added handling for fixed elements and fixed
# defects, which can then allow generalized quenching calcs 2/7/2023 =
# added in site blocking (finally!!!) 12/2023 - Megan addd in ability to
# freeze elements 1/2/24 - MAS fixed solution guess subroutines to use T
# dependent Eg for finding Ef gueses.  Cleaned up code. 1/3/24 - MAS
# editing of fixed elements to speed up, correction of denominators in site
# blocking (1-sum not sum-1 for the finite case).
# 10-4-2024 added option to supply a vector of initial guesses for
# Ef_mu_vec that will be helpful for generalized quenching.

# Import all addtional functions and tools used in this calculation
from equilibrium_dark_with_frozen_imports import *

def defect_equilibrium_dark_with_frozen(dummy_conditions, dummy_defects):
    ####### build up holder variables for outputs ##########
    # in the final output, each charge state has a column, each row is a different T.
    # Need this different name for the holder matrix because of scope of n_defects in some of the functions

    N_charge_states_out = np.zeros((len(dummy_conditions.T_equilibrium), dummy_defects.num_chargestates))
    N_defects_out = np.zeros((len(dummy_conditions.T_equilibrium), dummy_defects.num_defects))
    n_out = np.zeros(len(dummy_conditions.T_equilibrium))  # holder column vector # rows same as T
    p_out = np.zeros(len(dummy_conditions.T_equilibrium))
    sth1_out = np.zeros(len(dummy_conditions.T_equilibrium))
    sth2_out = np.zeros(len(dummy_conditions.T_equilibrium))
    EF_out = np.zeros(len(dummy_conditions.T_equilibrium))
    mu_out = np.zeros((len(dummy_conditions.T_equilibrium), dummy_conditions.num_elements))
    tot_bal_err_out = np.zeros(len(dummy_conditions.T_equilibrium))
    charge_bal_err_out = np.zeros(len(dummy_conditions.T_equilibrium))
    element_bal_err_out = np.zeros(len(dummy_conditions.T_equilibrium))
    stoich_out = np.zeros((len(dummy_conditions.T_equilibrium), dummy_conditions.num_elements))

    # Tloop_conditions holds *scalar* values for all properties one at a time as the T loop is worked throguh
    # make a local copy of the conditions variable to use with T dependnet
    # properties.  At every T we assign a new value of each property to each
    # variable as needed.  Future fix: assign T dependent dG0 values for
    # each chargestate for example.
    # all the subroutines will be written to use a dummy name version of conditions as a dummy variable
    # but when actually called should be called with "Tloop_conditions"
    Tloop_conditions = dummy_conditions

    # detect the type of calculation requested.  1=nothing frozen, 2=dfects frozen,
    # 3=elements frozen, 4 = defects and elments frozen.  The calc type gets
    # written back into the conditions variable
    Tloop_conditions = Calc_Method(Tloop_conditions)

    # check if guesses are supplied for Ef_mu_vec or not, then check if they
    # are valid
    if dummy_conditions['Ef_mu_guesses_supplied_flag'] == 'On':
        if (
            dummy_conditions('Ef_fixed_mu_guesses') is None or
            max(np.shape(dummy_conditions['Ef_fixed_mu_guesses'])) != dummy_conditions['num_T_equilibrium'] or
            min(np.shape(dummy_conditions['Ef_fixed_mu_guesses'])) != dummy_conditions['num_fixed_elements'] + 1
        ):
            raise ValueError(
                'If the conditions.Ef_fixed_mu_guesses field is present, it must have same number of rows as T_equilibrium '
                'and columns as num_fixed_elements + 1 and all be non-empty'
            )
        elif (
            max(np.shape(dummy_conditions['Ef_fixed_mu_guesses'])) == dummy_conditions['num_T_equilibrium'] and
            min(np.shape(dummy_conditions['Ef_fixed_mu_guesses'])) == dummy_conditions['num_fixed_elements'] + 1
        ):
            print('Ef_fixed_mu_guesses have been supplied.  It is recommended to use this only if you really need to override the automatic guess generation and temperature dependent solution following...')
        else:
            raise ValueError('Something strange about the supplied conditions.Ef_fixed_mu_guesses')

    # %%%%%%%% Main calculation - looped over all the equilibrium T's given.
    # %%%%%%%%% Tloop_conditions holds only scalar variables and is updated for
    # %%%%%%%%% each temperature, leaving the original conditions variabl alone
    print('as of now, T dependences for mu and band parameters are being used.  Must add capabilities for other properties being T dependent if desired in future')

    # start the main loop over temperatures
    for i1 in range(Tloop_conditions['num_T_equilibrium']): 

        # each time through the T loop, set the values of T_equilibrium
        Tloop_conditions['T_equilibrium'] = dummy_conditions['T_equilibrium'][i1]
        Tloop_conditions['kBT_equilibrium'] = dummy_conditions['kBT_equilibrium'][i1]
        Tloop_conditions['num_T_equilibrium'] = 1

        print('Starting calc for T=' + str(Tloop_conditions['T_equilibrium']) + 'K')  # call out the start of calc for each T

        # set the mu values for the current temperature.
        # the mu values set here will be overwritten (ignored) for fixed elements as needed further down in the code
        Tloop_conditions['muT_equilibrium'] = dummy_conditions['muT_equilibrium'][i1, :]

        # if Ef_fixed_mu_guesses are supplied in the conditions variable
        if Tloop_conditions['Ef_mu_guesses_supplied_flag'] == 'On':
            # set the values to the i1'st row of the array
            Tloop_conditions['Ef_fixed_mu_guesses'] = dummy_conditions['Ef_fixed_mu_guesses'][i1, :]

        # Handle set up the ability to specify fixed defect concentrations that vary vs T
        if dummy_conditions['T_dep_fixed_defect_flag'] == 'On':
            if np.shape(dummy_conditions['fixed_defects_concentrations'])[0] == Tloop_conditions['num_T_equilibrium']:
                # take the i1 row of the fixed defects variable from the original conditions file
                # and assign that row in the Tloop_conditions
                Tloop_conditions['fixed_defects_concentrations'] = dummy_conditions['fixed_defects_concentrations'][i1, :]
                # rotate this to a column vector (doing it in 2 steps to make it obvious we did it)
                Tloop_conditions['fixed_defects_concentrations'] = Tloop_conditions['fixed_defects_concentrations'].reshape(-1, 1)
            else:
                raise ValueError('If T_dep_fixed_defect_flag is ON, then conditions.fixed_defect_concentrations has to be a vector with an entry for each T')
        elif dummy_conditions['T_dep_fixed_defect_flag'] == 'Off':
            if np.shape(dummy_conditions['fixed_defects_concentrations'])[1] != 1:
                raise ValueError('If T_dep_fixed_defect_flag is OFF, then conditions.fixed_defect_concentrations has to be a single value (scalar) appropriate for all temperatures')

        # handle T dependent dH values here
        # if dummy_conditions.T_dep_dH == 'On':
        #     Tloop_defects.dH = dummy_defects.dHoT[i1, :]
        # elif dummy_conditions.T_dep_dH == 'Off':
        #     # do nothing different
        #     pass
        # else:
        #     raise ValueError('T dependent fixed defects and or T dependent dHo flags must be on or off')
        
        # Handle T dependent Nc, Nv, and band edges
        if dummy_conditions['T_dep_bands_flag'] == 'On':
            # the RHS of these calls need to call into original conditions variable (in case replace all is used by accident)
            Tloop_conditions['Eg'] = dummy_conditions['EgT_equilibrium'][i1]
            Tloop_conditions['Ec'] = dummy_conditions['EcT_equilibrium'][i1]
            Tloop_conditions['Ev'] = dummy_conditions['EvT_equilibrium'][i1]
            Tloop_conditions['Nc'] = dummy_conditions['NcT_equilibrium'][i1]
            Tloop_conditions['Nv'] = dummy_conditions['NvT_equilibrium'][i1]
        elif dummy_conditions['T_dep_bands_flag'] == 'Off':
            Tloop_conditions['Eg'] = dummy_conditions['EgRef']
            Tloop_conditions['Ec'] = dummy_conditions['EcRef']
            Tloop_conditions['Ev'] = 0
            Tloop_conditions['Nc'] = dummy_conditions['NcRef']
            Tloop_conditions['Nv'] = dummy_conditions['NvRef']
        else:
            raise ValueError('T dependent band parameters must be ON or OFF')
        

        # run the main calculation according to the method (method won't change vs T)  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if Tloop_conditions['calc_method'] == 1 or Tloop_conditions['calc_method'] == 2:
            # These are cases with no elements frozen. 1 is no defects frozen, 2 is some defects frozen.
            # We get the mu values from the conditions directly

            # options for the fzero routine (now user supplies these in the conditions variable)
            # fzero_options = optimset('PlotFcns','optimplotx','MaxFunEvals',1e6,'MaxIter',500,'TolX',1e-4,'TolFun',1e-4);
            # fzero_options = optimset('PlotFcns','optimplotfval','MaxFunEvals',1e6,'MaxIter',5000,'TolX',1e-4,'TolFun',1e-4);
            # fzero_options = optimset('PlotFcns','optimplotfval','MaxFunEvals',1e6,'MaxIter',500,'TolX',5e-3,'TolFun',1e-4);

            print('Calculation Method 1 or 2 running please be patient....')

            if Tloop_conditions['Ef_mu_guesses_supplied_flag'] == 'Off':
                if i1 == 0:
                    print('Starting grid search of Ef to get close to first solution')
                    EF_guess = EF_Guess12(Tloop_conditions)  # get a guess for EF close to minimum
                    print('Found guess for first T, passing it off to fzero')
                elif i1 == 1:
                    EF_guess = EF_from_last_T
                    print('Using solution from prior temperature as guess for solution - make sure to space T values close enough for continuity')
                elif i1 >= 2:
                    EF_guess = EF_from_last_T + 0.5 * (Tloop_conditions['T_equilibrium'] - last_T) * \
                               (EF_from_last_T - EF_from_2nd_last_T) / (last_T - second_last_T)
                    print('Using avg of prior solution and 1st order Taylor expansion as guess...')
            elif Tloop_conditions['Ef_mu_guesses_supplied_flag'] == 'On':
                EF_guess = Tloop_conditions['Ef_mu_guuesses']
            else:
                raise ValueError('problem with Ef_fixed_mu_guesses - it exists but something wrong')

            EF_out[i1] = root_scalar(Charge_Balance12, EF_guess, method='brentq') # We must specify the method of root finding - we use brents method to optimize since this is what fzero uses in matlab
            n_out[i1], p_out[i1], sth1_out[i1], sth2_out[i1] = Carrier_Concentrations(EF_out[i1])  # carriers
            EF_full_mu_vec = np.concatenate(([EF_out[i1]], Tloop_conditions['muT_equilibrium']))  # create the full EF_mu_vec taking in the fixed mu values
            N_charge_states_out[i1, :] = Chargestate_Concentrations(EF_full_mu_vec)  # compute the chargestate and carrier concentrations from the full EF_mu_vec
            charge_bal_err_out[i1] = Charge_Balance12(EF_out[i1])  # compute the net charge just to check final answers
            mu_out[i1, :] = Tloop_conditions['muT_equilibrium']

            if i1 >= 1:
                EF_from_2nd_last_T = EF_from_last_T
                EF_from_last_T = EF_out[i1]
                second_last_T = last_T
                last_T = Tloop_conditions['T_equilibrium']
            elif i1 == 0:
                EF_from_last_T = EF_out[i1]
                last_T = Tloop_conditions['T_equilibrium']
            else:
                raise ValueError('Something wrong with i1 indexing')



        elif Tloop_conditions['calc_method'] == 3 or Tloop_conditions['calc_method'] == 4:
            # These are the cases where some elements are frozen. 3 is only elements frozen, 4 is elements and defects frozen
            print('Calculation Method 3 or 4 running please be patient....')
            print('WARNING!!!: Remember, when element concentrations are fixed, it is possible that the desired solution is impossible to find within the limits of mu the user specified for each fixed element.  So check the results carefully and spend some time bracketing the solution by hand.  Remember that only complexes couple impurity elements together so you can vary one mu at a time for the most part. ')

            if Tloop_conditions['search_method_flag'] in ['particleswarm_pattern', 'particleswarm_pattern_simplex']:
                nvars = Tloop_conditions['num_fixed_elements'] + 1
                iter_lim = Tloop_conditions['fixed_elements_swarm_iterlimit_base'] * nvars
                stall_lim = Tloop_conditions['fixed_elements_swarm_stall_lim']
                display_int = Tloop_conditions['fixed_elements_swarm_display_int']

                if i1 == 0:
                    # calculate EF_min and EF_max based on band edges and temperature
                    EF_min = Tloop_conditions['Ev'] - 5 * Tloop_conditions['kBT_equilibrium']
                    EF_max = Tloop_conditions['Ec'] + 5 * Tloop_conditions['kBT_equilibrium']

                    # lower and upper bounds for PSO search: EF and mu for fixed elements
                    lb = np.concatenate((
                        [EF_min],
                        Tloop_conditions['fixed_elements_mu_ranges'][Tloop_conditions['indices_of_fixed_elements'], 0]
                    ))
                    ub = np.concatenate((
                        [EF_max],
                        Tloop_conditions['fixed_elements_mu_ranges'][Tloop_conditions['indices_of_fixed_elements'], 1]
                    ))

                    # estimate number of particles per fixed mu based on spacing and range
                    particles_per_fixed_mu = (
                        Tloop_conditions['fixed_elements_swarm1_fine_factor'] * (ub - lb) / Tloop_conditions['kBT_equilibrium']
                    )
                    grid_product = np.prod(particles_per_fixed_mu)

                    # calculate swarm size based on hypervolume and dimensionality
                    swarmsize1 = int(np.ceil(max(
                        Tloop_conditions['fixed_elements_swarm1_min_size'],
                        min(
                            Tloop_conditions['fixed_elements_swarm1_max_size'],
                            grid_product ** ((nvars - 1) / nvars)
                        )
                    )))

                    # configure swarm options depending on whether initial guesses are supplied
                    if Tloop_conditions['Ef_mu_guesses_supplied_flag'] == 'Off':
                        Tloop_conditions['swarm_options1'] = {
                            'SwarmSize': swarmsize1,
                            'Display': 'iter',
                            'DisplayInterval': display_int,
                            'ObjectiveLimit': Tloop_conditions['fixed_elements_swarm1_ObjectiveLimit'],
                            'MaxIterations': iter_lim,
                            'MaxStallIterations': stall_lim,
                            'HybridFcn': 'patternsearch'
                        }
                    elif Tloop_conditions['Ef_mu_guesses_supplied_flag'] == 'On':
                        Tloop_conditions['swarm_options1'] = {
                            'InitialPoints': Tloop_conditions['Ef_fixed_mu_guesses'][1:, :],
                            'SwarmSize': swarmsize1,
                            'Display': 'iter',
                            'DisplayInterval': display_int,
                            'ObjectiveLimit': Tloop_conditions['fixed_elements_swarm1_ObjectiveLimit'],
                            'MaxIterations': iter_lim,
                            'MaxStallIterations': stall_lim,
                            'HybridFcn': 'patternsearch'
                        }
                    else:
                        raise ValueError('looks like something contradictory with Ef_fixed_mu_guesses being supplied but no valid value provided?')

                    # run particle swarm optimization with Total_Balance34 as the objective
                    Total_Balance34 = Vectorize_Scalar_Function(Total_Balance34) # Vectorize Total_Balance34 in order to use pyswarm
                    # We need to make the bounds arrays in order to use pyswarm
                    lb = np.array(lb).flatten()
                    ub = np.array(ub).flatten()
                    swarm_options = { # Specifying swarm options, these are all common values, easily editable. 
                        'c1' : Tloop_conditions['swarm_options2'].get('c1',1.5), 
                        'c2' : Tloop_conditions['swarm_options2'].get('c2',1.5),
                        'w' : Tloop_conditions['swarm_options2'].get('c3',0.7)
                    }
                    # Now we can do a particle swarm
                    particle_swarm = GlobalBestPSO(n_particles=swarmsize1,dimensions=nvars,options=swarm_options,bounds=(lb,ub))
                    best_cost, EF_fixed_mu_vec_sol = particle_swarm.optimize(Total_Balance34,iters=Tloop_conditions['swarm_options1']['MaxIterations'])
                    
                    # If selected, refine solution using fminsearch (Nelder-Mead method in matlab)
                    if Tloop_conditions['search_method_flag'] == 'particleswarm_pattern_simplex':
                        EF_fixed_mu_vec_sol = minimize(Total_Balance34, EF_fixed_mu_vec_sol, method='Nelder-Mead',
                            options={
                                'maxfev': Tloop_conditions['fixed_elements_fmin_MaxFunEvals'],
                                'maxiter': Tloop_conditions['fixed_elements_fmin_MaxIter'],
                                'xatol': Tloop_conditions['fixed_elements_fmin_TolX'],
                                'fatol': Tloop_conditions['fixed_elements_fmin_TolFun']
                            }
                        ).x

                elif i1 >= 1:
                    # Define lower and upper bounds based on prior solution and thermal window
                    search_band = Tloop_conditions['fixed_elements_swarm2_search_band_kB'] * Tloop_conditions['kBT_equilibrium']
                    lb = EF_fixed_mu_from_last_T - search_band
                    ub = EF_fixed_mu_from_last_T + search_band 

                    # Estimate number of particles per variable
                    particles_per_fixed_mu = (
                        Tloop_conditions['fixed_elements_swarm2_fine_factor'] *
                        Tloop_conditions['fixed_elements_swarm2_search_band_kB']
                    )

                    grid_product = np.prod(particles_per_fixed_mu)  # hypervolume sampling density

                    # Calculate swarm size adaptively; very large. the idea is that you want to scale better than the dimensionality of the space being searched
                    swarmsize2 = int(np.ceil(
                        max(
                            Tloop_conditions['fixed_elements_swarm2_min_size'],
                            min(
                                Tloop_conditions['fixed_elements_swarm2_max_size'],
                                grid_product ** ((nvars - 1) / nvars)
                            )
                        )
                    ))

                    # Store swarm options for reuse (no 'InitialPoints' unless guesses are supplied)
                    if Tloop_conditions['Ef_mu_guesses_supplied_flag'] == 'Off':
                        Tloop_conditions['swarm_options2'] = {
                            'SwarmSize': swarmsize2,
                            'Display': 'iter',
                            'DisplayInterval': display_int,
                            'ObjectiveLimit': Tloop_conditions['fixed_elements_swarm2_ObjectiveLimit'],
                            'MaxIterations': iter_lim,
                            'MaxStallIterations': stall_lim,
                            'HybridFcn': 'patternsearch'  # placeholder, no direct PySwarms hybrid option
                        }
                    elif Tloop_conditions['Ef_mu_guesses_supplied_flag'] == 'On':
                        Tloop_conditions['swarm_options2'] = {
                            'InitialPoints': Tloop_conditions['Ef_fixed_mu_guesses'][1:, :],  # exclude EF
                            'SwarmSize': swarmsize2,
                            'Display': 'iter',
                            'DisplayInterval': display_int,
                            'ObjectiveLimit': Tloop_conditions['fixed_elements_swarm2_ObjectiveLimit'],
                            'MaxIterations': iter_lim,
                            'MaxStallIterations': stall_lim,
                            'HybridFcn': 'patternsearch'
                        }
                    else:
                        raise ValueError('looks like something contradictory with Ef_fixed_mu_guesses being supplied but no valid value provided?')

                    # Prepare and run particle swarm optimization
                    lb = np.array(lb).flatten()
                    ub = np.array(ub).flatten()

                    options = {
                        'c1': Tloop_conditions['swarm_options2'].get('c1', 1.5),
                        'c2': Tloop_conditions['swarm_options2'].get('c2', 1.5),
                        'w':  Tloop_conditions['swarm_options2'].get('w', 0.7)
                    }

                    Total_Balance34_vectorized = Vectorize_Scalar_Function(Total_Balance34)

                    particle_swarm = GlobalBestPSO(
                        n_particles=swarmsize2,
                        dimensions=nvars,
                        options=options,
                        bounds=(lb, ub)
                    )

                    best_cost, EF_fixed_mu_vec_sol = particle_swarm.optimize(
                        Total_Balance34_vectorized,
                        iters=Tloop_conditions['swarm_options2']['MaxIterations']
                    )

                    # Optional local refinement using fminsearch-style optimizer; setting can easily be tuned.
                    if Tloop_conditions['search_method_flag'] == 'particleswarm_pattern_simplex':
                        fminsearch_options = {
                            'maxfev': Tloop_conditions['fixed_elements_fmin_MaxFunEvals'],
                            'maxiter': Tloop_conditions['fixed_elements_fmin_MaxIter'],
                            'xatol': Tloop_conditions['fixed_elements_fmin_TolX'],
                            'fatol': Tloop_conditions['fixed_elements_fmin_TolFun']
                        }

                        EF_fixed_mu_vec_sol = minimize(
                            Total_Balance34,
                            EF_fixed_mu_vec_sol,
                            method='Nelder-Mead',
                            options=fminsearch_options
                        ).x

            elif Tloop_conditions['search_method_flag'] == 'grid_fminsearch':
                if Tloop_conditions['Ef_mu_guesses_supplied_flag'] == 'Off':
                    # max range of mu across fixed elements
                    max_mu_range = np.max(np.abs(
                        Tloop_conditions['fixed_elements_mu_ranges'][:, 1] -
                        Tloop_conditions['fixed_elements_mu_ranges'][:, 0]
                    ))

                    # this line calls back to the original conditions variable not Tloop one.
                    # Otherwise the search grid would become really really fine
                    start_kBT = dummy_conditions['kBT_equilibrium'][0]

                    fine_factor = 8

                    # Store number of grid points into Tloop_conditions
                    Tloop_conditions['fixed_elements_mu_npoints'] = int(
                        np.ceil(fine_factor * max_mu_range / start_kBT)
                    )

                    # Set options for fminsearch (Nelder-Mead)
                    fminsearch_options = {
                        'maxfev': Tloop_conditions['fixed_elements_fmin_MaxFunEvals'],
                        'maxiter': Tloop_conditions['fixed_elements_fmin_MaxIter'],
                        'xatol': Tloop_conditions['fixed_elements_fmin_TolX'],
                        'fatol': Tloop_conditions['fixed_elements_fmin_TolFun']
                    }  # may need to tune these settings

                    if i1 == 0:
                        print(
                            "Starting grid search over Ef and mu for fixed elements to get close to the solution for the first T. "
                            "Remember that the number of grid points to look at scales as num^dim+1 where dim is the number of fixed elements "
                            "and the +1 is for Ef"
                        )

                        import time
                        tic = time.time()

                        # Get a guess for EF and fixed mu values close to minimum using trial and error
                        EF_fixed_mu_guess = EF_Fixed_Mu_Guess34(Tloop_conditions)

                        guess_time = time.time() - tic
                        print(
                            f"Found guess for EF and mu values for fixed elements for first T in {guess_time:.2f} sec. "
                            "Phew that took a while. I need a shower, a beer, and to put my feet up. "
                            "Wait, you need me to keep going? Fine if you insist, but you should try to bracket the solution better next time."
                        )

                    elif i1 == 1:
                        EF_fixed_mu_guess = EF_fixed_mu_from_last_T
                        print("Using solution from prior temperature as guess for solution - make sure to space T values close enough for continuity")

                    elif i1 >= 2:
                        # This line calls back to dummy_conditions to access all T values
                        delta_T_prev = dummy_conditions['T_equilibrium'][i1 - 1] - dummy_conditions['T_equilibrium'][i1 - 2]
                        dEF_dT = (EF_fixed_mu_from_last_T - EF_fixed_mu_from_2nd_last_T) / delta_T_prev
                        dT = dummy_conditions['T_equilibrium'][i1] - dummy_conditions['T_equilibrium'][i1 - 1]
                        EF_fixed_mu_guess = EF_fixed_mu_from_last_T + 0.5 * dEF_dT * dT

                        print("Using avg of prior solution and 1st order Taylor expansion as guess...")
                    
                elif Tloop_conditions['Ef_mu_guesses_supplied_flag'] == 'On':
                    EF_fixed_mu_guess = Tloop_conditions['Ef_fixed_mu_guesses']
                else:
                    raise ValueError("Looks like something contradictory with Ef_fixed_mu_guesses being supplied but no valid value provided?")

                # First pass
                result = minimize(
                    Total_Balance34,
                    EF_fixed_mu_guess,
                    method='Nelder-Mead',
                    options=fminsearch_options
                )
                EF_fixed_mu_vec_sol = result.x
                fminsearch_exit_flag = result.status  # 0 = success

                # Second refinement pass
                result = minimize(
                    Total_Balance34,
                    EF_fixed_mu_vec_sol,
                    method='Nelder-Mead',
                    options=fminsearch_options
                )
                EF_fixed_mu_vec_sol = result.x
                fminsearch_exit_flag = result.status

            else:
                raise ValueError("For case 3 & 4 calculations, search_method_flag must be one of the coded options")

        # these items here are executed for cases 3 & 4 using any solver option
        print(f"Found solution as__{EF_fixed_mu_vec_sol}__for EF_fixed_mu_vec")

        # expand it out to the full EF_mu_vec
        EF_full_mu_vec_sol = Expand_Fixed_Mu_Vec_To_Full_Mu_Vec(EF_fixed_mu_vec_sol)

        # pick off the optimized EF value
        EF_out[i1] = EF_full_mu_vec_sol[0]

        # store mu values
        mu_out[i1, :] = EF_full_mu_vec_sol[1:]

        # carriers
        n_out[i1], p_out[i1], sth1_out[i1], sth2_out[i1] = Carrier_Concentrations(EF_out[i1])

        # chargestates
        N_charge_states_out[i1, :] = Chargestate_Concentrations(EF_full_mu_vec_sol)

        # compute balance errors
        charge_bal_err_out[i1] = Charge_Balance34(EF_fixed_mu_vec_sol)
        element_bal_err_out[i1] = np.sum(Fixed_Element_Balance34(EF_fixed_mu_vec_sol))
        tot_bal_err_out[i1] = Total_Balance34(EF_fixed_mu_vec_sol)

        print(f"charge_bal={charge_bal_err_out[i1]}")
        print(f"element_bal={element_bal_err_out[i1]}")
        print(f"tot_bal={tot_bal_err_out[i1]}")

        # update solution memory
        if i1 >= 2:
            EF_fixed_mu_from_2nd_last_T = EF_fixed_mu_from_last_T
            EF_fixed_mu_from_last_T = EF_fixed_mu_vec_sol
            second_last_T = last_T
            last_T = Tloop_conditions['T_equilibrium']
        elif i1 == 1:
            EF_fixed_mu_from_last_T = EF_fixed_mu_vec_sol
            last_T = Tloop_conditions['T_equilibrium']
        else:
            raise ValueError("Something wrong with i1 indexing")

    else:
        raise ValueError("calc method must be defined as 1, 2, 3, or 4 - check problem definition / setup")

################################### End of the Main Calculation ###################################################


################################# Create Final Output Structures ##################################################
    # now that we are out of the T loop we go back to dummy_conditions

    # sum over chargestates in each defect to get the totals for each defect.
    # Do this here at the end so the loop only runs one time
    for i3 in range(dummy_defects['num_defects']):
        index = dummy_defects['cs_ID'] == (i3 + 1)  # +1 to match MATLAB's 1-based indexing
        N_defects_out[:, i3] = np.sum(N_charge_states_out[:, index], axis=1)

    # build up the solution dictionary
    equilib_dark_sol = {}

    equilib_dark_sol['defect_names'] = dummy_defects['defect_names']
    equilib_dark_sol['chargestate_names'] = dummy_defects['chargestate_names']

    # transpose to match MATLAB column vector behavior
    equilib_dark_sol['T_equilibrium'] = np.array(dummy_conditions['T_equilibrium']).reshape(-1, 1)

    # create column vectors of Nd and Na repeated for each temperature
    num_T = len(dummy_conditions['T_equilibrium'])
    equilib_dark_sol['Nd'] = dummy_conditions['Nd'] * np.ones((num_T, 1))
    equilib_dark_sol['Na'] = dummy_conditions['Na'] * np.ones((num_T, 1))

    equilib_dark_sol['EFn'] = EF_out  # planning ahead for light calcs
    equilib_dark_sol['EFp'] = EF_out
    equilib_dark_sol['n'] = n_out
    equilib_dark_sol['p'] = p_out
    equilib_dark_sol['sth1'] = sth1_out
    equilib_dark_sol['sth2'] = sth2_out
    equilib_dark_sol['chargestates'] = N_charge_states_out
    equilib_dark_sol['defects'] = N_defects_out

    # handle stoichiometry-specific postprocessing
    if dummy_conditions['stoich_flag'] == 'Ga2O3':
        equilib_dark_sol['Ga_O_stoich'], equilib_dark_sol['element_totals'] = Ga2O3_stoich(
            equilib_dark_sol, dummy_conditions, dummy_defects
        )
    elif dummy_conditions['stoich_flag'] == 'CdTe':
        equilib_dark_sol['Cd_Te_stoich'], equilib_dark_sol['element_totals'] = CdTe_stoich(
            equilib_dark_sol, dummy_conditions, dummy_defects
        )
    else:
        print('Must specify the function that computes stoichiometry for each material')

    # store final error metrics and chemical potentials
    equilib_dark_sol['charge_bal_err'] = charge_bal_err_out
    equilib_dark_sol['element_bal_err'] = element_bal_err_out
    equilib_dark_sol['tot_bal_err'] = tot_bal_err_out
    equilib_dark_sol['mu'] = mu_out

##################################### End of the Main Function #############################################

