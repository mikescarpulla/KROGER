import numpy as np
from n_Fermi_Dirac import n_Fermi_Dirac

def Carrier_Concentrations(EF_dummy, Tloop_conditions):
    """
    Function to compute n and p.
    Input must be EF only (scalar, not vector with mu's attached).
    """

    etaCB = (EF_dummy - Tloop_conditions['Ec']) / Tloop_conditions['kBT_equilibrium']
    etaVB = (EF_dummy - Tloop_conditions['Ev']) / Tloop_conditions['kBT_equilibrium']  # looks asymmetric but correct
    etaSTH1 = (EF_dummy - (Tloop_conditions['Ev'] + Tloop_conditions['E_relax_sth1'])) / Tloop_conditions['kBT_equilibrium']
    etaSTH2 = (EF_dummy - (Tloop_conditions['Ev'] + Tloop_conditions['E_relax_sth2'])) / Tloop_conditions['kBT_equilibrium']

    if Tloop_conditions['Boltz_or_FD_flag'] == 'FD':
        # Use Fermi-Dirac integrals to handle degenerate conditions
        n = n_Fermi_Dirac(etaCB, Tloop_conditions['Nc'])
        p = n_Fermi_Dirac(-etaVB, Tloop_conditions['Nv'])
        sth1 = Tloop_conditions['sth_flag'] * n_Fermi_Dirac(-etaSTH1, Tloop_conditions['num_sites'][2])
        sth2 = Tloop_conditions['sth_flag'] * n_Fermi_Dirac(-etaSTH2, Tloop_conditions['num_sites'][3])

    elif Tloop_conditions['Boltz_or_FD_flag'] == 'Boltz':
        # Use Boltzmann approximation
        n = Tloop_conditions['Nc'] * np.exp(etaCB)
        p = Tloop_conditions['Nv'] * np.exp(-etaVB)
        sth1 = Tloop_conditions['sth_flag'] * Tloop_conditions['num_sites'][2] * np.exp(-etaSTH1)
        sth2 = Tloop_conditions['sth_flag'] * Tloop_conditions['num_sites'][3] * np.exp(-etaSTH2)

    else:
        raise ValueError("Boltz_or_FD_flag must be 'Boltz' or 'FD'")

    # Optional (commented out) method 1 of STHs assuming only way to make them is through free holes
    # sth = p * Tloop_conditions['sth_flag'] * np.exp(Tloop_conditions['E_relax_sth'] / Tloop_conditions['kBT_equilibrium'])

    return n, p, sth1, sth2
