import numpy as np

# Given EF and total number of each defect type, figure out the number of each charge state.
def fullquench_chargestate_concentrations(EF_dummy, conditions_dummy, defects_dumy, equilib_sol_dummy, j):
    # Set up arrays
    N_chargestates_fullquench = np.zeros(defects_dumy['num_chargestates'])
    Z = np.zeros(defects_dumy['num_defects'])

    # Calculate Boltzmann factors for all charge states
    # The formation enthalpy of the defects without the chemical potential term (quench assumes no mass exchange)
    dH_rel = defects_dumy['cs_dHo'] + defects_dumy['cs_charge'] * EF_dummy
    Boltz_facs = np.exp(-dH_rel / conditions_dummy['kBT_fullquench'])

    for i in range(defects_dumy['num_defects']):  # Loop over defects (defect.cs_ID) - not over charge states
        indices = (defects_dumy['cs_ID'] == i)  # Find the indices of the charge states of the ith defect
        Z[i] = np.sum(Boltz_facs[indices])  # Partition function Z for defect i

        # equilib_sol_dummy['defects'][j, i] is a scalar, Z[i] is a scalar
        N_chargestates_fullquench[indices] = (
            Boltz_facs[indices] / Z[i] * equilib_sol_dummy['defects'][j, i]
        )

    return N_chargestates_fullquench
# %%%% end concentrations
