import numpy as np
from Carrier_Concentrations_EDwF import Carrier_Concentrations 
from Chargestate_Concentrations_EDwF import Chargestate_Concentrations


def Charge_Balance12(EF_dummy, Tloop_conditions, dummy_defects):
    """
    Function to calculate signed charge balance for methods 1 and 2
    for speedup. Same as the 34 version but stripped all the fixed
    mu stuff out. This gets called a lot, so don't put any logic
    checks inside—do checking outside before calling this.
    """
    # Deal with carriers first
    n, p, sth1, sth2 = Carrier_Concentrations(EF_dummy)

    # Create the full EF_mu_vec
    EF_full_mu_vec_dummy = np.concatenate(([EF_dummy], Tloop_conditions['muT_equilibrium']))

    # Compute the concentration of all charged states
    N_chargestates = Chargestate_Concentrations(EF_full_mu_vec_dummy)

    # Compute the total signed charge balance
    charge_bal12 = (
        np.sum(dummy_defects['cs_charge'] * N_chargestates.T)
        + p + sth1 + sth2 - n
        + Tloop_conditions['Nd'] - Tloop_conditions['Na']
    )

    # Alternate version (commented out in original):
    # charge_bal12 = (
    #     (np.sum(dummy_defects['cs_charge'] * N_chargestates.T) + p - n + Tloop_conditions['Nd'] - Tloop_conditions['Na'])
    #     / np.sqrt(Tloop_conditions['Nc'] * Tloop_conditions['Nv'])
    # )

    return charge_bal12
