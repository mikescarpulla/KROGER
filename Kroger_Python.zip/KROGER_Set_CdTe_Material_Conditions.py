import numpy as np
import global_data

# Reference the conditions and defects structure to the global database
conditions = global_data.conditions
defects = global_data.defects

#%% Set Semiconductor Bandstructure and Lattice Sites %%%%%%%%%%%%%%%%%%%%%%
# This has to come after the temperature vector is set
# Ga2O3

conditions["vibent_T0"] = 200  # This is the characteristic T0 for the average phonon mode in Ga2O3, as determined from the w0 that makes the Debye temperature come out to about 740 K based on the Cv(T) data found online. T0 where x = hbar*w0/kBT = T0/T, wherein w0 is the mean phonon energy from the Debye temperature determined from Cv(T).

# When T-independent values are used
conditions["TRef"] = 300
conditions["EgRef"] = 1.5  # This is for constant Eg(T)
conditions["EvRef"] = 0
conditions["EcRef"] = conditions["EgRef"]
conditions["NcRef"] = 1e18
conditions["NvRef"] = 1e19

# T-dependent Eg values
conditions["Eg0"] = 1.5860  # Bandgap at 0K in eV. Using Adrian's number from STEM EELS at PSU - 4.8 eV at 300 K. So about 4.9 eV at 0K.
conditions["varshini_a"] = 5.9117e-4  # Can implement any model you want for Eg(T) as long as it gives a value for all T_equilibrium.
conditions["varshini_b"] = 160

# conditions["EcT_fraction"] = 0
# conditions["EcT_fraction"] = 0.25
conditions["EcT_fraction"] = 0.70
# conditions["EcT_fraction"] = 0.375
# conditions["EcT_fraction"] = 0.50  # What fraction of Eg(T) happens in the CB?
# conditions["EcT_fraction"] = 0.75
# conditions["EcT_fraction"] = 1
conditions["EvT_fraction"] = 1 - conditions["EcT_fraction"]

# These take the equilibrium T values from conditions and generate the
# needed T-dependent values. The fraction of Eg change caused by VB vs CB
# can be modified above.
conditions["NcT_equilibrium"] = conditions["NcRef"] * (conditions["T_equilibrium"] / conditions["TRef"]) ** 1.5
conditions["NvT_equilibrium"] = conditions["NvRef"] * (conditions["T_equilibrium"] / conditions["TRef"]) ** 1.5
delta_EgT_equilibrium = (conditions["varshini_a"] * conditions["T_equilibrium"] ** 2) / (conditions["T_equilibrium"] + conditions["varshini_b"])  # delta is a positive number
conditions["EgT_equilibrium"] = conditions["Eg0"] - delta_EgT_equilibrium
conditions["EcT_equilibrium"] = conditions["Eg0"] * np.ones_like(conditions["EgT_equilibrium"]) - conditions["EcT_fraction"] * delta_EgT_equilibrium
conditions["EvT_equilibrium"] = np.zeros_like(conditions["EgT_equilibrium"]) + conditions["EvT_fraction"] * delta_EgT_equilibrium

conditions["NcT_fullquench"] = conditions["NcRef"] * (conditions["T_fullquench"] / conditions["TRef"]) ** 1.5
conditions["NvT_fullquench"] = conditions["NvRef"] * (conditions["T_fullquench"] / conditions["TRef"]) ** 1.5
delta_EgT_fullquench = (conditions["varshini_a"] * conditions["T_fullquench"] ** 2) / (conditions["T_fullquench"] + conditions["varshini_b"])  # delta is a positive number
conditions["EgT_fullquench"] = conditions["Eg0"] - delta_EgT_fullquench
conditions["EcT_fullquench"] = conditions["Eg0"] - conditions["EcT_fraction"] * delta_EgT_fullquench
conditions["EvT_fullquench"] = conditions["EvT_fraction"] * delta_EgT_fullquench

# Clean up memory after using these
del delta_EgT_equilibrium, delta_EgT_fullquench

# Site densities in the Ga2O3 lattice (num FU/unit cell / vol for unit cell)
N_Cd = 1.47e22  # site 1
N_Te = 1.47e22  # site 2
N_iCd = 1.47e22  # site 3
N_iTe = 1.47e22  # site 4
conditions["num_sites"] = np.array([N_Cd, N_Te, N_iCd, N_iTe])  # Note this needs to be a column vector, don't change it to a row vector.

# Calculate the numerical prefactor for each defect from defects.degen_factor_config, defects.degen_factor_elec, defects.cs_num_each_site, and conditions.num_sites
# defects.cs_num_each_site tells you the number of primitive unit cells needed to form each defect (assuming the sites of the crystal, including distinct interstitials like the ia, ib, ... in b-Ga2O3, are counted such that there is one per primitive unit cell).
defects["cs_site_prefactor"] = np.sort(
    (np.ones((defects["num_chargestates"], 1)) * conditions["num_sites"]) / defects["cs_num_each_site"], axis=1
)  # Calculates the max number of each charge state that could be formed, given the availability of each site type in the crystal. Then sorts by the rows ascending.
defects["cs_site_prefactor"] = defects["cs_site_prefactor"][:, 0]  # Keep only the first column, which should be the limiting one.
defects["cs_prefactor"] = defects["cs_degen_factor_config"] * defects["cs_degen_factor_elec"] * defects["cs_site_prefactor"]

# Clean up memory
del N_Cd, N_Te, N_iCd, N_iTe
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
