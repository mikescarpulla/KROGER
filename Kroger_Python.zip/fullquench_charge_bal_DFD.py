import numpy as np
from fullquench_carrier_concentrations_DFD import fullquench_carrier_concentrations
from fullquench_chargestate_concentrations_DFD import fullquench_chargestate_concentrations

# Function that computes the net charge
def fullquench_charge_bal(EF_dummy, conditions_dummy, defects_dumy):
    n, p, sth1, sth2 = fullquench_carrier_concentrations(EF_dummy, conditions_dummy, defects_dumy)
    N_chargestates_fullquench = fullquench_chargestate_concentrations(EF_dummy, conditions_dummy, defects_dumy)

    # Compute the net charge balance
    charge_bal = (
        np.sum(defects_dumy['cs_charge'] * N_chargestates_fullquench.T)
        + p + sth1 + sth2 - n
        + conditions_dummy['Nd'] - conditions_dummy['Na']
    )
    return charge_bal
# %%%% end charge_bal   %%%%%%%%%%%%%
