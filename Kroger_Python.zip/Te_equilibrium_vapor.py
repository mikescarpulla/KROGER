import numpy as np
import matplotlib.pyplot as plt
from CdTe_G0_Imports import *

P_units = 'atm'
kB_eV = 8.617e-5
P_ref = 1

# Te species over elemental Te
plt.figure(1)
plt.clf()
plt.ylim([-20, 5])
plt.title(r'Vapor Pressure of $Te_i$ (i=1..7) over Te')
plt.xlabel('T (K)')
plt.ylabel(r'$\log_{10}(p in atm)$')

T = np.arange(300, 1601, 10)
T = T.reshape(-1,1)
G0_Te_condensed = G0_Te_ls.G0_Te_ls(T, 1, 1, P_units)  # Partial molar Gibbs energy per Te in solid/liquid Te

# Change in partial molar Gibbs energy per Te atom in solid/liquid upon vaporization
dGTe1 = G0_Te_gv.G0_Te_gv(T, 1, 1, P_units) - G0_Te_condensed
dGTe2 = (1 / 2) * G0_Te2_gv.G0_Te2_gv(T, 1, 1, P_units) - G0_Te_condensed
dGTe3 = (1 / 3) * G0_Te3_gv.G0_Te3_gv(T, 1, 1, P_units) - G0_Te_condensed
dGTe4 = (1 / 4) * G0_Te4_gv.G0_Te4_gv(T, 1, 1, P_units) - G0_Te_condensed
dGTe5 = (1 / 5) * G0_Te5_gv.G0_Te5_gv(T, 1, 1, P_units) - G0_Te_condensed
dGTe6 = (1 / 6) * G0_Te6_gv.G0_Te6_gv(T, 1, 1, P_units) - G0_Te_condensed
dGTe7 = (1 / 7) * G0_Te7_gv.G0_Te7_gv(T, 1, 1, P_units) - G0_Te_condensed

# Vapor pressures for Te species
p_Te1 = P_ref * np.exp(-dGTe1 / (kB_eV * T))
p_Te2 = P_ref * np.exp(-2 * dGTe2 / (kB_eV * T))
p_Te3 = P_ref * np.exp(-3 * dGTe3 / (kB_eV * T))
p_Te4 = P_ref * np.exp(-4 * dGTe4 / (kB_eV * T))
p_Te5 = P_ref * np.exp(-5 * dGTe5 / (kB_eV * T))
p_Te6 = P_ref * np.exp(-6 * dGTe6 / (kB_eV * T))
p_Te7 = P_ref * np.exp(-7 * dGTe7 / (kB_eV * T))
p_Tetot = p_Te1 + p_Te2 + p_Te3 + p_Te4 + p_Te5 + p_Te6 + p_Te7

# Plot individual species
plt.plot(T, np.log10(p_Te1), label='Te1')
plt.plot(T, np.log10(p_Te2), 'ro', label='Te2')
plt.plot(T, np.log10(p_Te3), label='Te3')
plt.plot(T, np.log10(p_Te4), label='Te4')
plt.plot(T, np.log10(p_Te5), label='Te5')
plt.plot(T, np.log10(p_Te6), label='Te6')
plt.plot(T, np.log10(p_Te7), label='Te7')
plt.plot(T, np.log10(p_Tetot), '-k', label=r'$Te_{all}$ (Sum Te1-Te7)')

# Brooks total Te over Te
TBrooks = T[T > 800]
pTeTotBrooksmmHg = 10 ** (-5960.2 / TBrooks + 7.5999)
pTeTotBrooksatm = pTeTotBrooksmmHg / 760
plt.plot(TBrooks, np.log10(pTeTotBrooksatm), label=r'Brooks $Te_{all}$')

plt.legend()

# Plot 2: Te2 over CdTe
plt.figure(2)
plt.clf()
plt.ylim([-20, 0])
plt.title(r'Vapor Pressure of $Te_2$ over CdTe')
plt.xlabel('T (K)')
plt.ylabel(r'$\log_{10}(p in atm)$')

# Te2 above CdTe
Tbrebrick = np.arange(1050, 1231, 10)
log10pTe2_Brebrick = -10000 / Tbrebrick + 6.346
plt.plot(Tbrebrick, log10pTe2_Brebrick, label='Brebrick 2010')

# Te2 above CdTe (LB regions)
TLB1 = np.arange(300, 1371, 10)
TLB2 = np.arange(1370, 1601, 10)
pCdTeLB1 = 10 ** (6.496 - 9580 / TLB1)
pCdTeLB2 = 10 ** (5.37 - 8050 / TLB2)
pTe2LB1 = pCdTeLB1 / 3
pTe2LB2 = pCdTeLB2 / 3

plt.plot(TLB1, np.log10(pTe2LB1), label=r'LB $T<T_m$')
plt.plot(TLB2, np.log10(pTe2LB2), label=r'LB $T>T_m$')

plt.legend()

# Plot 3: Plotting Gibbs energies per Te atom
plt.figure(3)
plt.clf()

# Plot and store the line objects
lines = []
labels = []

lines.append(plt.plot(T, G0_Te_ls.G0_Te_ls(T, 1, 1, P_units), 'b-')[0])
labels.append(r'$G^o_{l,s}$')

lines.append(plt.plot(T, G0_Te_gv.G0_Te_gv(T, 1, 1, P_units), 'orange')[0])
labels.append(r'$G^o_{Te_vap}$')

lines.append(plt.plot(T, 0.5 * G0_Te2_gv.G0_Te2_gv(T, 1, 1, P_units), 'g-')[0])
labels.append(r'$G^o_{Te_2,vap}$')

# Chemical potential calculations
lines.append(plt.plot(T, (2 * G0_Te_ls.G0_Te_ls(T, 1, 1, P_units) - G0_Te2_gv.G0_Te2_gv(T, 1, 1, P_units)) / 2, 'ko')[0])
labels.append(r'$\mu_{Te} = \frac{2G^o_{Te,ls} - G^o_{Te_2,\mathrm{vap}}}{2}$')

lines.append(plt.plot(T, 0.5 * kB_eV * T * np.log(p_Te2), 'g-')[0])
labels.append(r'$\mu_{Te} = \frac{1}{2} k_B T \ln(p_{\mathrm{vap},Te_2})$')

# Manually set the legend
plt.legend(handles=lines, labels=labels)

plt.xlabel('T (K)')
plt.ylabel('Gibbs Energy (eV/atom)')
plt.show()

plt.show()
