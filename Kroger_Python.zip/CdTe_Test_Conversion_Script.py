# This is the test conversion script for CdTe conversion to python
import numpy as np
import matplotlib.pyplot as plt
from Test_Funct import Test_Funct
import os
################################################################
########################### G0_Te_ls ###########################

from G0_Te_ls import G0_Te_ls

# Variables
#T = 300
#P_tot = 10
#T = np.array([100, 220, 332, 450])
#P_tot = np.array([10, 15, 20, 8])
T = np.linspace(1,1000,num=100)
P_tot = np.linspace(1,100,num=100)
P_partial = 3
X_i = P_partial / P_tot
P_units = 'Torr'

# Function Call
G0_Te_ls_result = G0_Te_ls(T, P_tot, X_i, P_units)

# Output result
# print(G0_Te_ls_result)

# Plotting
plt.plot(T,G0_Te_ls_result)
plt.xlabel("Temperature [K]")
plt.ylabel("Gibbs Energy [eV]")
plt.title("Calculating G (Python)")
plt.show()

################################################################
########################### G0_Te_gv ###########################
'''
from G0_Te_gv import G0_Te_gv

# Variables
P_partial = 3
P_units_poss = ['Torr','atm','Bar','Pa']
test_val = 'c'

for i in P_units_poss:
    P_units = i
    # Testing Scalar, Vector, and Range W/ Graph
    if test_val == 'a':
        T = 300
        P_tot = 10
        X_i = P_partial / P_tot
        G0_Te_gv_result = G0_Te_gv(T, P_tot, X_i, P_units)
        print(f'in {P_units} the value of G0_Te_gv_result is:',G0_Te_gv_result)
    elif test_val == 'b':
        T = np.array([100, 220, 332, 450])
        P_tot = np.array([10, 15, 20, 8])
        X_i = P_partial / P_tot
        G0_Te_gv_result = G0_Te_gv(T, P_tot, X_i, P_units)
        print(f'in {P_units} the value of G0_Te_gv_result is:\n',G0_Te_gv_result)
    else:
        T = np.linspace(1,1000,num=100)
        P_tot = np.linspace(1,100,num=100)
        X_i = P_partial / P_tot
        G0_Te_gv_result = G0_Te_gv(T, P_tot, X_i, P_units)
        plt.plot(T,G0_Te_gv_result)
        plt.show()
'''
################################################################
########################### G0_Te7_gv ###########################
'''
from G0_Te7_gv import G0_Te7_gv

# Variables
P_partial = 3
P_units_poss = ['Torr','atm','Bar','Pa']
test_val = 'c'

for i in P_units_poss:
    P_units = i
    # Testing Scalar, Vector, and Range W/ Graph
    if test_val == 'a':
        T = 300
        P_tot = 10
        X_i = P_partial / P_tot
        G0_Te7_gv_result = G0_Te7_gv(T, P_tot, X_i, P_units)
        print(f'in {P_units} the value of G0_Te7_gv_result is:',G0_Te7_gv_result)
    elif test_val == 'b':
        T = np.array([100, 220, 332, 450])
        P_tot = np.array([10, 15, 20, 8])
        X_i = P_partial / P_tot
        G0_Te7_gv_result = G0_Te7_gv(T, P_tot, X_i, P_units)
        print(f'in {P_units} the value of G0_Te7_gv_result is:\n',G0_Te7_gv_result)
    else:
        T = np.linspace(1,1000,num=100)
        P_tot = np.linspace(1,100,num=100)
        X_i = P_partial / P_tot
        G0_Te7_gv_result = G0_Te7_gv(T, P_tot, X_i, P_units)
        if i == "Torr":
            plt.plot(T,G0_Te7_gv_result)
            plt.show()
'''
################################################################
########################### G0_Te6_gv ###########################
'''
from G0_Te6_gv import G0_Te6_gv

os.system("cls")

# Variables
P_partial = 3
P_units_poss = ['Torr','atm','Bar','Pa']
test_val_poss = ['a','b','c']
Funct = G0_Te6_gv

for p in test_val_poss:
    test_val = p
    for i in P_units_poss:
        P_units = i
        # Testing Scalar, Vector, and Range W/ Graph
        if test_val == 'a':
            print(f"SCALAR TEST in {i}")
            T = 300
            P_tot = 10
            X_i = P_partial / P_tot
            result = Funct(T, P_tot, X_i, P_units)
            print(f'in {P_units} the scalar value of this function is:',result)
            print('\n\n')
        elif test_val == 'b':
            print(f"VECTOR TEST in {i}")
            T = np.array([100, 220, 332, 450])
            P_tot = np.array([10, 15, 20, 8])
            X_i = P_partial / P_tot
            result = Funct(T, P_tot, X_i, P_units)
            print(f'in {P_units} the vector value of this function is:\n',result)
            print('\n\n')
        else:
            T = np.linspace(1,1000,num=100)
            P_tot = np.linspace(1,100,num=100)
            X_i = P_partial / P_tot
            result = Funct(T, P_tot, X_i, P_units)
            plt.plot(T,result)
            plt.title(f"PLOT TEST in {i}")
            plt.show()

print(f'TESTING DONE for {Funct}')
'''
################################################################
########################### G0_Te5_gv ###########################
'''
# Import Thermo Function
from G0_Te5_gv import G0_Te5_gv

# Store Thermo Function in variable
Funct = G0_Te5_gv

# Call Function for Testing
Test_Funct(Funct)
'''
################################################################
########################### G0_Te4_gv ###########################
'''
# Clear terminal
os.system("cls" if os.name == "nt" else "clear")

# Import Thermo Function
from G0_Te4_gv import G0_Te4_gv

# Store Thermo Function in variable
Funct = G0_Te4_gv

# Call Function for Testing
Test_Funct(Funct)
'''

