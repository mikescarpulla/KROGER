import numpy as np

def G0_Cd_ls(T, P_tot, X_i, P_units):
    """
    Calculate the standard Gibbs free energy (G0_Cd_ls) for Cadmium.

    Parameters:
        T (numpy array): Temperature values (Kelvin).
        P_tot (numpy array): Total pressure values.
        X_i (numpy array): Mole fraction of the component.
        P_units (str): Unit of pressure ('atm', 'Torr', 'Pa', or 'Bar').

    Returns:
        numpy array: Gibbs free energy values in eV/Ga2O molecule.
    """

    # Define constants
    q = 1.602176634e-19  # Charge of an electron (C)
    avo = 6.0221409e+23  # Avogadro's number
    kB_eV = 8.617333262e-5  # Boltzmann constant in eV/K

    # Select the reference pressure (P_ref) based on units
    P_ref_dict = {'atm': 1, 'Torr': 760, 'Bar': 1, 'Pa': 1e5}
    if P_units not in P_ref_dict:
        raise ValueError("Units of pressure must be 'atm', 'Torr', 'Pa', or 'Bar'.")

    P_ref = P_ref_dict[P_units]

    # Ensure T and P_tot are column and row vectors, respectively
    T = np.asarray(T).reshape(-1, 1)  # Make T a column vector
    P_tot = np.asarray(P_tot).reshape(1, -1)  # Make P_tot a row vector

    # Shape T and P_tot to be 2D arrays for vectorized calculations
    T = T * np.ones((1, P_tot.shape[1]))  # Expand T across columns
    P_tot = np.ones((T.shape[0], 1)) * P_tot  # Expand P_tot across rows

    G0_Cd_s = np.zeros_like(T)
    G0_Cd_l = np.zeros_like(T)
    G0_Cd_ls = np.zeros_like(T)

    # Define masks based on temperature ranges for solid Cd
    masks1 = (T >= 298) & (T <= 594)
    masks2 = (T > 594) & (T <= 1500)
    masks3 = (T > 1500) & (T <= 1600)

    G0_Cd_s += masks1 * (-7083.46898 + 99.5061986 * T - 6.273908000e-3 * T**2 - 6966.36 * T**-1 - 22.0442408 * T * np.log(T))
    G0_Cd_s += masks2 * (-20064.9716 + 256.812234 * T + 8.832011496e-3 * T**2 + 1241289.61 * T**-1 - 8.996036074e-7 * T**3 - 45.1611543 * T * np.log(T))
    G0_Cd_s += masks3 * (-9027.48876 + 148.205481 * T - 29.7064000 * T * np.log(T))

    # Define masks for liquid Cd
    maskl1 = (T > 298) & (T <= 400)
    maskl2 = (T > 400) & (T <= 594)
    maskl3 = (T > 594) & (T <= 1600)

    G0_Cd_l += maskl1 * (-955.024687 + 89.2092822 * T - 6.273908000e-3 * T**2 - 6966.36000 * T**-1 - 22.0442408 * T * np.log(T))
    G0_Cd_l += maskl2 * (21716.8836 - 371.046869 * T - 0.115159917 * T**2 - 1271815.45 * T**-1 + 2.889978116e-5 * T**3 + 53.1313898 * T * np.log(T))
    G0_Cd_l += maskl3 * (-3252.30331 + 138.251107 * T - 29.7064000 * T * np.log(T))

    # Select the minimum Gibbs free energy (solid or liquid phase)
    G0_Cd_ls = np.minimum(G0_Cd_s, G0_Cd_l)

    # Convert units to eV/Ga2O molecule
    G0_Cd_ls /= (avo * q)

    # Account for total pressure and mole fraction
    G0_Cd_ls += kB_eV * T * np.log(X_i)

    # Set zero values to infinity for error indication
    G0_Cd_ls[G0_Cd_ls == 0] = np.inf

    return G0_Cd_ls

'''
View Data  Cd     Units:  T(K) P(atm) Energy(J) Quantity(mol) 
Name: Cadmium

  G(T) J/mol - 1 atm  

             G(T)                  G(T)                     G(T)                     T(K)        
 ____________ _____________________ ________________________ ________________________ ___________ 

 S1         1 - 7083.46898          + 99.5061986     T       - 6.273908000E-03 T^ 2   298 - 594   
 S1         1 - 6966.36000     T^-1 - 22.0442408     T ln(T)                          298 - 594   
 S1         2 - 20064.9716          + 256.812234     T       + 8.832011496E-03 T^ 2   594 - 1500  
 S1         2 + 1241289.61     T^-1 - 8.996036074E-07 T^ 3   - 45.1611543     T ln(T) 594 - 1500  
 S1         3 - 9027.48876          + 148.205481     T       - 29.7064000     T ln(T) 1500 - 1600 
 L1         4 - 955.024687          + 89.2092822     T       - 6.273908000E-03 T^ 2   298 - 400   
 L1         4 - 6966.36000     T^-1 - 22.0442408     T ln(T)                          298 - 400   
 L1         5 21716.8836            - 371.046869     T       - 0.115159917     T^ 2   400 - 594   
 L1         5 - 1271815.45     T^-1 + 2.889978116E-05 T^ 3   + 53.1313898     T ln(T) 400 - 594   
 L1         6 - 3252.30331          + 138.251107     T       - 29.7064000     T ln(T) 594 - 1600  
 G1         7 105599.101            - 28.4149645     T       - 20.7861120     T ln(T) 298 - 1500  
 ____________ _____________________ ________________________ ________________________ ___________ 
'''