# This is a subroutine that is called in the main calculation - equalibrium_dark_with_frozen

# EF_Guess12 samples a range of EF values and looks for the one that minimizes charge imbalance.

# Needed imports for the function
import numpy as np
import matplotlib.pyplot as plt
from Charge_Balance12_EDwF import Charge_Balance12
from EF_Grid_Maker_EDwF import EF_Grid_Maker

def EF_Guess12(EFG12_conditions):
    """
    For methods 1 & 2:
    Function that uses grid search to get an EF guess close to the charge balance solution.
    Returns a single EF value guess.
    """

    # Create grid of EF values
    EF_grid = EF_Grid_Maker(EFG12_conditions)

    nn = len(EF_grid)
    errs = np.zeros(nn)

    # Evaluate charge balance over the EF grid
    for i4 in range(nn):
        errs[i4] = Charge_Balance12(EF_grid[i4])  # Methods 1 & 2 only involve Ef

    # Find the index of the point closest to the zero crossing
    min_index = np.where((errs ** 2) == np.min(errs ** 2))[0]

    if min_index.size == 1:
        # normal case where one point is closest to the zero crossing
        EF_guess12 = EF_grid[min_index[0]]

    elif min_index.size == 2:
        # case where two are equally close, just pick one
        EF_guess12 = EF_grid[min_index[0]]

    elif min_index.size == 0 or min_index.size >= 3:
        # if something is really weird, plot charge balance vs EF and raise an error
        plt.figure(1)
        plt.clf()
        plt.plot(EF_grid, np.log10(np.abs(errs)), 'b-')
        plt.title("Charge balance error vs EF")
        plt.xlabel("EF (eV)")
        plt.ylabel("log10(|charge balance|)")
        plt.grid(True)
        print("Charge balance error values at min_index:", errs[min_index])
        raise ValueError("Something strange about charge balance error vs EF — solutions may not be valid. See figure 1")

    return EF_guess12