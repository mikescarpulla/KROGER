import numpy as np
import matplotlib.pyplot as plt
import os
import scipy.io as sio
import datetime

# T in Kelvin, kBT in eV, and the DOS factors which are set so that
# the integrals for n, p can be run in eV units and come out to #/cm^3
# The example here is Ga2O3 with defects computed by Joel Varley
# Convention for sites: Ga1 Ga2 O1 O2 O3 interstitial ...
# Convention for chemical potentials [Ga O Si H Fe Sn ...]
# Jan 2023 - added ability to freeze defect concentrations
# Feb 2023 - added site blocking
# 2/14/2023 - added provisions for variable pO2 - can make Brower diagram plots next
# 3/23 - 1/2024 added ability to freeze elements, major code overhauls -
# Megan Stephans and MS.
# 3/28/24 - renamed variables in defects to cs_ to denote they have to do
# with the charge states. Implemented ability for calculation of prefactors for each
# charge state using electronic degeneracy, config degeneracy, and number of
# primitive cells needed (complexes including multiple Sn_Ga defects would
# eat up multiple primitive cells to form each one).
# 4/3/24 - replaced grid search + fminsearch with particle swarm +
# pattern search, tuned default parameters. Fixed some issues with saving
# and the summed error function. Fixed saving files. Fixed bugs. Tuned
# parameters for swarm optimization in high dimensions without running out
# of memory
# 4/8/24 - added reduced files to save for defects above a user-defined threshold conc for all T's.
# Cleaned up plotting. Added ability to plot fractions of fixed elements in each defect.
# 8/12/24 - added self-trapped holes as another flavor of holes. Added
# quantum dSvib based on the number of atoms changed out.

# Clear workspace and figures   %%%%%%%%%%%%
# Equivalent to MATLAB's clear all, clc in Python

conditions = {}
conditions['figures_flag'] = 'On'
# conditions['figures_flag'] = 'Off'

if conditions['figures_flag'] == 'On':
    for i in range(1, 8):
        plt.figure(i)
        plt.clf()
        plt.hold = True  # Note: `hold on` is default behavior in matplotlib

# Set Physical Constants  %%%%%%%%%
conditions['q'] = 1.602176565e-19
conditions['h'] = 6.62606957e-34
conditions['kB'] = 8.6173324e-5
conditions['mo'] = 9.1093837e-31

import os
import scipy.io as sio

# Set problem definition and calculation details by editing this section %%%%%%%%
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

# Future improvement - make this into a modular ingestion where you can
# mix and match different subsets of all the defects and it will number
# the charge states automatically

# Select the .mat file database of defect properties and load it %%%%%%%%
# Note: defects and charge states listed down, one row per. Elements
# listed as columns in variables like defects.cs_dm. These conventions must
# be obeyed so that the matrix and vector multiplications used in calculations
# work out right - e.g., when mu vectors and dm vectors are multiplied to
# get formation energies for each defect.

conditions['defect_db_fname'] = None
conditions['defect_db_pname'] = None

# Uncomment to use a file selection dialog (if a GUI is available)
# conditions['defect_db_fname'], conditions['defect_db_pname'] = uigetfile('*.mat', 'Select the defect database file you want to use')
from mat_file_to_python_dict import mat_file_to_python_dict

if conditions['defect_db_fname'] is None or not isinstance(conditions['defect_db_fname'], str):
    # If the user doesn't pick one, set it manually here
    # conditions['defect_db_fname'] = 'Ga2O3_Varley_all_defects_new_072924.mat'
    conditions['defect_db_fname'] = 'Ga2O3_Varley_all_defects_new_092724.mat'

# You need to make sure the defects file is saved and present in the path the defect_db_pname saves
if conditions['defect_db_pname'] is None or not isinstance(conditions['defect_db_pname'], str):
    conditions['defect_db_pname'] = os.getcwd() + os.sep  # Get current working directory and ensure separator

# Load the .mat file
mat_filepath = os.path.join(conditions['defect_db_pname'], conditions['defect_db_fname'])
defects = mat_file_to_python_dict(mat_filepath)

defect_db_name_root = conditions['defect_db_fname'][:conditions['defect_db_fname'].rfind('.')]  # Strip extension from filename


if len(defects.keys()) < 18:
    raise ValueError('Defects database file seems to be missing some required parts - carefully check it and try again')

'''
# %%%%%%%%%%%%%%%%%% Manually increase dHo for Vga and complexes - numbers based on Varley 031424 database
for ii in list(range(38, 244)) + list(range(252, 560)) + list(range(568, 606)) + list(range(632, 676)):
    # conditions['defects']['cs_dHo'][ii] = conditions['defects']['cs_dHo'][ii] + 0.5
    conditions['defects']['cs_dHo'][ii] = conditions['defects']['cs_dHo'][ii] - 0.5
    # conditions['defects']['cs_dHo'][ii] = conditions['defects']['cs_dHo'][ii] - 1

# %%%%% choose folder and base filename to save calculation run outputs
save_fname_root = input("Enter the filename for saving results (or press Enter to use default): ")

if not save_fname_root:
    save_fname_root = conditions['defect_db_fname'].split('.')[0] + '_' + datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    conditions['save_pname'] = conditions['defect_db_pname']  # Default to defect database directory
elif save_fname_root[-4] == '.':
    save_fname_root = save_fname_root[:-4]  # Strip file extension if present
    conditions['save_pname'] = conditions['defect_db_pname']  # Default to defect database directory

conditions['conditions_save_fname'] = save_fname_root + '_calculation_conditions'
conditions['equilib_save_fname'] = save_fname_root + '_equilib_dark_sol'
conditions['fullquench_save_fname'] = save_fname_root + '_fullquench_dark_sol'
conditions['elements_save_fname'] = save_fname_root + '_element_totals'
conditions['grouping_save_fname'] = save_fname_root + '_grouped_defects'

# Cleanup temporary variables
del save_fname_root
'''
################################
import tkinter as tk
from tkinter import filedialog

# Initialize Tkinter and hide the root window
root = tk.Tk()
root.withdraw()  # Hide main window

# Open a file save dialog (equivalent to MATLAB uiputfile)
save_filepath = filedialog.asksaveasfilename(title="Select or type the filename and location for saving results")

if save_filepath:  # If user selects a file
    conditions['save_pname'], save_fname_root = os.path.split(save_filepath)  # Split into folder and filename
else:  # If user cancels, use defaults
    save_fname_root = conditions['defect_db_fname'].split('.')[0] + '_' + datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    conditions['save_pname'] = conditions['defect_db_pname']  # Default to defect database directory

# Ensure filename has no extension issues
if save_fname_root[-4] == '.':
    save_fname_root = save_fname_root[:-4]  # Strip file extension if present

# Assign calculated filenames
conditions['conditions_save_fname'] = save_fname_root + '_calculation_conditions'
conditions['equilib_save_fname'] = save_fname_root + '_equilib_dark_sol'
conditions['fullquench_save_fname'] = save_fname_root + '_fullquench_dark_sol'
conditions['elements_save_fname'] = save_fname_root + '_element_totals'
conditions['grouping_save_fname'] = save_fname_root + '_grouped_defects'


# %% Calc and Display Options  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
conditions['plot_log10_min'] = 14  # Threshold for plotting
conditions['plot_log10_max'] = 19  # Upper bound for plots

# Save to file options
conditions['save_min'] = 1e14  # Minimum threshold for saving defects

#conditions['stoich_flag'] = 'CdTe' # for CdTe calculations
conditions['stoich_flag'] = 'Ga2O3' # for Ga2O3 calculations

# Save all the defects and chargestates or just the ones
# conditions['save_files_flag'] = 'All' # Save all
conditions['save_files_flag'] = 'Sig_Only'  # Save only significant defects

# conditions['defect_group_flag'] = 'on'
conditions['defect_group_flag'] = 'Off'
if conditions['defect_group_flag'] == 'On':
    # conditions['defect_grouping_fname'] = 'CdTe_grouping_defects.mat' # for CdTe Calculations
    conditions['defect_grouping_fname'] = 'Ga2O3_grouping_defects.mat'
    conditions['defect_grouping_pname'] = os.getcwd() + os.sep

# Statistical mechanics options
    # Turn on Fermi-Dirac stats for bands or use Boltzmann stats
# conditions['Boltz_or_FD_flag'] = 'Boltz'
conditions['Boltz_or_FD_flag'] = 'FD'
    # Turn on or off site blocking statistics
conditions['site_blocking_flag'] = 'On_Infinite'
#conditions['site_blocking_flag'] = 'On_Finite'
#conditions['site_blocking_flag'] = 'Off'
    # Turn on or off vibrational entropy. Add 3kB per added atom, remove that for removed atoms.
    #  G = H-TS so interstiitals should decrease G while vacacnies add it
#conditions['vib_ent_flag'] = '3kB'
conditions['vib_ent_flag'] = 'Quantum'
#conditions['vib_ent_flag'] = 'Off'
    # Turn on or off T dependent parameters
conditions['T_dep_bands_flag'] = 'On'
#conditions['T_dep_bands_flag'] = 'Off'

# Self-trapped holes (STH) options
    # Give relaxation energy for the STH
#conditions['sth_flag'] = 0 # Turns off the STH
conditions['sth_flag'] = 1  # Turns on the STH
conditions['E_relax_sth1'] = 0.52 # Relaxation energy for STH1's
conditions['E_relax_sth2'] = 0.53 # Relaxation energy for STH2's

# Matrix chemical potential handling
#conditions['T_dep_matrix_mu_flag'] = 'Off' # Traditional way for most DFT papers = constant value vs. T
conditions['T_dep_matrix_mu_flag'] = 'On' # using actual thermochemistry

# Fixed defect concentration handling - Either a constant value 
#   for all T or different values vs T
#conditions['T_dep_fixed_defect_flag'] = 'On' 
conditions['T_dep_fixed_defect_flag'] = 'Off'

#  Interstitial equilibrium handling - paraequilibrium is when we assume that some of the defects like
#    interstitials will equilibrate like electrons in quenching.
#conditions['interstitial_equilibrate_at_Tquench_flag'] = 'On'
#conditions['interstitial_equilibrate_at_Tquench_flag'] = 'Off'

# EF and chemical potential guess options - user can provide guesses for EF or Ef_mu_vec for each T_equilibrium that override automatic
#   searching for grid searches.  For particleswarm, this guess is just added to the population of particles.   
#conditions['Ef_mu_guesses_supplied_flag'] = 'On'
conditions['Ef_mu_guesses_supplied_flag'] = 'Off'
# conditions["Ef_mu_guesses"] = []  # This creates the variable, but the user needs to put the right values into it at some point below.
# conditions["Ef_mu_guesses"] = np.ones((11, 1)) * np.array([1, -2])  # Guesses for [Ef, mufixed1, mufixed2, ...] (one row per temperature)

# adjust how fine the steps are for brute force search over Ef for quenching.  spacing = kBT/this.  kBT/2 is too coarse a lot of the time
conditions['fullquench_EF_search_step_divisor'] = 5 

# Optimization method selection - choose the method of optimization used for finding solutions when elements are constrained - case 3 and 4
conditions['search_method_flag'] = 'particleswarm_pattern_simplex'
#conditions['search_method_flag'] = 'grid_fminsearch'
#conditions['search_method_flag'] = 'particleswarm_pattern'


# %% Set options for fminsearch for fixing elements concentrations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Check which search method flag is selected
if conditions["search_method_flag"] == "grid_fminsearch":
    
    # Quicker set
    conditions["fixed_elements_fmin_MaxFunEvals"] = int(1e5)
    conditions["fixed_elements_fmin_MaxIter"] = int(1e5)
    conditions["fixed_elements_fmin_TolX"] = 1e-4
    conditions["fixed_elements_fmin_TolFun"] = 1e-4

    # Finer set (Uncomment to use)
    # conditions["fixed_elements_fmin_MaxFunEvals"] = int(1e6)
    # conditions["fixed_elements_fmin_MaxIter"] = int(1e6)
    # conditions["fixed_elements_fmin_TolX"] = 1e-5
    # conditions["fixed_elements_fmin_TolFun"] = 1e-5

elif conditions["search_method_flag"] in ["particleswarm_pattern", "particleswarm_pattern_simplex"]:
    
    # These control particle swarm search. Assumption: the list of T's
    # goes from high to low. For the first T, we do a more exhaustive
    # search for the solution. Then, for temperatures 2-end, we start out swarm2 
    # at the prior solution and search within a band a few kBT wide.

    conditions["fixed_elements_swarm_iterlimit_base"] = 20
    conditions["fixed_elements_swarm_stall_lim"] = 15
    conditions["fixed_elements_swarm_display_int"] = 5
    conditions["fixed_elements_swarm1_fine_factor"] = 3
    conditions["fixed_elements_swarm1_min_size"] = 350
    conditions["fixed_elements_swarm1_max_size"] = 15000  # 15000 seems to be OK upper limit on a laptop, 20000 is slow
    conditions["fixed_elements_swarm1_ObjectiveLimit"] = 1e10  # Quit if the best value is better than this

    conditions["fixed_elements_swarm2_fine_factor"] = 3
    conditions["fixed_elements_swarm2_search_band_kB"] = 2  # We take the solution from the prior temperature and search within a band +/- this*kB for the next one
    conditions["fixed_elements_swarm2_min_size"] = 300
    conditions["fixed_elements_swarm2_max_size"] = 15000
    conditions["fixed_elements_swarm2_ObjectiveLimit"] = 1e8

    if conditions["search_method_flag"] == "particleswarm_pattern_simplex":
        # These are for the final fminsearch after particleswarm is done.
        conditions["fixed_elements_fmin_MaxFunEvals"] = int(1e4)
        conditions["fixed_elements_fmin_MaxIter"] = 7500
        conditions["fixed_elements_fmin_TolX"] = 1e-5
        conditions["fixed_elements_fmin_TolFun"] = 1e-5


# %% Set Up Batch Calculation Permuting 4 Dopants and 2 Value of f %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
'''
for index in range(1, 9):

    if index == 1 or index == 5:
        save_fname_root = "Sn_Kuramata_2016"
    elif index == 2 or index == 6:
        save_fname_root = "Mg_doped"
    elif index == 3 or index == 7:
        save_fname_root = "Fe_doped"
    elif index == 4 or index == 8:
        save_fname_root = "UID_Kuramata_2016"

    if index <= 4:
        conditions["EcT_fraction"] = 0.75  # What fraction of Eg change vs T happens in the CB?
        save_fname_root = save_fname_root + "_f75"
    elif index >= 5:
        conditions["EcT_fraction"] = 0.50  # What fraction of Eg change vs T happens in the CB?
        save_fname_root = save_fname_root + "_f50"

    conditions_save_fname = save_fname_root + "_calculation_conditions"
    equilib_save_fname = save_fname_root + "_equilib_dark_sol"
    fullquench_save_fname = save_fname_root + "_fullquench_dark_sol"

    if conditions["figures_flag"] == "On":
        for i in range(1, 8): 
            plt.figure(i)  # Use matplotlib to handle figures
            plt.clf()
            plt.hold(True)  # Not needed in modern matplotlib; remove in actual implementation

        del i 

        # Set a threshold - if a quantity doesn't go above this at some temperature then don't bother plotting it
        conditions["plot_log10_min"] = 14  
        conditions["plot_log10_max"] = 20
'''

# %% Set Temperatures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Vector of T values at which to calculate for equilibrium
# Start at the highest T you want and then work down in order to fully
# exploit the adaptive guessing. Also, for fixed elements, the major time
# is spent finding the first guess, the optimization is fast by comparison once you fix 2 or more elements.
# So it's worth doing a fine T grid for long calculations so you don’t have
# to ever do it over.

conditions["T_equilibrium"] = np.arange(1500, 700 - 1, -100)  # Row vector of T in K at which to compute equilibrium

# Alternative temperature settings (uncomment as needed)
# conditions["T_equilibrium"] = np.arange(2100, 500 - 1, -100)
# conditions["T_equilibrium"] = np.arange(2100, 1500 - 1, -100)
# conditions["T_equilibrium"] = np.arange(1200, 800 - 1, -50)
# conditions["T_equilibrium"] = np.arange(2100, 2000 - 1, -100)
# conditions["T_equilibrium"] = np.arange(10, 300 + 1, 10)
# conditions["T_equilibrium"] = np.arange(2100, 1400 - 1, -50)
# conditions["T_equilibrium"] = np.arange(500, 2100 + 1, 50)
# conditions["T_equilibrium"] = np.arange(500, 2100 + 1, 100)
# conditions["T_equilibrium"] = np.arange(300, 2100 + 1, 100)

# Single-temperature settings for tasks like doping or mu sweeps
# conditions["T_equilibrium"] = np.array([1000 + 273])
# conditions["T_equilibrium"] = np.array([600 + 273])
# conditions["T_equilibrium"] = np.array([1600 + 273])
# conditions["T_equilibrium"] = np.array([1200 + 273])
# conditions["T_equilibrium"] = np.array([1100 + 273])
# conditions["T_equilibrium"] = np.array([1600 + 273])

conditions["num_T_equilibrium"] = len(conditions["T_equilibrium"])
conditions["kBT_equilibrium"] = conditions["kB"] * conditions["T_equilibrium"]

# Set final T for full quenching from the T_equilibrium values above
conditions["T_fullquench"] = 300  # Scalar temperature at which to compute the defect concentrations after quenching from T_equilibrium
conditions["kBT_fullquench"] = conditions["kB"] * conditions["T_fullquench"]

# Logic checks on temperatures
if conditions["T_equilibrium"].ndim != 1:
    raise ValueError("T_equilibrium should be a row vector")
elif not np.isscalar(conditions["T_fullquench"]):
    raise ValueError("Quench temperature has to be a scalar")
# End setting temperatures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







### Checks for creating defects and saving defect info
#print(defect_db_name_root) 
# Checking conditions

#print(conditions.keys())


#Checking Defects: 
print(defects.keys())
#print(defects['numelements'])
#print(defects['num_defects'])
#print(defects['elementnames'])