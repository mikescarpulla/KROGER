import numpy as np

def dSvib_quantum_per_mode(TempK, T0):
    """
    Calculates the normalized quantum vibrational entropy per mode.

    T0/T is x = ħ*ω₀ / (kB*T), so compute this from the Debye temperature.

    Returns:
        dSvib_Q_per_mode_norm = T0/(2*T) * coth(T0/(2*T)) + log(csch(T0/(2*T)))
    """
    x = T0 / (2 * TempK)

    # coth(x) = 1 / tanh(x), csch(x) = 1 / sinh(x)
    dSvib_Q_per_mode_norm = x / np.tanh(x) + np.log(1 / np.sinh(x))

    return dSvib_Q_per_mode_norm
