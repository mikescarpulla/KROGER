import numpy as np
import global_data

# Reference the conditions and defects structure to the global database
conditions = global_data.conditions
defects = global_data.defects

#%% Set Temperatures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Vector of T values at which to calculate for equilibrium
# Start at the highest T you want and then work down in order to fully
# exploit the adaptive guessing. Also, for fixed elements the major time
# is spent finding the first guess; the optimization is fast by comparison once you fix 2 or more elements.
# So it's worth doing a fine T grid for long calculations so you don't have
# to ever do it over.

conditions["T_equilibrium"] = np.arange(1500, 599, -20)  # Row vector of T in K at which to compute the equilibrium
conditions["num_T_equilibrium"] = len(conditions["T_equilibrium"])
conditions["kBT_equilibrium"] = conditions["kB"] * conditions["T_equilibrium"]

# Set final T for full quenching from the T_equilibrium values above
conditions["T_fullquench"] = 300  # Scalar temperature at which to compute the defect concentrations after quenching from T_equilibrium
conditions["kBT_fullquench"] = conditions["kB"] * conditions["T_fullquench"]

# Logic checks on temperatures
if conditions["T_equilibrium"].ndim != 1:
    raise ValueError("T_equilibrium should be a row vector")
elif not np.isscalar(conditions["T_fullquench"]):
    raise ValueError("Quench temperature has to be a scalar")
#%% End setting temperatures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#%%%%% Determine how to set pressures, chemical potentials, concentrations of the elements

#%% Set total pressure and units %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Set total pressure
# conditions["P_tot"] = 1e-4  # Total pressure in atm
conditions["P_tot"] = 1  # Total pressure in atm
# conditions["P_tot"] = 0.025  # Total pressure in atm

conditions["P_units"] = "atm"

# conditions["P_tot"] = 30e-3
# conditions["P_units"] = "Torr"

#%% Set up the elements to use in the model %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Note: Later below, some elements or individual defects' concentrations can
# be fixed. This overrides setting chemical potentials up here, so it's OK
# to have entries here for elements fixed later.

# conditions['num_elements] = 17; 
# If conditions["num_elements"] is not explicitly set, set it to the number of
# columns in defects["cs_dm"]
if "num_elements" not in conditions or not conditions["num_elements"]:
    conditions["num_elements"] = defects["cs_dm"].shape[1]

#%% Set the scenario used to determine the chemical potential of the host material
# Different options for setting the host material's chemical potentials according to equilibrium equations or other

# For T-independent mu conditions (set one mu like mu=0 for rich/poor conditions)
conditions["mu_CdTe"] = -1.39  # Formation energy of CdTe from Intuon

conditions["mu_conditions_flag"] = "CdTe_touching_Cd(l,s)"
# conditions["mu_conditions_flag"] = "CdTe_touching_Te(l,s)"

# If using "pO2-variable", need to also set pO2
# conditions["pO2"] = 1
# conditions["pO2"] = 0.2
# conditions["pO2"] = 0.02
# conditions["pO2"] = 0.2 * conditions["P_tot"]  # For MOCVD
# conditions["pO2"] = 1e-4
# conditions["pO2"] = 1e-6
# conditions["pO2"] = 1e-8

# If using "pGa_vap-variable", need to also set a value
# conditions["pGa_vap"] = 1e-4

# Specify partial pressures of Ga2O or GaO
# conditions["pGa2O_vap"] = 1e-4

# if conditions["mu_conditions_flag"] == "O2-1atm":  # Equilibrium with O2 at pO2=ptot=1 atm. This overrides anything set above.
#     conditions["pO2"] = 1
#     conditions["p_tot"] = 1
#%% End setting scenario for host material

#%% Set chemical potentials depending on the method for each element
# Set default that all elements have fixed value of mu that is
# very negative like -30 eV. Make a matrix with rows for each T and columns for each
# element (including matrix ones).
conditions["mu_constant_flag"] = np.ones(conditions["num_elements"], dtype=int)

# Initialize a flag for mu set by phase boundaries - this should be mutually
# exclusive with the constant mu flag above.
conditions["mu_from_2nd_phases_flag"] = np.zeros(conditions["num_elements"], dtype=int)

# Both of these options will overwrite entries in this variable initialized here - this is the one the actual calc uses
conditions["muT_equilibrium"] = -30 * np.ones((conditions["num_T_equilibrium"], defects["numelements"]))

#%% Matrix elements: set mu values first (first 2 columns for a binary, first 3 for a ternary, etc.)
mu_Cd, mu_Te = Cd_Te_CdTe_chem_potentials_from_conditions(conditions) #
conditions["muT_equilibrium"][:, 0] = mu_Cd  # Explicitly assign Cd column
conditions["muT_equilibrium"][:, 1] = mu_Te  # Explicitly assign Te column

#%% Impurity elements
# Calculate the values of all elements' limiting mu values based on the conditions
# [impurity_mu_boundary_limits] = impurity_mu_limit_imposed_by_pO2(conditions["T_equilibrium"], conditions["P_tot"], conditions["P_units"], mu_Te)

# Example for setting Si to -4 for all T
# conditions["mu_constant_flag"][2] = 1
# conditions["mu_from_2nd_phases_flag"][2] = 0
# mu_Si = -4
# conditions["muT_equilibrium"][:, 2] = mu_Si * np.ones(conditions["num_T_equilibrium"])

# Example for setting H to value set by 2nd phase equilibrium based on mu_O
#H_mu_num = 4
#conditions["mu_from_2nd_phases_flag"][H_mu_num - 1] = 1  # Convert to zero-based index
#conditions["mu_constant_flag"][H_mu_num - 1] = 0  # Flip the other flag too

# Use the right precomputed column. Column numbers for impurity_mu variable are smaller by 2
#conditions["muT_equilibrium"][:, H_mu_num - 1] = impurity_mu_boundary_limits[:, H_mu_num - 3]  

# mu_Sn set by 2nd phase equilibrium based on mu_O
#Sn_mu_num = 6
#conditions["mu_from_2nd_phases_flag"][Sn_mu_num - 1] = 1  # Convert to zero-based index
#conditions["mu_constant_flag"][Sn_mu_num - 1] = 0  # Flip the other flag too

# Use the right precomputed column. Column numbers for impurity_mu variable are smaller by 2
#conditions["muT_equilibrium"][:, Sn_mu_num - 1] = impurity_mu_boundary_limits[:, Sn_mu_num - 3]

#%% Logic checks
mu_set_exclusively_by_one_method_check = ((conditions["mu_constant_flag"] + conditions["mu_from_2nd_phases_flag"]) - 1) != 0
conditions["mu_set_flag"] = (conditions["mu_constant_flag"] + conditions["mu_from_2nd_phases_flag"]) > 0

if np.any(mu_set_exclusively_by_one_method_check):
    print(mu_set_exclusively_by_one_method_check)
    raise ValueError("Mu for each element must be set either as a constant or by a phase boundary.")

#%% Set elements with fixed concentrations and the target values
#if an element is fixed, it means the chemical potential for that element
# is floated (rather than fixed) and optimized (along with Ef and those of
# any others fixed )to get the desired total number over all the defects
# containing that element.  List any fixed elements by putting a 1 in its
# position in the vector conditions.fixed_conc_flag.
# This is mutually exclusive with setting chem potential for the element
# element order for ref
# Cd Te N P As Sb Cu

# initilaize flag and value pair for elements set by total concentrations -
# since this is a more unusual option this supercedes any mu values set (mu values determined in the calc self consistently).  This should be mutually exclusive with setting mu value flags though
conditions["fixed_conc_flag"] = np.zeros(conditions["num_elements"], dtype=int)
conditions["fixed_conc_values"] = np.zeros(conditions["num_elements"])  # Target values of elements

# Initialize holder for the ranges over which to search for mu for frozen elements
# convention for now is that this matrix should be the size for all the elements, not just the fixed ones we specify ranges for all the elements.  Later can change this to only specify ranges for the ones that are frozen (not specify values for those left open).
# since either a direct grid search or particle swarm is used to generate the first guess, there are
# HUGE time savings if you can narrow down this range manually first using
# a series of calcs with constant mu values to estimate mu for each element
# you want to freeze.  Or you can brute force it and just wait for ever...%
conditions["fixed_elements_mu_ranges"] = np.zeros((conditions["num_elements"], 2))

# Fix As doping
conditions["fixed_conc_flag"][4] = 1  # Fix As
conditions["mu_set_flag"][4] = 0  # Flip the flag saying Si is set by mu
conditions["fixed_conc_values"][4] = 5e16  # Specify the value
lo_mu_As = -10
hi_mu_As = -2
conditions["fixed_elements_mu_ranges"][4, :] = [lo_mu_As, hi_mu_As]

# Default is no elements fixed - catch if nothing entered.
if "fixed_conc_flag" not in conditions or not np.any(conditions["fixed_conc_flag"]):
    conditions["fixed_conc_flag"] = np.zeros(defects["numelements"], dtype=int)
elif "fixed_conc_values" not in conditions or not np.any(conditions["fixed_conc_values"]):
    conditions["fixed_conc_values"] = np.zeros(defects["numelements"])

# Use the fixed elements vector as a mask
conditions["fixed_conc_values"] *= conditions["fixed_conc_flag"]

# Find number of fixed elements and their indices
conditions["indices_of_fixed_elements"] = np.where(conditions["fixed_conc_flag"] > 0)[0]
conditions["num_fixed_elements"] = len(conditions["indices_of_fixed_elements"])

if conditions["num_fixed_elements"] != 0:
    for i in range(conditions["num_fixed_elements"]):
        msg = f"WARNING: Fixed concentration of element used for {defects['elementnames'][conditions['indices_of_fixed_elements'][i]]}... Be sure you meant to do this."
        print(msg)
else:
    print("No elements have fixed concentrations. Proceeding.")

#%% Logic checks on mu or concentrations set for each element
neither_mu_nor_conc_flag = conditions["mu_set_flag"] * conditions["fixed_conc_flag"]
both_mu_and_conc_flag = conditions["mu_set_flag"] + conditions["fixed_conc_flag"] == 0

if np.any(neither_mu_nor_conc_flag):
    print(neither_mu_nor_conc_flag)
    raise ValueError("Must set either the mu or concentration for each element.")
elif np.any(both_mu_and_conc_flag):
    print(both_mu_and_conc_flag)
    raise ValueError("Must set either the mu or the concentration for each element, not both.")
elif conditions["muT_equilibrium"].shape[1] != conditions["num_elements"]:
    raise ValueError("Number of columns in mu array not equal to number of elements declared.")
elif np.isinf(conditions["muT_equilibrium"]).any():
    raise ValueError("Infinite mu detected - this happens when there is no model for G0 for the T requested for some substance(s).")

#%% Cleanup
del both_mu_and_conc_flag, neither_mu_nor_conc_flag
#%% End handling matrix chemical potentials
