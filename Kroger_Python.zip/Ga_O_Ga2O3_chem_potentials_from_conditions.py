# %% Function that returns the Ga and O chemical potentials in equilibrium with Ga2O3 for a vector of temperatures
# %% 6/25/2024 - Aadi merged prior subroutines into one file so that new materials can be made using only one file.
# %% In the Ga-O system, we have Ga, GaO(vap), Ga2O (s, vap), Ga2O3(s,l), and O2(g).  
# The vapor formed over Ga2O3 is governed by Ga2O3 = Ga2O + O2.
# %% pure liquid Ga + Ga2O3 results in Ga2O evolving according to  4 Ga + 2 Ga2O3 = 4 Ga2O + O2.
from Ga2O3_G0_Imports import *

def Ga_O_Ga2O3_chem_potentials_from_conditions(conditions):
    print('Assumption is that the specified chemical potentials are continuously enforced at constant P (no products build up or reactants deplete). This is opposed to setting these initial conditions in a closed box and letting them react.  So user make sure specified conditions are compatible and undrstood.')

    if conditions['T_dep_matrix_mu_flag'] == 'Off':  # T independent mu values
        print('using T-independent chemical potentials')

        if conditions['mu_conditions_flag'] == 'O-rich':
            mu_O = 0
            mu_Ga = conditions['mu_Ga2O3'] / 2

        elif conditions['mu_conditions_flag'] == 'Ga-rich':  # for now main one should be O-rich
            mu_Ga = 0
            mu_O = conditions['mu_Ga2O3'] / 3
        else:
            raise ValueError('using T-independent mu values, conditions.mu_conditions_flag should be O-rich or Ga-rich')

        # user needs to commit these to the conditions variable in the main script
        mu_Ga = [mu_Ga] * len(conditions['T_equilibrium'])
        mu_O = [mu_O] * len(conditions['T_equilibrium'])

    elif conditions['T_dep_matrix_mu_flag'] == 'On':  # T dependent chemical potentials for the O and Ga
        print('using T-dependent chemical potentials')

        if conditions['mu_conditions_flag'] == 'O2-1atm':
            conditions.update({'pGa_vap': 0, 'pGaO_vap': 0, 'pGa2O_vap': 0, 'pO2': 1, 'P_tot': 1, 'P_units': 'atm'})
            G0_Ga2O3 = G0_Ga2O3_ls(conditions['T_equilibrium'], 1, 1, 'atm')
            G0_O2 = G0_O2_gv(conditions['T_equilibrium'], 1, 1, 'atm')
            mu_O = G0_O2 / 2
            mu_Ga = (G0_Ga2O3 - 3 * mu_O) / 2

        elif conditions['mu_conditions_flag'] == 'air-1atm':
            conditions.update({'pGa_vap': 0, 'pGaO_vap': 0, 'pGa2O_vap': 0, 'pO2': 0.2, 'pN2': 0.8, 'P_tot': 1, 'P_units': 'atm'})
            G0_Ga2O3 = G0_Ga2O3_ls(conditions['T_equilibrium'], 1, 1, 'atm')
            X_O2 = conditions['pO2'] / conditions['P_tot']
            X_N2 = conditions['pN2'] / conditions['P_tot']
            G0_O2 = G0_O2_gv(conditions['T_equilibrium'], conditions['P_tot'], X_O2, conditions['P_units'])
            mu_O = G0_O2 / 2
            mu_Ga = (G0_Ga2O3 - 3 * mu_O) / 2

        elif conditions['mu_conditions_flag'] == 'pO2-variable':
            conditions.update({'pGa_vap': 0, 'pGaO_vap': 0, 'pGa2O_vap': 0})
            if 'pO2' not in conditions or not conditions['pO2']:
                raise ValueError('if using conditions.mu_conditions_flag = pO2-variable, user must specify a pO2')
            if 'P_units' not in conditions or not conditions['P_units']:
                raise ValueError('if using conditions.mu_conditions_flag = pO2-variable, user must specify P units')
            G0_Ga2O3 = G0_Ga2O3_ls(conditions['T_equilibrium'], conditions['P_tot'], 1, conditions['P_units'])
            X_O2 = conditions['pO2'] / conditions['P_tot']
            G0_O2 = G0_O2_gv(conditions['T_equilibrium'], conditions['P_tot'], X_O2, conditions['P_units'])
            mu_O = G0_O2 / 2
            mu_Ga = (G0_Ga2O3 - 3 * mu_O) / 2

        elif conditions['mu_conditions_flag'] == 'pGa_vap-variable':
            conditions.update({'pO2': 0, 'pGaO_vap': 0, 'pGa2O_vap': 0})
            if not conditions['pGa_vap']:
                raise ValueError('if using conditions.mu_conditions_flag = pGa_vap-variable, user must specify a pGa_vap')
            if not conditions['P_units']:
                raise ValueError('if using conditions.mu_conditions_flag =  pGa_vap-variable, user must specify P units')
            G0_Ga2O3 = G0_Ga2O3_ls(conditions['T_equilibrium'], conditions['P_tot'], 1, conditions['P_units'])
            X_Ga_vap = conditions['pGa_vap'] / conditions['P_tot']
            ################################# CHANGED G0_GA_VAP TO G0_GA_GV ############################################
            mu_Ga = G0_Ga_gv(conditions['T_equilibrium'], conditions['P_tot'], X_Ga_vap, conditions['P_units'])
            mu_O = (G0_Ga2O3 - 2 * mu_Ga) / 3

        elif conditions['mu_conditions_flag'] == 'Ga_ls-rich':
            conditions.update({'pGa_vap': 0, 'pGa2O_vap': 0, 'pGaO_vap': 0, 'pO2': 0})
            G0_Ga2O3 = G0_Ga2O3_ls(conditions['T_equilibrium'], conditions['P_tot'], 1, conditions['P_units'])
            mu_Ga = G0_Ga_ls(conditions['T_equilibrium'], conditions['P_tot'], 1, conditions['P_units'])
            mu_O = (G0_Ga2O3 - 2 * mu_Ga) / 3

        else:
            raise ValueError('using T dependent chemical potentials, conditions.mu_conditions_flag must be one of the coded scenarios')

        # these two lines make sure that all values are scalars, and that the total pressure is >= to the sum of reactive (not inert gas) species
        scalar_check = all(isinstance(conditions[k], (int, float)) for k in ['P_tot', 'pGa_vap', 'pO2', 'pGaO_vap', 'pGa2O_vap'])
        if not scalar_check:
            raise ValueError('all pressures must scalar values  - make a loop over pressure in the script calling this if multiple P values are desired')

        if conditions['P_tot'] < (conditions['pGa_vap'] + conditions['pO2'] + conditions['pGaO_vap'] + conditions['pGa2O_vap']):
            raise ValueError('the total pressure must be >= sum of reactive (non inert) species pressures')

    else:
        raise ValueError('T_dep_matrix_mu_flag must be either "On" or "Off"')

    return mu_Ga, mu_O
