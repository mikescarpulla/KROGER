import numpy as np

def G0_Ga2O3_ls(T, P_tot, X_i, P_units):
    # gives the Gibbs energy of beta-Ga2O3 as function of T and P
    # T vector in K
    # G comes out in eV/Formula unit
    # values from Zinkevich and Aldinger JACS (2004)
    # convert to eV/FU at the end
    # the only thing P is used for here is making the output the right size

    # now convert units to eV per FU of b-Ga2O3 
    q = 1.602176634e-19  # J/eV
    avo = 6.0221409e+23  # formula units/mol
    kB_eV = 8.617333262e-5

    if P_units == 'atm':
        P_ref = 1
    elif P_units == 'Torr':
        P_ref = 760
    elif P_units == 'Bar':
        P_ref = 1
    elif P_units == 'Pa':
        P_ref = 1e5
    else:
        raise ValueError('Units of pressure must be atm, Torr, Pa, or Bar unless the ln(P/Pref) term is changed')

    # Make T a column vector
    T = np.array(T).reshape(-1, 1)
    nT = T.shape[0]

    # Make P_tot a row vector
    P_tot = np.array(P_tot).reshape(1, -1)
    nP = P_tot.shape[1]

    # Expand T and P_tot to match each other's dimensions
    T = T * np.ones((1, nP))
    P_tot = np.ones((nT, 1)) * P_tot
    G0_Ga2O3_ls = np.zeros_like(T)  # preallocate space

    # Gibbs free energy calculation in J/mol
    G0_Ga2O3_ls = -1127917 + 684.8332 * T - 112.3935 * T * np.log(T) - 0.00796268819 * (T**2) + 1080114 / T

    # Convert to eV/FU
    G0_Ga2O3_ls = G0_Ga2O3_ls / (q * avo)  # this should be in eV/FU

    # Now take Ptot and Xi into account  
    G0_Ga2O3_ls = G0_Ga2O3_ls + kB_eV * T * np.log(X_i)

    # set any that are zero because of masking to infinity so it produces an
    # obvious error that can be seen 
    G0_Ga2O3_ls[G0_Ga2O3_ls == 0] = np.inf

    return G0_Ga2O3_ls
