# This file contains all the imports for the thermodynamic
#   functions (calculating Gibbs Energy) associated with CdTe.
# Its function is to allow for a single line to be called in
#   scripts that rely on these functions.
# To call these functions in a script use: "from CdTe_G0_Imports import *"

import G0_Cd_gv as G0_Cd_gv
import G0_Cd_ls as G0_Cd_ls
import G0_CdTe_ls as G0_CdTe_ls
import G0_Te_gv as G0_Te_gv
import G0_Te_ls as G0_Te_ls
import G0_Te2_gv as G0_Te2_gv
import G0_Te3_gv as G0_Te3_gv
import G0_Te4_gv as G0_Te4_gv
import G0_Te5_gv as G0_Te5_gv
import G0_Te6_gv as G0_Te6_gv
import G0_Te7_gv as G0_Te7_gv