import numpy as np
import global_data

# Reference the conditions and defects structure to the global database
conditions = global_data.conditions
defects = global_data.defects

# %% Set unidentified shallow doping (fixed charge added to charge balance)
# conditions["Nd"] = 0  # Imposed shallow doping concentrations
# conditions["Nd"] = 2e16  # UID in real samples with Si background
# conditions["Nd"] = 2e17  # Intentional doping
# conditions["Nd"] = 0
# conditions["Na"] = 0

# Set shallow dopants to zero as default
if "Nd" not in conditions or conditions["Nd"] is None:
    conditions["Nd"] = 0

if "Na" not in conditions or conditions["Na"] is None:
    # conditions["Na"] = 2e17
    conditions["Na"] = 0
# %%% End shallow doping %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

# %%
# %% Set any interstitials that equilibrate at T_quench
# if conditions["interstitial_equilibrate_at_Tquench_flag"] == "On":
#     cs_is_simple_interstitial_flag = (
#         not np.any(defects["cs_num_each_site"][:, :5])
#         and np.sum(defects["cs_dm"], axis=1) == 1
#     )  # If the cs uses none of the {Ga1 Ga2 O1 O2 O3} sites, thus uses only interstitial sites AND it adds only one atom, it's a simple interstitial.
#     # Also add other defects or charge states explicitly by manually calling
#     # out their index number here, or a different logic condition
#
# elif conditions["interstitial_equilibrate_at_Tquench_flag"] == "Off":
#     cs_is_simple_interstitial_flag = np.zeros(defects["num_chargestates"])
# else:
#     raise ValueError("Something weird about some charge states in terms of whether or not they are simple interstitials")
#
# for kk in range(defects["num_chargestates"]):
#     if cs_is_simple_interstitial_flag[kk]:
#         conditions["set_to_zero_for_paraequilibrium_flag"] = 1
#     # elif some other condition based on diffusivity or includes small element like Li or H ...

# %% Set any defects with fixed concentrations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# This overrides any conditions set for the elements.
# First initialize a column vector with the right number of entries for the
# current defect variable. Then you can go in and set individual ones.
conditions["fixed_defects"] = np.zeros(defects["num_defects"])
conditions["fixed_defects_concentrations"] = np.zeros(defects["num_defects"])

# One might want to cancel out some defects from the database to not
# include them in a model run
# conditions["fixed_defects_concentrations"][5:7] = 0  # Antisites in Intuon CdTe database
# conditions["fixed_defects"][5:7] = 1

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# %% T-independent case - each defect has single value for all temperatures
#
# conditions["fixed_defects"][168] = 1
# # conditions["fixed_defects_concentrations"][168] = 8.9e16  # Si_GaI
#
# # Sn-doped Kuramata 2016
# conditions["fixed_defects"][221] = 1
# conditions["fixed_defects_concentrations"][221] = 3.6e17  # Ir_GaII
# conditions["fixed_defects"][192] = 1
# conditions["fixed_defects_concentrations"][192] = 4.3e16  # Cr_GaII
# conditions["fixed_defects"][198] = 1
# conditions["fixed_defects_concentrations"][198] = 2.5e15  # Ti_GaII
# conditions["fixed_defects"][246] = 1
# conditions["fixed_defects_concentrations"][246] = 6.3e15  # Zr_GaII
# conditions["fixed_defects"][237] = 1
# conditions["fixed_defects_concentrations"][237] = 1.3e16  # Ca_GaII
# conditions["fixed_defects"][235] = 1
# conditions["fixed_defects_concentrations"][235] = 1.4e16  # Mg_GaII
#
# # if index == 1 or index == 5:
#     ## Sn doped Kuramata 2016
#     conditions["fixed_defects"][222] = 1
#     conditions["fixed_defects_concentrations"][222] = 3.6e17   # Ir_GaII
#     conditions["fixed_defects"][193] = 1
#     conditions["fixed_defects_concentrations"][193] = 4.3e16   # Cr_GaII
#     conditions["fixed_defects"][199] = 1
#     conditions["fixed_defects_concentrations"][199] = 2.5e15   # Ti_GaII
#     conditions["fixed_defects"][247] = 1
#     conditions["fixed_defects_concentrations"][247] = 6.3e15   # Zr_GaII
#     conditions["fixed_defects"][238] = 1
#     conditions["fixed_defects_concentrations"][238] = 1.3e16   # Ca_GaII
#     conditions["fixed_defects"][236] = 1
#     conditions["fixed_defects_concentrations"][236] = 1.4e16   # Mg_GaII

# elif index == 2 or index == 6:
#     ## Mg doped
#     conditions["fixed_defects"][222] = 1
#     conditions["fixed_defects_concentrations"][222] = 5.9e16   # Ir_GaII
#     conditions["fixed_defects"][193] = 1
#     conditions["fixed_defects_concentrations"][193] = 3.9e16   # Cr_GaII
#     conditions["fixed_defects"][199] = 1
#     conditions["fixed_defects_concentrations"][199] = 3.8e15   # Ti_GaII
#     conditions["fixed_defects"][247] = 1
#     conditions["fixed_defects_concentrations"][247] = 8.8e15   # Zr_GaII
#     conditions["fixed_defects"][238] = 1
#     conditions["fixed_defects_concentrations"][238] = 1.3e16   # Ca_GaII
#     conditions["fixed_defects"][236] = 1
#     conditions["fixed_defects_concentrations"][236] = 2e18     # Mg_GaII

# elif index == 3 or index == 7:
#     ## Fe doped
#     conditions["fixed_defects"][222] = 1
#     conditions["fixed_defects_concentrations"][222] = 5.9e16   # Ir_GaII
#     conditions["fixed_defects"][193] = 1
#     conditions["fixed_defects_concentrations"][193] = 3.9e16   # Cr_GaII
#     conditions["fixed_defects"][199] = 1
#     conditions["fixed_defects_concentrations"][199] = 3.8e15   # Ti_GaII
#     conditions["fixed_defects"][247] = 1
#     conditions["fixed_defects_concentrations"][247] = 8.8e15   # Zr_GaII
#     conditions["fixed_defects"][238] = 1
#     conditions["fixed_defects_concentrations"][238] = 1.3e16   # Ca_GaII
#     conditions["fixed_defects"][236] = 1
#     conditions["fixed_defects_concentrations"][236] = 5e15     # Mg_GaII

# elif index == 4 or index == 8:
#     ## UID Kuramata 2016
#     conditions["fixed_defects"][222] = 1
#     conditions["fixed_defects_concentrations"][222] = 5.9e16   # Ir_GaII
#     conditions["fixed_defects"][193] = 1
#     conditions["fixed_defects_concentrations"][193] = 3.9e16   # Cr_GaII
#     conditions["fixed_defects"][199] = 1
#     conditions["fixed_defects_concentrations"][199] = 3.8e15   # Ti_GaII
#     conditions["fixed_defects"][247] = 1
#     conditions["fixed_defects_concentrations"][247] = 8.8e15   # Zr_GaII
#     conditions["fixed_defects"][238] = 1
#     conditions["fixed_defects_concentrations"][238] = 1.3e16   # Ca_GaII
#     conditions["fixed_defects"][236] = 1
#     conditions["fixed_defects_concentrations"][236] = 5e15     # Mg_GaII

# end


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# %% T-dependent fixed defect values
# Use this, for example, after floating the element and finding that only
# 2 defects dominate but their numbers change vs. T. The format will be T down the rows and concentrations for each
# defect across. So to pick out the column vector giving concentration of
# defect #32 at all the temperatures, you'd use conditions["fixed_defects_concentrations"][:, 31]

if conditions["T_dep_fixed_defect_flag"] == "On" and conditions["fixed_defects_concentrations"].ndim == 1:
    conditions["fixed_defects_concentrations"] = np.outer(
        np.ones_like(conditions["T_equilibrium"]), conditions["fixed_defects_concentrations"]
    )  # Expand out the list so each T can have a distinct value.

# Now we can go in and assign different values for different defects, for
# example based on values obtained from a prior simulation. Yes, for now specify the fixed defects
# inside the if loop checking if the flag is on.

# conditions["fixed_defects"][14] = 1  # VGa,ic in the 3/21/24 database

# if using a predefined temperature range, example:
# conditions["fixed_defects_concentrations"][:, 14] = np.array([values])

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# %% Logic checks on fixed defects and setting default to none fixed
# Default is none; catch this. Note that if elif loops exit once one
# condition is satisfied.

if "fixed_defects" not in conditions or conditions["fixed_defects"] is None:
    conditions["fixed_defects"] = np.zeros(defects["num_defects"])

if conditions["T_dep_fixed_defect_flag"] == "Off":
    conditions["fixed_defects_concentrations"] *= conditions[
        "fixed_defects"
    ]  # If a defect is not fixed but by accident it has a target conc set, just set its target concentration to zero also, using the fixed defects vector as a mask.

    if "fixed_defects_concentrations" not in conditions or conditions["fixed_defects_concentrations"] is None:
        conditions["fixed_defects_concentrations"] = np.zeros(defects["num_defects"])

# Applies to any fixed defect scenario
# Find number of fixed defects and their indices
conditions["indices_of_fixed_defects"] = np.where(conditions["fixed_defects"])[0]
conditions["num_fixed_defects"] = len(conditions["indices_of_fixed_defects"])

if conditions["num_fixed_defects"] != 0:
    for i in range(conditions["num_fixed_defects"]):
        msg = (
            f"WARNING: Fixed concentration used for {defects['defect_names'][conditions['indices_of_fixed_defects'][i]]}."
            " Be sure you meant to do this."
        )
        print(msg)
else:
    print("No Defects fixed. Proceeding.")

# %%% End section on fixed defects %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
