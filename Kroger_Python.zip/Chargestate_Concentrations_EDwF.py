import numpy as np
from dSvib_quantum_per_mode_EDwF import dSvib_quantum_per_mode

def Chargestate_Concentrations(EF_full_mu_vec_dummy, Tloop_conditions, dummy_defects):
    """
    Function that calculates the number of each charge state of each defect.
    Input must be a full EF_mu_vector with entries for ALL elements (not just fixed ones).
    Fixed defects override fixed elements, so method cases (1–4) must be handled separately.
    """

    EF = EF_full_mu_vec_dummy[0]
    mu_vec = EF_full_mu_vec_dummy[1:]

    if Tloop_conditions['calc_method'] in [1, 3]:

        if Tloop_conditions['vib_ent_flag'] == '3kB':
            dG = (
                dummy_defects['cs_dHo']
                - dummy_defects['cs_dm'] @ mu_vec
                + dummy_defects['cs_charge'] * EF
                - 3 * Tloop_conditions['kBT_equilibrium'] * np.sum(dummy_defects['cs_dm'], axis=1)
            )
        elif Tloop_conditions['vib_ent_flag'] == 'Quantum':
            dG = (
                dummy_defects['cs_dHo']
                - dummy_defects['cs_dm'] @ mu_vec
                + dummy_defects['cs_charge'] * EF
                - 3 * Tloop_conditions['kBT_equilibrium']
                * dSvib_quantum_per_mode(Tloop_conditions['T_equilibrium'], Tloop_conditions['vibent_T0'])
                * np.sum(dummy_defects['cs_dm'], axis=1)
            )
        elif Tloop_conditions['vib_ent_flag'] == 'Off':
            dG = (
                dummy_defects['cs_dHo']
                - dummy_defects['cs_dm'] @ mu_vec
                + dummy_defects['cs_charge'] * EF
            )
        else:
            raise ValueError("Vibrational entropy flag must be '3kB', 'Quantum', or 'Off'")

        if Tloop_conditions['site_blocking_flag'] == 'On_Infinite':
            partition = np.sum(np.exp(-dG / Tloop_conditions['kBT_equilibrium']))
            N_chargestates = (
                dummy_defects['cs_prefactor']
                * np.exp(-dG / Tloop_conditions['kBT_equilibrium'])
                / (1 + partition)
            ).T

        elif Tloop_conditions['site_blocking_flag'] == 'On_Finite':
            partition = np.sum(np.exp(-dG / Tloop_conditions['kBT_equilibrium']))
            N_chargestates = (
                dummy_defects['cs_prefactor']
                * np.exp(-dG / Tloop_conditions['kBT_equilibrium'])
                / (1 - partition)
            ).T

        elif Tloop_conditions['site_blocking_flag'] == 'Off':
            N_chargestates = (
                dummy_defects['cs_prefactor']
                * np.exp(-dG / Tloop_conditions['kBT_equilibrium'])
            ).T

        else:
            raise ValueError("Site blocking flag must be 'On_Infinite', 'On_Finite', or 'Off'")

    elif Tloop_conditions['calc_method'] in [2, 4]:
        # Full formation energy with chemical potentials
        if Tloop_conditions['vib_ent_flag'] == '3kB':
            dG = (
                dummy_defects['cs_dHo']
                - dummy_defects['cs_dm'] @ mu_vec
                + dummy_defects['cs_charge'] * EF
                - 3 * Tloop_conditions['kBT_equilibrium'] * np.sum(dummy_defects['cs_dm'], axis=1)
            )
        elif Tloop_conditions['vib_ent_flag'] == 'Quantum':
            dG = (
                dummy_defects['cs_dHo']
                - dummy_defects['cs_dm'] @ mu_vec
                + dummy_defects['cs_charge'] * EF
                - 3 * Tloop_conditions['kBT_equilibrium']
                * dSvib_quantum_per_mode(Tloop_conditions['T_equilibrium'], Tloop_conditions['vibent_T0'])
                * np.sum(dummy_defects['cs_dm'], axis=1)
            )
        elif Tloop_conditions['vib_ent_flag'] == 'Off':
            dG = (
                dummy_defects['cs_dHo']
                - dummy_defects['cs_dm'] @ mu_vec
                + dummy_defects['cs_charge'] * EF
            )
        else:
            raise ValueError("Vibrational entropy flag must be '3kB', 'Quantum', or 'Off'")

        # Relative formation energy without chemical potentials (for fixed defects)
        if Tloop_conditions['vib_ent_flag'] == '3kB':
            dG_rel = (
                dummy_defects['cs_dHo']
                + dummy_defects['cs_charge'] * EF
                - 3 * Tloop_conditions['kBT_equilibrium'] * np.sum(dummy_defects['cs_dm'], axis=1)
            )
        elif Tloop_conditions['vib_ent_flag'] == 'Quantum':
            dG_rel = (
                dummy_defects['cs_dHo']
                + dummy_defects['cs_charge'] * EF
                - 3 * Tloop_conditions['kBT_equilibrium']
                * dSvib_quantum_per_mode(Tloop_conditions['T_equilibrium'], Tloop_conditions['vibent_T0'])
                * np.sum(dummy_defects['cs_dm'], axis=1)
            )
        elif Tloop_conditions['vib_ent_flag'] == 'Off':
            dG_rel = (
                dummy_defects['cs_dHo']
                + dummy_defects['cs_charge'] * EF
            )
        else:
            raise ValueError("Vibrational entropy flag must be '3kB', 'Quantum', or 'Off'")

        Boltz_fac_rel = np.exp(-dG_rel / Tloop_conditions['kBT_equilibrium'])
        N_chargestates = np.zeros_like(dG)

        # Assign frozen defect charge state concentrations using Gibbs factors
        for i17 in range(Tloop_conditions['num_fixed_defects']):
            defect_idx = Tloop_conditions['fixed_defects_index'][i17]
            lo = dummy_defects['cs_indices_lo'][defect_idx]
            hi = dummy_defects['cs_indices_hi'][defect_idx] + 1
            indices = slice(lo, hi)
            Z = np.sum(Boltz_fac_rel[indices])
            N_chargestates[indices] = (
                Tloop_conditions['fixed_defects_concentrations'][defect_idx]
                * Boltz_fac_rel[indices]
                / Z
            )
            dG[indices] = -Tloop_conditions['kBT_equilibrium'] * np.log(
                N_chargestates[indices] / dummy_defects['cs_prefactor'][indices]
            )

        # Recalculate all charge state concentrations based on site blocking setting
        if Tloop_conditions['site_blocking_flag'] == 'On_Infinite':
            partition = np.sum(np.exp(-dG / Tloop_conditions['kBT_equilibrium']))
            N_chargestates = (
                dummy_defects['cs_prefactor']
                * np.exp(-dG / Tloop_conditions['kBT_equilibrium'])
                / (1 + partition)
            ).T

        elif Tloop_conditions['site_blocking_flag'] == 'On_Finite':
            partition = np.sum(np.exp(-dG / Tloop_conditions['kBT_equilibrium']))
            N_chargestates = (
                dummy_defects['cs_prefactor']
                * np.exp(-dG / Tloop_conditions['kBT_equilibrium'])
                / (1 - partition)
            ).T

        elif Tloop_conditions['site_blocking_flag'] == 'Off':
            N_chargestates = (
                dummy_defects['cs_prefactor']
                * np.exp(-dG / Tloop_conditions['kBT_equilibrium'])
            ).T

        else:
            raise ValueError("Site blocking flag must be 'On_Infinite', 'On_Finite', or 'Off'")

    else:
        raise ValueError("Calculation method must be 1, 2, 3, or 4")

    return N_chargestates
