import numpy as np

def Cd_Te_CdTe_chem_potentials_from_conditions(conditions):
    """
    Function that returns the Cd and Te chemical potentials in equilibrium with CdTe
    for a vector of temperatures.
    """

    print('Assumption is that the specified chemical potentials are continuously enforced at constant P (no products build up or reactants deplete). This is opposed to setting these initial conditions in a closed box and letting them react.  So user make sure specified conditions are compatible and understood.')

    if conditions['T_dep_matrix_mu_flag'] == 'Off':  # T independent mu values
        print('using T-independent chemical potentials')

        if conditions['mu_conditions_flag'] == 'Te-rich':
            mu_Te = 0
            mu_Cd = conditions['mu_CdTe']

        elif conditions['mu_conditions_flag'] == 'Cd-rich':  # For now, main one should be Te-rich or Cd-rich
            mu_Cd = 0
            mu_Te = conditions['mu_CdTe']
        else:
            raise ValueError("Using T-independent mu values, conditions['mu_conditions_flag'] should be 'Cd-rich' or 'Te-rich'")

        # user needs to commit these to the conditions variable in the main script
        mu_Cd = np.ones((len(conditions['T_equilibrium']),)) * mu_Cd
        mu_Te = np.ones((len(conditions['T_equilibrium']),)) * mu_Te

    elif conditions['T_dep_matrix_mu_flag'] == 'On':  # T-dependent chemical potentials from thermochemistry
        print('using T-dependent chemical potentials')

        if conditions['mu_conditions_flag'] == 'CdTe_touching_Cd(l,s)':
            mu_Cd = G0_Cd_ls(conditions['T_equilibrium'], conditions['P_tot'], 1, conditions['P_units'])
            mu_Te = G0_CdTe_ls(conditions['T_equilibrium'], conditions['P_tot'], 1, conditions['P_units']) - mu_Cd

        elif conditions['mu_conditions_flag'] == 'CdTe_touching_Te(l,s)':
            mu_Te = G0_Te_ls(conditions['T_equilibrium'], conditions['P_tot'], 1, conditions['P_units'])
            mu_Cd = G0_CdTe_ls(conditions['T_equilibrium'], conditions['P_tot'], 1, conditions['P_units']) - mu_Te

        elif conditions['mu_conditions_flag'] == 'Cd_vapor_over_Cd_at_T_Cd':
            G_Cd_condensed = G0_Cd_ls(conditions['T_Cd'], conditions['P_tot'], 1, conditions['P_units'])
            G_Cd_vap = G0_Cd_gv(conditions['T_Cd'], conditions['P_tot'], 1, conditions['P_units'])
            mu_Cd = conditions['P_ref'] * np.exp(-(G_Cd_vap - G_Cd_condensed) / (kB_eV * conditions['T_Cd']))  # treating Cd vapor as ideal gas at T_Cd
            mu_Te = G0_CdTe_ls(conditions['T_equilibrium'], conditions['P_tot'], 1, conditions['P_units']) - mu_Cd

        elif conditions['mu_conditions_flag'] == 'Te2_vapor_over_Te_at_T_Te':
            # here we approximate the vapor as being only Te2
            # dG_Te2 = 0.5 * G0_Te2_gv(conditions['T_Te'], conditions['P_ref'], 1, conditions['P_units']) \
            #         - G0_Te_ls(conditions['T_Te'], conditions['P_ref'], 1, conditions['P_units'])
            # p_Te2 = conditions['P_ref'] * np.exp(-2 * dG_Te2 / conditions['T_Te'])
            # mu_Te = 0.5 * kB_eV * conditions['T_Te'] * np.log(p_Te2 / conditions['P_ref'])

            # alternative approach that avoids computing pVap then ln:
            mu_Te = G0_Te_ls(conditions['T_Te'], 1, 1, conditions['P_units']) - G0_Te2_gv(conditions['T_Te'], conditions['P_tot'], 1, conditions['P_units']) / 2
            mu_Cd = G0_CdTe_ls(conditions['T_equilibrium'], conditions['P_tot'], 1, conditions['P_units']) - mu_Te

        # elif conditions['mu_conditions_flag'] == 'CdTe_congruent_vapor_at_Tsource':
        #     pass  # as for CSS - Tequilib is the sample T while vapor source could be higher

        else:
            raise ValueError("Using T-dependent chemical potentials, conditions['mu_conditions_flag'] must be one of the coded scenarios.")

        # These two checks ensure all pressures are scalars and that total pressure >= sum of reactive species
        # if not all(map(np.isscalar, [conditions['P_tot'], conditions['pGa_vap'], conditions['pO2'], conditions['pGaO_vap'], conditions['pGa2O_vap']])):
        #     raise ValueError("All pressures must be scalar values — make a loop in the calling script for multiple values")

        # if conditions['P_tot'] < (conditions['pGa_vap'] + conditions['pO2'] + conditions['pGaO_vap'] + conditions['pGa2O_vap']):
        #     raise ValueError("Total pressure must be >= sum of reactive (non-inert) species pressures")

    else:
        raise ValueError("conditions['T_dep_matrix_mu_flag'] must be 'On' or 'Off'")

    return mu_Cd, mu_Te
