import numpy as np

def G0_SnO_ls(T, P_tot, X_i, P_units):
    """
    This function gives the standard Gibbs energy G0 of SnO as a function of T, P_tot, and mole fraction.
    T and P_tot can be vectors; the output will be a 2D array.
    G0 is computed in kJ/mol and converted to eV/formula unit at the end.
    T in K, P in atm, Torr etc (must put in string argument 'atm' or 'Torr' etc)
    Logical masks are used like step functions vs T, allowing the whole expression to be built up piecewise over the list of T values  
    For a gas/vapor or mechanical mixture of phases such as ideal solution, mu(T,Ptot,Xi) = {Go(T,Pref) from Showmate equation} + kBT[ln(Ptot/Pref) + ln(X_i)]
         the total Gibbs energy of a mixture is Gmixture = Sum(Xi*mu_i) . Note how you end up with the xlnx terms this way, giving the ideal entropy of mixing

    Handy preformated Showmate templates
    Go = mask1.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    Go = Go + mask2.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    Go = Go + mask3.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    Go = Go + mask4.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));

    """

    # Define constants
    q = 1.602176634e-19  # Charge of an electron in Coulombs
    avo = 6.0221409e+23  # Avogadro's number
    kB_eV = 8.617333262e-5  # Boltzmann constant in eV/K

    # Select the reference pressure (P_ref) for specified units of pressure
    if P_units == 'atm':
        P_ref = 1
    elif P_units == 'Torr':
        P_ref = 760
    elif P_units == 'Bar':
        P_ref = 1
    elif P_units == 'Pa':
        P_ref = 1e5
    else:
        raise ValueError("Units of pressure must be 'atm', 'Torr', 'Pa', or 'Bar'.")

    # Ensure T and P_tot are column and row vectors, respectively
    T = np.array(T).reshape(-1, 1)  # Convert T to a column vector
    P_tot = np.array(P_tot).reshape(1, -1)  # Convert P_tot to a row vector

    # Create 2D arrays of T and P_tot for vectorized calculations
    T_matrix = T * np.ones_like(P_tot)
    P_tot_matrix = np.ones_like(T) * P_tot

    # Initialize G0 array
    G0_SnO_ls = np.zeros_like(T_matrix)

    # Define masks for temperature ranges
    mask1 = (T_matrix > 298) & (T_matrix <= 1273)  # solid

    # Solid
    G0_SnO_ls = G0_SnO_ls + mask1 * (
        -298331.317
        + 215.499320 * T_matrix
        - 7.322000000e-03 * T_matrix**2
        - 39.9572 * T_matrix * np.log(T_matrix)
    )

    # Convert units to eV per SnO
    G0_SnO_ls = G0_SnO_ls / (avo * q)  # eV/SnO molecule

    # Account for P_tot and X_i
    G0_SnO_ls =  G0_SnO_ls + kB_eV * T_matrix * np.log(X_i)

    # Set any zero values caused by masking to infinity for obvious errors
    G0_SnO_ls[G0_SnO_ls == 0] = np.inf

    return G0_SnO_ls

'''
% % % 
% % % View Data  SnO     Units:  T(K) P(atm) Energy(J) Quantity(mol) 
% % % Name: Tin Monoxide
% % % 
% % %   G(T) J/mol - 1 atm  
% % % 
% % %              G(T)                     G(T)                     G(T)                   T(K)        
% % % ____________ ________________________ ________________________ ______________________ ___________ 
% % % 
% % % S1         1              +      T       -  T^ 2 298 - 1273  
% % % S1         1    T ln(T)                                                 298 - 1273  
% % % G1         2 10508.1867               + 30.2261397     T       + 140400.000     T^-1  298 - 1000  
% % % G1         2 - 221.320000     T^0.5   - 37.9600000     T ln(T)                        298 - 1000  
% % % G1         3 9898.11022               + 2.11008105     T       - 6.515000000E-04 T^ 2 1000 - 2000 
% % % G1         3 - 34.7000000     T ln(T)                                                 1000 - 2000 
% % % ____________ ________________________ ________________________ ______________________ ___________ 
% % % 
'''