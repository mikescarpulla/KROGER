import numpy as np

def G0_Ti2O3_ls(T, P_tot, X_i, P_units):
    """
    This function gives the standard Gibbs energy G0 of Ti2O3 as a function of T, P_tot, and mole fraction.
    T and P_tot can be vectors; the output will be a 2D array.
    G0 is computed in kJ/mol and converted to eV/formula unit at the end.
    T in K, P in atm, Torr etc (must put in string argument 'atm' or 'Torr' etc)
    Logical masks are used like step functions vs T, allowing the whole expression to be built up piecewise over the list of T values  
    For a gas/vapor or mechanical mixture of phases such as ideal solution, mu(T,Ptot,Xi) = {Go(T,Pref) from Showmate equation} + kBT[ln(Ptot/Pref) + ln(X_i)]
        the total Gibbs energy of a mixture is Gmixture = Sum(Xi*mu_i) . Note how you end up with the xlnx terms this way, giving the ideal entropy of mixing
    
    Handy preformated Showmate templates
    Go = mask1.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    Go = Go + mask2.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    Go = Go + mask3.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    Go = Go + mask4.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    """

    # Define constants
    q = 1.602176634e-19  # Charge of an electron in Coulombs
    avo = 6.0221409e+23  # Avogadro's number
    kB_eV = 8.617333262e-5  # Boltzmann constant in eV/K

    # Select the reference pressure (P_ref) for specified units of pressure
    if P_units == 'atm':
        P_ref = 1
    elif P_units == 'Torr':
        P_ref = 760
    elif P_units == 'Bar':
        P_ref = 1
    elif P_units == 'Pa':
        P_ref = 1e5
    else:
        raise ValueError("Units of pressure must be 'atm', 'Torr', 'Pa', or 'Bar'.")

    # Ensure T and P_tot are column and row vectors, respectively
    T = np.array(T).reshape(-1, 1)  # Convert T to a column vector
    P_tot = np.array(P_tot).reshape(1, -1)  # Convert P_tot to a row vector

    # Create 2D arrays of T and P_tot for vectorized calculations
    T_matrix = T * np.ones_like(P_tot)
    P_tot_matrix = np.ones_like(T) * P_tot

    # Initialize G0 arrays
    G0_Ti2O3_s1 = np.zeros_like(T_matrix)
    G0_Ti2O3_s2 = np.zeros_like(T_matrix)
    G0_Ti2O3_liquid = np.zeros_like(T_matrix)
    G0_Ti2O3_ls = np.zeros_like(T_matrix)

    # Define masks for temperature ranges
    mask1 = (T_matrix >= 298) & (T_matrix <= 470)  # solid 1
    mask2 = (T_matrix > 470) & (T_matrix <= 2115)
    mask3 = (T_matrix > 298) & (T_matrix <= 2115)  # solid 2
    mask4 = (T_matrix > 298) & (T_matrix <= 2115)  # liquid

    # solid1
    G0_Ti2O3_s1 = mask1 * (
        -1171154.54
        + 6399.41546 * T_matrix
        - 9404192.70 * T_matrix**(-1.0)
        - 58419.4632 * T_matrix**0.5
        - 730.233813 * T_matrix * np.log(T_matrix)
    )
    G0_Ti2O3_s1 += mask2 * (
        -1548686.12
        + 1157.75518 * T_matrix
        - 804824.470 * T_matrix**(-1.0)
        - 3000.87476 * T_matrix**0.5
        + 260920167.0 * T_matrix**(-2.0)
        - 169.961109 * T_matrix * np.log(T_matrix)
    )

    # solid2
    G0_Ti2O3_s2 = mask3 * (
        -1547548.01
        + 1155.33360 * T_matrix
        - 804824.470 * T_matrix**(-1.0)
        - 3000.87476 * T_matrix**0.5
        + 260920167.0 * T_matrix**(-2.0)
        - 169.961109 * T_matrix * np.log(T_matrix)
    )

    # liquid
    G0_Ti2O3_liquid = mask4 * (
        -1442547.94
        + 1105.68824 * T_matrix
        - 804824.470 * T_matrix**(-1.0)
        - 3000.87476 * T_matrix**0.5
        + 260920167.0 * T_matrix**(-2.0)
        - 169.961109 * T_matrix * np.log(T_matrix)
    )

    # Choose the minimum G0 value, selecting the right phase
    G0_Ti2O3_ls = np.min(
        np.stack((G0_Ti2O3_s1, G0_Ti2O3_s2, G0_Ti2O3_liquid), axis=2), axis=2
    )

    # Convert units to eV per Ti2O3
    G0_Ti2O3_ls = G0_Ti2O3_ls / (avo * q)  # eV/Ti2O3 molecule

    # Account for P_tot and X_i
    G0_Ti2O3_ls = G0_Ti2O3_ls + kB_eV * T_matrix * np.log(X_i)

    # Set any zero values caused by masking to infinity for obvious errors
    G0_Ti2O3_ls[G0_Ti2O3_ls == 0] = np.inf

    return G0_Ti2O3_ls


'''
%% for referecne, it's nice to copy the original data here in comments to allow proofreading.  For exaple this is the text file from FactSage for H2O.  
% % % 
% % % View Data   Ti2O3     Units:  T(K) P(atm) Energy(J) Quantity(mol) 
% % % Name: titanium sesquioxide
% % % 
% % %   G(T) J/mol - 1 atm  
% % % 
% % %              G(T)                   G(T)                     G(T)                     T(K)        
% % % ____________ ______________________ ________________________ ________________________ ___________ 
% % % 
% % % S1         1 - 1171154.54           + 6399.41546     T       - 9404192.70     T^-1    298 - 470   
% % % S1         1 - 58419.4632     T^0.5 - 730.233813     T ln(T)                          298 - 470   
% % % S1         2 - 1548686.12           + 1157.75518     T       - 804824.470     T^-1    470 - 2115  
% % % S1         2 - 3000.87476     T^0.5 + 260920167.     T^-2    - 169.961109     T ln(T) 470 - 2115  
% % % S1         3 - 1590651.75           + 1012.18648     T       - 156.900000     T ln(T) 2115 - 2500 
% % % S2         4 - 1547548.01           + 1155.33360     T       - 804824.470     T^-1    298 - 2115  
% % % S2         4 - 3000.87476     T^0.5 + 260920167.     T^-2    - 169.961109     T ln(T) 298 - 2115  
% % % S2         5 - 1589513.65           + 1009.76490     T       - 156.900000     T ln(T) 2115 - 2500 
% % % L1         6 - 1442547.94           + 1105.68824     T       - 804824.470     T^-1    298 - 2115  
% % % L1         6 - 3000.87476     T^0.5 + 260920167.     T^-2    - 169.961109     T ln(T) 298 - 2115  
% % % L1         7 - 1484513.58           + 960.119543     T       - 156.900000     T ln(T) 2115 - 2500 
% % % ____________ ______________________ ________________________ ________________________ ___________ 
% % % 
'''
