# This is a subroutine that is called in the main calculation and additional subroutines the main function uses - equalibrium_dark_with_frozen

# EF_Grid_Maker sets up a grid of EF values. Using interval 1/2 of kBT guarantees you can't miss the solution,
#   which should be within kBT/2 of the guess.

import numpy as np

def EF_Grid_Maker(EFGM_conditions):

    EF_inc = EFGM_conditions['kBT_equilibrium'] / 2  # interval = 0.5 * kBT

    # Calculate number of intervals from Ev to Ec, padded on each side by 10 intervals
    total_range = EFGM_conditions['Ec'] - EFGM_conditions['Ev']
    num_steps = int(np.ceil(total_range / EF_inc))
    
    EF_min = EFGM_conditions['Ev'] - 10 * EF_inc
    EF_max = EF_min + (num_steps + 20) * EF_inc  # 10 steps on each side

    # Generate the EF grid using np.arange
    EF_grid = np.arange(EF_min, EF_max + EF_inc / 2, EF_inc)  # Add small buffer to ensure inclusive

    return EF_grid
