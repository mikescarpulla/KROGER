import numpy as np

def G0_Te2_gv(T, P_tot, X_i, P_units):
    # Define constants
    q = 1.602176634e-19
    avo = 6.0221409e+23
    kB_eV = 8.617333262e-5
    
    # Select the Pref for specified units of pressure
    P_ref_dict = {'atm': 1, 'Torr': 760, 'Bar': 1, 'Pa': 1e5}
    if P_units not in P_ref_dict:
        raise ValueError("Units of pressure must be atm, Torr, Pa, or Bar.")
    P_ref = P_ref_dict[P_units]
    
    # Ensure T and P_tot are NumPy arrays and reshape appropriately
    T = np.asarray(T).reshape(-1, 1)  # Make T a column vector
    P_tot = np.asarray(P_tot).reshape(1, -1)  # Make P_tot a row vector
    
    # Expand T and P_tot to 2D arrays for vectorized calculations
    T_mat = np.tile(T, (1, P_tot.shape[1]))
    P_tot_mat = np.tile(P_tot, (T.shape[0], 1))
    G0_Te2_gv = np.zeros_like(T_mat,dtype=float)
    
    # Define masks for temperature ranges
    mask1 = (T_mat >= 298) & (T_mat < 500)
    mask2 = (T_mat >= 500) & (T_mat < 1000)
    mask3 = (T_mat >= 1000) & (T_mat < 2100)
    mask4 = (T_mat >= 2100) & (T_mat <= 3000)
    
    # Calculate G0_Te2_gv using the given equations
    G0_Te2_gv += mask1 * (151341.335 - 19.4485261*T_mat + 7.535e-4*T_mat**2 
                           - 2.725716667e-6*T_mat**3 - 35.7007*T_mat*np.log(T_mat))
    G0_Te2_gv += mask2 * (155262.717 - 103.210571*T_mat - 2.01879e-2*T_mat**2 
                           - 200257.0/T_mat + 3.1063e-6*T_mat**3 - 21.9053*T_mat*np.log(T_mat))
    G0_Te2_gv += mask3 * (133634.827 + 144.999946*T_mat + 7.0228e-3*T_mat**2 
                           + 2176970.0/T_mat - 6.666183333e-7*T_mat**3 - 58.4436*T_mat*np.log(T_mat))
    G0_Te2_gv += mask4 * (152003.363 - 3.80338102*T_mat - 1.801695e-3*T_mat**2 
                           - 38.0321*T_mat*np.log(T_mat))
    
    # Convert units to eV per molecule
    G0_Te2_gv /= (avo * q)
    
    # Adjust for total pressure and composition fraction
    G0_Te2_gv += kB_eV * T_mat * (np.log(P_tot_mat / P_ref) + np.log(X_i))
    
    # Set zero values due to masking to infinity for error indication
    G0_Te2_gv[G0_Te2_gv == 0] = np.inf
    G0_Te2_gv[np.isnan(G0_Te2_gv)] = np.inf
    
    return G0_Te2_gv

'''
View Data: Te2  
Units: T(K), P(atm), Energy(J), Quantity(mol)  

Name: Te2  

G(T) J/mol - 1 atm  

              G(T)                     G(T)                     G(T)                     T(K)        
 ____________ ________________________ ________________________ ________________________ ___________  

G1         1 151341.335               - 19.4485261     T       + 7.535000000E-04 T^2   298 - 500   
G1         1 - 2.725716667E-06 T^3   - 35.7007000     T ln(T)                          298 - 500   
G1         2 155262.717               - 103.210571     T       - 2.018790000E-02 T^2   500 - 1000  
G1         2 - 200257.000     T^-1    + 3.106300000E-06 T^3   - 21.9053000     T ln(T) 500 - 1000  
G1         3 133634.827               + 144.999946     T       + 7.022800000E-03 T^2   1000 - 2100 
G1         3 + 2176970.00     T^-1    - 6.666183333E-07 T^3   - 58.4436000     T ln(T) 1000 - 2100 
G1         4 152003.363               - 3.80338102     T       - 1.801695000E-03 T^2   2100 - 3000 
G1         4 - 38.0321000     T ln(T)                                                   2100 - 3000 
 ____________ ________________________ ________________________ ________________________ ___________  
'''