# This is a subroutine that is called in the main calculation - equalibrium_dark_with_frozen

# Calc_Method a setup utility that determines how the defect equilibrium calculation should be performed based on 
#   whether defects and elements are fixed or open.

import numpy as np

def Calc_Method(CM_conditions, dummy_defects):
    """
    Determine calculation method type (1, 2, 3, or 4) based on whether defects or elements are fixed.
    Modifies and returns the CM_conditions dictionary.
    """

    # check for valid inputs for fixed and open defects and elements
    if len(CM_conditions['fixed_defects']) != dummy_defects['num_defects']:
        raise ValueError("Tloop_conditions['fixed_defects'] has to be same size as num_defects")

    elif len(CM_conditions['fixed_conc_flag']) != dummy_defects['numelements']:
        raise ValueError("Tloop_conditions['fixed_conc_flag'] has to be same size as # elements")

    elif np.sum(CM_conditions['fixed_defects']) != CM_conditions['num_fixed_defects']:
        raise ValueError("Something wrong with number of fixed defects")

    elif np.sum(CM_conditions['fixed_conc_flag']) != CM_conditions['num_fixed_elements']:
        raise ValueError("Something wrong with number of fixed elements")

    # these logic checks figure out how calc will be done

    if np.sum(CM_conditions['fixed_defects']) == 0:  # no defects fixed, all open
        CM_conditions['some_defects_fixed_flag'] = 0
        CM_conditions['fixed_defects_index'] = []
        CM_conditions['num_fixed_defects'] = 0
        # CM_conditions['open_defects_index'] = np.ones_like(CM_conditions['fixed_defects'])
        # CM_conditions['num_open_defects'] = len(CM_conditions['open_defects_index'])

    else:  # some defects have fixed concentration
        CM_conditions['some_defects_fixed_flag'] = 1
        CM_conditions['fixed_defects_index'] = list(np.where(CM_conditions['fixed_defects'] == 1)[0])
        CM_conditions['num_fixed_defects'] = len(CM_conditions['fixed_defects_index'])
        # CM_conditions['open_defects_index'] = list(np.where(CM_conditions['fixed_defects'] == 0)[0])
        # CM_conditions['num_open_defects'] = len(CM_conditions['open_defects_index'])

    if np.sum(CM_conditions['fixed_conc_flag']) == 0:  # no elements fixed, all open (mu set for all)
        CM_conditions['some_elements_fixed_flag'] = 0
        CM_conditions['fixed_elements_index'] = []
        CM_conditions['num_fixed_elements'] = 0
        CM_conditions['open_elements_index'] = np.ones_like(CM_conditions['fixed_conc_flag'])

    else:  # at least one element concentration is set
        CM_conditions['some_elements_fixed_flag'] = 1
        CM_conditions['fixed_elements_index'] = list(np.where(CM_conditions['fixed_conc_flag'] == 1)[0])
        CM_conditions['num_fixed_elements'] = len(CM_conditions['fixed_elements_index'])
        CM_conditions['open_elements_index'] = list(np.where(CM_conditions['fixed_conc_flag'] == 0)[0])

    # determine the calculation method type (1-4)
    if CM_conditions['some_defects_fixed_flag'] == 0 and CM_conditions['some_elements_fixed_flag'] == 0:
        CM_conditions['calc_method'] = 1
    elif CM_conditions['some_defects_fixed_flag'] == 1 and CM_conditions['some_elements_fixed_flag'] == 0:
        CM_conditions['calc_method'] = 2
    elif CM_conditions['some_defects_fixed_flag'] == 0 and CM_conditions['some_elements_fixed_flag'] == 1:
        CM_conditions['calc_method'] = 3
    elif CM_conditions['some_defects_fixed_flag'] == 1 and CM_conditions['some_elements_fixed_flag'] == 1:
        CM_conditions['calc_method'] = 4
    else:
        raise ValueError("Defects and elements must be either fixed or open")

    return CM_conditions
