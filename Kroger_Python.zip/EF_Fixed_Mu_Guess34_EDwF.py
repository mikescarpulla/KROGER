# This is a subroutine that is called in the main calculation - equalibrium_dark_with_frozen

# EF_Fixed_Mu_Guess34 does a grid search in a multi-dimensional space to find a good initial guess for the 
#   Fermi level (EF) and chemical potentials (mu) of fixed elements that minimize the total balance
#   error in a defect system.

# Methods: 
#   Itertools.product() generates all combinations of mu values.
#   We dynamically build the guess vector
#   Overall, a clean and scalable structure that works for any number
#       of fixed elements.

# Needed imports for the function
import numpy as np
from itertools import product
from EF_Grid_Maker_EDwF import EF_Grid_Maker
from Fixed_Mu_Grid_Maker_EDwF import Fixed_Mu_Grid_Maker
from Total_Balance34_EDwF import Total_Balance34

def EF_Fixed_Mu_Guess34(EFFMG34_conditions):
    """
    Grid search the m-dimensional space (m = num fixed elements) to return an EF_fixed_mu_vec guess.
    This guess is sent to the optimizer to get EF and mu values for fixed elements.
    """

    # Set up the EF grid the same way as in EF_Guess12
    EF_grid = EF_Grid_Maker(EFFMG34_conditions)

    # Create search grid for each frozen element
    mu_grid_holder = Fixed_Mu_Grid_Maker(EFFMG34_conditions)  # returns list of 1D numpy arrays

    num_fixed = EFFMG34_conditions['num_fixed_elements']
    tot_bal = float('inf')  # Initialize as infinity so any first value will be smaller
    EF_fixed_mu_guess34 = None  # To be filled with the best guess found

    # Print how many points will be evaluated
    mu_lengths = [len(mu) for mu in mu_grid_holder]
    num_grid_points = len(EF_grid) * np.prod(mu_lengths)
    print(f"Starting grid search over {num_grid_points} points in Ef-mu space")

    # Iterate over EF grid
    for i, ef in enumerate(EF_grid):
        percent_done = (i + 1) / len(EF_grid) * 100
        print(f"{percent_done:.1f}% through initial grid search. Appreciate your patience")

        # Create product of all combinations of fixed mus
        for mu_comb in product(*mu_grid_holder):
            current_EF_fixed_mu_vec = np.array([ef] + list(mu_comb))
            current_tot_bal = Total_Balance34(current_EF_fixed_mu_vec)

            if current_tot_bal < tot_bal:
                EF_fixed_mu_guess34 = current_EF_fixed_mu_vec
                tot_bal = current_tot_bal

    # Handle case of >10 fixed elements
    if num_fixed > 10:
        raise ValueError("More than 10 fixed elements requested — contact developers to add support")

    return EF_fixed_mu_guess34
