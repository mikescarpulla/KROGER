import numpy as np

def CdTe_stoich(solution, conditions, defects):
    """
    Calculate the stoichiometric ratio and element totals for CdTe.

    Parameters:
        solution: Object containing charge states (solution.chargestates as 2D array).
        conditions: Object containing number of sites (conditions.num_sites as a list/array).
        defects: Object containing cs_dm as a 2D array of defect contributions.
        There objects are all python dictionaries

    Returns:
        ratio_stoich: 2D array where each row contains the ratio and Cd/Te stoichiometry.
        element_totals: 2D array with total counts for each element.
    """
    num_entries = solution['chargestates'].shape[0]
    num_Cd = np.zeros(num_entries)
    num_Te = np.zeros(num_entries)
    num_N = np.zeros(num_entries)
    num_P = np.zeros(num_entries)
    num_As = np.zeros(num_entries)
    num_Sb = np.zeros(num_entries)
    num_Cu = np.zeros(num_entries)
    Cd_Te_stoich = np.zeros((num_entries, 2))

    for j in range(num_entries):  # Loop over all entries
        num_Cd[j] = conditions['num_sites'][0] + np.dot(defects['cs_dm'][:, 0], solution['chargestates'][j, :])
        num_Te[j] = conditions['num_sites'][1] + np.dot(defects['cs_dm'][:, 1], solution['chargestates'][j, :])
        num_N[j] = np.dot(defects['cs_dm'][:, 2], solution['chargestates'][j, :])
        num_P[j] = np.dot(defects['cs_dm'][:, 3], solution['chargestates'][j, :])
        num_As[j] = np.dot(defects['cs_dm'][:, 4], solution['chargestates'][j, :])
        num_Sb[j] = np.dot(defects['cs_dm'][:, 5], solution['chargestates'][j, :])
        num_Cu[j] = np.dot(defects['cs_dm'][:, 6], solution['chargestates'][j, :])
        Cd_Te_stoich[j, :] = [num_Cd[j], num_Te[j]] / 1.47e22

    ratio = Cd_Te_stoich[:, 1] / (Cd_Te_stoich[:, 0] + Cd_Te_stoich[:, 1])
    ratio_stoich = np.column_stack((ratio, Cd_Te_stoich))

    element_totals = np.column_stack((num_Cd, num_Te, num_N, num_P, num_As, num_Sb, num_Cu))

    return ratio_stoich, element_totals