import numpy as np
from n_Fermi_Dirac import n_Fermi_Dirac

# Function to compute n and p.
# Input must be EF only (scalar, not vector with mus attached)
def fullquench_carrier_concentrations(EF_dummy, conditions_dummy, defects_dumy=None):
    # Calculate normalized energies
    etaCB = (EF_dummy - conditions_dummy['EcT_fullquench']) / conditions_dummy['kBT_fullquench']
    etaVB = (EF_dummy - conditions_dummy['EvT_fullquench']) / conditions_dummy['kBT_fullquench']
    # This looks wrong (not symmetric compared to CB case) but it is right.
    # Direction of integration and sign on EF - Ev are both swapped.
    etaSTH1 = (EF_dummy - (conditions_dummy['EvT_fullquench'] + conditions_dummy['E_relax_sth1'])) / conditions_dummy['kBT_fullquench']
    etaSTH2 = (EF_dummy - (conditions_dummy['EvT_fullquench'] + conditions_dummy['E_relax_sth2'])) / conditions_dummy['kBT_fullquench']

    if conditions_dummy['Boltz_or_FD_flag'] == 'FD':
        # Use Fermi-Dirac integrals so degenerate conditions handled correctly
        n = n_Fermi_Dirac(etaCB, conditions_dummy['NcT_fullquench'])
        p = n_Fermi_Dirac(-etaVB, conditions_dummy['NvT_fullquench'])
        sth1 = conditions_dummy['sth_flag'] * n_Fermi_Dirac(-etaSTH1, conditions_dummy['num_sites'][2])
        sth2 = conditions_dummy['sth_flag'] * n_Fermi_Dirac(-etaSTH2, conditions_dummy['num_sites'][3])
    elif conditions_dummy['Boltz_or_FD_flag'] == 'Boltz':
        # Use just Boltzmann approx
        n = conditions_dummy['NcT_fullquench'] * np.exp(etaCB)  # Boltzmann factors should end up <1 when EF is in gap
        p = conditions_dummy['NvT_fullquench'] * np.exp(-etaVB)
        sth1 = conditions_dummy['sth_flag'] * conditions_dummy['num_sites'][2] * np.exp(-etaSTH1)
        sth2 = conditions_dummy['sth_flag'] * conditions_dummy['num_sites'][3] * np.exp(-etaSTH2)
    else:
        raise ValueError("Boltz_or_FD_flag must be 'Boltz' or 'FD'")

    return n, p, sth1, sth2
