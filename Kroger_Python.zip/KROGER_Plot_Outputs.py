import numpy as np
import matplotlib.pyplot as plt
import mplcursors
import global_data

# Reference the data structure to the global database
conditions = global_data.conditions
defects = global_data.defects
equilib_dark_sol = global_data.equilib_dark_sol
fullquench_dark_sol = global_data.fullquench_dark_sol


# %% Plotting Script Conversion
# Only generate figures if flagged on
if conditions['figures_flag'] == 'On':
    # Clear all figures 1 through 7
    for i in range(1, 8):
        plt.figure(i)
        plt.clf()

    # %% Plot Formation enthalpies vs EF at 300 K
    plt.figure(1)
    EF = np.linspace(0, conditions['EgRef'], 101)
    # dH_EF0 = cs_dHo - cs_dm * muT_equilibrium(1, :)'
    dH_EF0 = defects['cs_dHo'] - defects['cs_dm'].dot(conditions['muT_equilibrium'][0, :])
    f1_lines = []
    for i in range(defects['num_chargestates']):
        line, = plt.plot(
            EF,
            dH_EF0[i] + defects['cs_charge'][i] * EF,
            label=defects['chargestate_names'][i]
        )
        f1_lines.append(line)
    plt.legend()
    plt.title(
        f"300 K Formation Enthalpies of Defects for μ_Cd={conditions['muT_equilibrium'][0,0]}"
        f" and μ_Te={conditions['muT_equilibrium'][0,1]}"
    )
    plt.xlabel('EF (eV)')
    plt.ylabel('Formation Enthalpy (eV)')
    mplcursors.cursor(f1_lines, hover=True)

    # %% plot total defect concentrations
    plt.figure(2)
    f2_lines = []
    # equilibrium n, p
    f2_lines.append(
        plt.plot(
            conditions['T_equilibrium'],
            np.log10(equilib_dark_sol['n']),
            'o', label='n equilib',
            markeredgecolor='r', markerfacecolor='r'
        )[0]
    )
    f2_lines.append(
        plt.plot(
            conditions['T_equilibrium'],
            np.log10(equilib_dark_sol['p']),
            'o', label='p equilib',
            markeredgecolor='b', markerfacecolor='b'
        )[0]
    )
    if conditions['sth_flag'] == 1:
        # sth1, sth2, |Nd-Na|, and quench series
        f2_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(equilib_dark_sol['sth1']), 'o', label='sth1 equilib')[0])
        f2_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(equilib_dark_sol['sth2']), 'o', label='sth2 equilib')[0])
        f2_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(np.abs(equilib_dark_sol['Nd'] - equilib_dark_sol['Na'])), 'k-', label='|Nd-Na|')[0])
        f2_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(fullquench_dark_sol['n']), 'o', label='n quench', markeredgecolor='r')[0])
        f2_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(fullquench_dark_sol['p']), 'o', label='p quench', markeredgecolor='b')[0])
        f2_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(fullquench_dark_sol['sth1']), 'o', label='sth1 quench', markeredgecolor='g')[0])
        f2_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(fullquench_dark_sol['sth2']), 'o', label='sth2 quench', markeredgecolor='g')[0])
        # defect species over threshold
        for i in range(defects['num_defects']):
            if np.max(np.log10(equilib_dark_sol['defects'][:, i])) >= conditions['plot_log10_min']:
                line, = plt.plot(
                    conditions['T_equilibrium'],
                    np.log10(equilib_dark_sol['defects'][:, i]),
                    label=defects['defect_names'][i]
                )
                f2_lines.append(line)
    else:
        # no sth
        f2_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(np.abs(equilib_dark_sol['Nd'] - equilib_dark_sol['Na'])), 'k-', label='|Nd-Na|')[0])
        f2_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(fullquench_dark_sol['n']), 'o', label='n quench', markeredgecolor='r')[0])
        f2_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(fullquench_dark_sol['p']), 'o', label='p quench', markeredgecolor='b')[0])
        for i in range(defects['num_defects']):
            if np.max(np.log10(equilib_dark_sol['defects'][:, i])) >= conditions['plot_log10_min']:
                line, = plt.plot(
                    conditions['T_equilibrium'],
                    np.log10(equilib_dark_sol['defects'][:, i]),
                    label=defects['defect_names'][i]
                )
                f2_lines.append(line)
    plt.legend()
    plt.title('Concentrations at Equilibrium Temperature K')
    plt.xlabel('Equilibrium T (K)')
    plt.ylabel('Log10 Concentrations (#/cm3)')
    plt.ylim(conditions['plot_log10_min'], conditions['plot_log10_max'])
    plt.xlim(min(conditions['T_equilibrium']), max(conditions['T_equilibrium']))
    mplcursors.cursor(f2_lines, hover=True)

    # %% plot all chargestates for equilibrium
    plt.figure(3)
    f3_lines = []
    f3_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(equilib_dark_sol['n']), 'o', label='n equilib', markeredgecolor='r', markerfacecolor='r')[0])
    f3_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(equilib_dark_sol['p']), 'o', label='p equilib', markeredgecolor='b', markerfacecolor='b')[0])
    if conditions['sth_flag'] == 1:
        f3_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(equilib_dark_sol['sth1']), 'o', label='sth1 equilib')[0])
        f3_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(equilib_dark_sol['sth2']), 'o', label='sth2 equilib')[0])
        f3_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(np.abs(equilib_dark_sol['Nd'] - equilib_dark_sol['Na'])), 'k-', label='|Nd-Na|')[0])
        f3_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(fullquench_dark_sol['n']), 'o', label='n quench', markeredgecolor='r')[0])
        f3_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(fullquench_dark_sol['p']), 'o', label='p quench', markeredgecolor='b')[0])
        f3_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(fullquench_dark_sol['sth1']), 'o', label='sth1 quench', markeredgecolor='g')[0])
        f3_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(fullquench_dark_sol['sth2']), 'o', label='sth2 quench', markeredgecolor='g')[0])
        for i in range(defects['num_chargestates']):
            if np.max(np.log10(equilib_dark_sol['chargestates'][:, i])) >= conditions['plot_log10_min']:
                line, = plt.plot(
                    conditions['T_equilibrium'],
                    np.log10(equilib_dark_sol['chargestates'][:, i]),
                    label=defects['chargestate_names'][i]
                )
                f3_lines.append(line)
    else:
        f3_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(np.abs(equilib_dark_sol['Nd'] - equilib_dark_sol['Na'])), 'k-', label='|Nd-Na|')[0])
        f3_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(fullquench_dark_sol['n']), 'o', label='n quench', markeredgecolor='r')[0])
        f3_lines.append(plt.plot(conditions['T_equilibrium'], np.log10(fullquench_dark_sol['p']), 'o', label='p quench', markeredgecolor='b')[0])
        for i in range(defects['num_chargestates']):
            if np.max(np.log10(equilib_dark_sol['chargestates'][:, i])) >= conditions['plot_log10_min']:
                line, = plt.plot(
                    conditions['T_equilibrium'],
                    np.log10(equilib_dark_sol['chargestates'][:, i]),
                    label=defects['chargestate_names'][i]
                )
                f3_lines.append(line)
    plt.legend()
    mplcursors.cursor(f3_lines, hover=True)

    # %% Plot band diagram vs T: Ec, Ev, EFn vs T
    plt.figure(5)
    plt.plot(conditions['T_equilibrium'], equilib_dark_sol['EFn'], 'r-')
    plt.plot(conditions['T_equilibrium'], fullquench_dark_sol['EFn'], '--r')
    if conditions['T_dep_bands_flag'] == 'On':
        plt.plot(conditions['T_equilibrium'], conditions['EcT_equilibrium'], 'k-')
        plt.plot(conditions['T_equilibrium'], conditions['EvT_equilibrium'], 'k-')
        plt.plot(conditions['T_equilibrium'], [conditions['EcRef']]*len(conditions['T_equilibrium']), 'k--')
        plt.plot(conditions['T_equilibrium'], [conditions['EvRef']]*len(conditions['T_equilibrium']), 'k--')
        plt.legend([
            'EF(T_Equilib)', 'EF(T_Quench)',
            'Ec(T_Equilib)', 'Ev(T_Equilib)',
            'Ec(T_Quench)', 'Ev(T_Quench)'
        ])
    elif conditions['T_dep_bands_flag'] == 'Off':
        plt.plot(conditions['T_equilibrium'], [conditions['EcRef']]*len(conditions['T_equilibrium']), 'k--')
        plt.plot(conditions['T_equilibrium'], [conditions['EvRef']]*len(conditions['T_equilibrium']), 'k--')
        plt.legend(['EF(T_Equilib)', 'EF(T_Quench)', 'Ec', 'Ev'])
    else:
        raise ValueError("conditions['T_dep_bands_flag'] must be 'On' or 'Off'")
    plt.title('Fermi Levels for Equilibrium and Quenching vs T')
    plt.xlabel('Equilibrium T (K)')
    plt.ylabel('Energies (eV)')

    # %% Plot the mu values for the solution
    plt.figure(6)
    f6_lines = []
    for i in range(defects['numelements']):
        line, = plt.plot(
            conditions['T_equilibrium'],
            equilib_dark_sol['mu'][:, i],
            label=defects['elementnames'][i]
        )
        f6_lines.append(line)
    plt.title('Chemical Potentials for Elements at Equilibrium vs T')
    plt.legend()
    plt.xlabel('Equilibrium T (K)')
    plt.ylabel('Chem Potentials (eV)')
    plt.ylim(-12, 0)
    mplcursors.cursor(f6_lines, hover=True)

    # %% plot the stoichiometry from equilibrium
    plt.figure(7)
    f7_lines = []
    for i in range(conditions['num_elements']):
        line, = plt.plot(
            conditions['T_equilibrium'],
            np.log10(equilib_dark_sol['element_totals'][:, i]),
            label=defects['elementnames'][i]
        )
        f7_lines.append(line)
    plt.title('Atomic Concentrations')
    plt.legend()
    plt.xlabel('Equilibrium T (K)')
    plt.ylabel('Log10 Concentrations (#/cm3)')
    plt.ylim(conditions['plot_log10_min'], conditions['plot_log10_max'])
    mplcursors.cursor(f7_lines, hover=True)

    # %% analyze distribution of each fixed element
    for idx in conditions['indices_of_fixed_elements']:
        plt.figure(7 + idx)
        plt.clf()
        plt.title('Fraction of Element in Defects')
        plt.xlabel('Equilibrium T (K)')
        plt.ylabel('Fraction of Element in Each Defect')
        plt.ylim(0, 1)

        # contains_element should return (fractions, _, names, _)
        fracs, _, names, _ = contains_element(
            equilib_dark_sol, defects, idx
        )
        lines = []
        for j in range(fracs.shape[1]):
            line, = plt.plot(
                equilib_dark_sol['T_equilibrium'],
                fracs[:, j],
                label=names[j]
            )
            lines.append(line)
        plt.legend()
        mplcursors.cursor(lines, hover=True)
