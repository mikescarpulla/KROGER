import numpy as np
from Chargestate_Concentrations_EDwF import Chargestate_Concentrations
from Expand_Fixed_Mu_Vec_To_Full_Mu_Vec_EDwF import Expand_Fixed_Mu_Vec_To_Full_Mu_Vec

def Fixed_Element_Balance34(EF_fixed_mu_vec_dummy,Tloop_conditions,dummy_defects):
    """
    Returns a vector of the signed difference between fixed element
    concentrations and their target values, only for the fixed elements.

    The result is masked by the fixed concentration flags so only relevant
    element balances are reported (ignores substitutional/mixed elements
    where masking avoids double counting).
    """

    # Expand the reduced EF+mu vector to the full vector
    EF_full_mu_vec_dummy = Expand_Fixed_Mu_Vec_To_Full_Mu_Vec(EF_fixed_mu_vec_dummy)

    # Calculate the defect charge state concentrations
    N_chargestates = Chargestate_Concentrations(EF_full_mu_vec_dummy)

    # Compute imbalance only for fixed elements using matrix multiplication.
    # Rotate and reshape arrays to match dimensions properly, then mask using fixed_conc_flag.
    fixed_element_bal34_vec = (
        (np.dot(dummy_defects['cs_dm'].T, N_chargestates.T).T - Tloop_conditions['fixed_conc_values'])
        * Tloop_conditions['fixed_conc_flag']
    )

    return fixed_element_bal34_vec
