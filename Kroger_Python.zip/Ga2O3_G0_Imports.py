# This file contains all the imports for the thermodynamic
#   functions (calculating Gibbs Energy) associated with Ga2O3.
# Its function is to allow for a single line to be called in
#   scripts that rely on these functions.
# To call these functions in a script use: "from Ga2O3_G0_Imports import *"

from G0_ZrO2_ls import G0_ZrO2_ls
from G0_ZrO2_gv import G0_ZrO2_gv
from G0_TiO_ls import G0_TiO_ls
from G0_TiO_gv import G0_TiO_gv
from G0_TiO2_ls import G0_TiO2_ls
from G0_TiO2_gv import G0_TiO2_gv
from G0_Ti2O3_ls import G0_Ti2O3_ls
from G0_SnO_ls import G0_SnO_ls
from G0_SnO_gv import G0_SnO_gv
from G0_SnO2_ls import G0_SnO2_ls
from G0_SnO2_gv import G0_SnO2_gv
from G0_SiO_gv import G0_SiO_gv
from G0_SiO2_ls import G0_SiO2_ls
from G0_RhO_ls import G0_RhO_ls
from G0_RhO_gv import G0_RhO_gv
from G0_RhO2_ls import G0_RhO2_ls
from G0_RhO2_gv import G0_RhO2_gv
from G0_Rh_ls import G0_Rh_ls
from G0_Rh2O_ls import G0_Rh2O_ls
from G0_Rh2O3_ls import G0_Rh2O3_ls
from G0_PtO2_gv import G0_PtO2_gv
from G0_Pt_ls import G0_Pt_ls
from G0_O2_gv import G0_O2_gv
from G0_MgO_ls import G0_MgO_ls
from G0_MgO_gv import G0_MgO_gv
from G0_IrO3_gv import G0_IrO3_gv
from G0_IrO2_ls import G0_IrO2_ls
from G0_IrO2_gv import G0_IrO2_gv
from G0_HfO2_ls import G0_HfO2_ls
from G0_H2O_ls import G0_H2O_ls
from G0_H2O_gv import G0_H2O_gv
from G0_GaO_gv import G0_GaO_gv
from G0_Ga_ls import G0_Ga_ls
from G0_Ga_gv import G0_Ga_gv
from G0_Ga2O_gv import G0_Ga2O_gv
from G0_Ga2O3_ls import G0_Ga2O3_ls
from G0_FeO_ls import G0_FeO_ls
from G0_Fe3O4_ls import G0_Fe3O4_ls
from G0_Fe2O3_ls import G0_Fe2O3_ls
from G0_CrO_ls import G0_CrO_ls
from G0_CrO_gv import G0_CrO_gv
from G0_CrO2_ls import G0_CrO2_ls
from G0_CrO2_gv import G0_CrO2_gv
from G0_Cr3O4_ls import G0_Cr3O4_ls
from G0_Cr2O3_ls import G0_Cr2O3_ls
from G0_CaO_ls import G0_CaO_ls
from G0_CaO_gv import G0_CaO_gv
