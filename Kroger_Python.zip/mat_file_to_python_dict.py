# Use: This is a very important function because it converts a defects
#   .mat file (structure) into a dictionary which python can use in the same way
#    that matlab uses a structure. 
# Inputs: The input to this function is the PATH on YOUR COMPUTER to the .mat file
#    you want to convert
# Ouputs: The output to this function is a dictionary that resembles the original 
#   Matlab structure. 
# This particular conversion is used as an example and to make sure its done correctly

import scipy.io as sio
import numpy as np
def mat_file_to_python_dict(file_path):
    # Fix the file path issue using raw string notation (Solution 1)

    # Load the .mat file
    mat_data = sio.loadmat(file_path, struct_as_record=False, squeeze_me=True)

    # Function to recursively convert MATLAB structs to Python dictionaries
    def mat_struct_to_dict(mat_obj):
        """Recursively convert MATLAB structures to Python dictionaries."""
        if isinstance(mat_obj, sio.matlab.mat_struct):  # Convert MATLAB struct
            return {key: mat_struct_to_dict(value) for key, value in mat_obj.__dict__.items() if not key.startswith('_')}
        elif isinstance(mat_obj, dict):  # Convert dictionary elements
            return {key: mat_struct_to_dict(value) for key, value in mat_obj.items()}
        elif isinstance(mat_obj, np.ndarray):  # Convert arrays
            if mat_obj.size == 1:
                return mat_struct_to_dict(mat_obj.item())  # Extract single-element arrays
            else:
                return [mat_struct_to_dict(el) for el in mat_obj]  # Convert arrays into lists of dictionaries
        else:
            return mat_obj

    # Convert the 'defects' structure into a Python dictionary
    if 'defects' in mat_data:
        defects_dict = mat_struct_to_dict(mat_data['defects'])
    else:
        defects_dict = {}

    return defects_dict  # Now, `defects_dict` is a fully converted dictionary!