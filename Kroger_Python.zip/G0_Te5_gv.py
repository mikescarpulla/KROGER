import numpy as np

def G0_Te5_gv(T, P_tot, X_i, P_units):
    # Define constants
    q = 1.602176634e-19
    avo = 6.0221409e+23
    kB_eV = 8.617333262e-5

    # Select the Pref for specified units of pressure
    if P_units == 'atm':
        P_ref = 1
    elif P_units == 'Torr':
        P_ref = 760
    elif P_units == 'Bar':
        P_ref = 1
    elif P_units == 'Pa':
        P_ref = 1e5
    else:
        raise ValueError('Units of pressure must be atm, Torr, Pa, or Bar, or you need to add more units with corresponding Pref in the file')

    # Work with T and P if they come in as column or row vectors
    T = np.array(T).reshape(-1, 1)  # Make T a column vector
    nT = T.shape[0]
    P_tot = np.array(P_tot).reshape(1, -1)  # Make P a row vector
    nP = P_tot.shape[1]

    # Shape T and P to both be 2D arrays so that all calculations are vectorized
    T = T * np.ones((1, nP))  # Expand T
    P_tot = np.ones((nT, 1)) * P_tot  # Expand P_tot
    G0_Te5_gv = np.zeros_like(T)

    # Define masks based on temperature ranges
    mask1 = (T >= 298) & (T <= 1500)

    # Calculate G0_Te5_gv for the given range
    G0_Te5_gv += mask1 * (187116.902 + 262.128648 * T - 1.964374304e-4 * T**2 
                          + 107727.386 * T**-1 + 5.160401344e-8 * T**3 
                          - 6.972537041e-12 * T**4 - 107.906525 * T * np.log(T))

    # Convert units to eV per Ga2O
    G0_Te5_gv = G0_Te5_gv / (avo * q)  # eV/Ga2O molecule

    # Now take P_tot and X_i into account
    G0_Te5_gv += kB_eV * T * (np.log(P_tot / P_ref) + np.log(X_i))

    # Set any values that are zero due to masking to infinity so it produces an obvious error
    G0_Te5_gv[G0_Te5_gv == 0] = np.inf
    G0_Te5_gv[np.isnan(G0_Te5_gv)] = np.inf

    return G0_Te5_gv

# % View Data  Te5     Units:  T(K) P(atm) Energy(J) Quantity(mol) 
# % Name: tellurium
# %
# %   G(T) J/mol - 1 atm  
# %
# %              G(T)                     G(T)                   G(T)                   T(K)       
# % ____________ ________________________ ______________________ ______________________ __________ 
# %
# % G1         1 187116.902               + 262.128648     T     - 1.964374304E-04 T^ 2 298 - 1500 
# % G1         1 + 107727.386     T^-1    + 5.160401344E-08 T^ 3 - 6.972537041E-12 T^ 4 298 - 1500 
# % G1         1 - 107.906525     T ln(T)                                               298 - 1500 
# % ____________ ________________________ ______________________ ______________________ __________ 
