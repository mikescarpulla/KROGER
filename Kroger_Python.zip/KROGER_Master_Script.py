# You are on the master script page, this page acts as the oversight for the full calcualtion. Each script is called sequentially
#   and the full calcuation is run and the outputs are saved and shown. 

#
# TO DO: We were trying to find or make  impurity_mu_limit_imposed_by_pO2

# Create the global data base, this will hold dictionaries and other variables that get changed throughout the full calculation
import global_data

#%% CdTe - These call scripts of the same name. Edit them to control the desired calculation.
# Uncomment and import modules as needed for CdTe calculations.
# from KROGER_Load_CdTe_Database_and_Calc_Settings import main as load_cdte_database_and_settings
# from KROGER_Set_CdTe_Thermo_Conditions import main as set_cdte_thermo_conditions
# from KROGER_Set_CdTe_Material_Conditions import main as set_cdte_material_conditions
# from KROGER_Set_CdTe_Defect_Conditions import main as set_cdte_defect_conditions

# load_cdte_database_and_settings()
# set_cdte_thermo_conditions()  # Includes temperature vector so it needs to come before material and defects
# set_cdte_material_conditions()
# set_cdte_defect_conditions()

#%% Ga2O3 - These call scripts of the same name. Edit them to control the desired calculation.
import KROGER_Load_Ga203_Database_and_Calc_Settings 
import KROGER_Set_Ga2O3_Thermo_Conditions
import KROGER_Set_Ga2O3_Material_Conditions 
import KROGER_Set_Ga2O3_Defect_Conditions

KROGER_Load_Ga203_Database_and_Calc_Settings()
KROGER_Set_Ga2O3_Thermo_Conditions()
KROGER_Set_Ga2O3_Material_Conditions()
KROGER_Set_Ga2O3_Defect_Conditions()

#%% Perform the calculation, post-process results, save, and plot.

import KROGER_Validate_and_Save_Conditions_Do_Calculations 
# chargestateanalysis addition
import KROGER_Save_Full_Equlibrium_Outputs
import KROGER_Save_Full_Quench_Outputs
import KROGER_Plot_Outputs # you'll need to install mpl cursors with: pip install mplcursors

KROGER_Validate_and_Save_Conditions_Do_Calculations()
KROGER_Save_Full_Equlibrium_Outputs()
KROGER_Save_Full_Quench_Outputs()
KROGER_Plot_Outputs()
