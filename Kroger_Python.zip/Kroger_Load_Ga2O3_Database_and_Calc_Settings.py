import os
import scipy.io
from datetime import datetime

# Set Physical Constants
conditions = {
    "q": 1.602176565e-19,
    "h": 6.62606957e-34,
    "kB": 8.6173324e-5,
    "mo": 9.1093837e-31,
}

# Set problem definition and calculation details

# Select the .mat file database of defect properties and load it
conditions["defect_db_fname"] = ""
conditions["defect_db_pname"] = ""
# User selection is commented out; manual setting instead
# conditions["defect_db_fname"] = "Intuon_CdTe_09152024.mat"
conditions["defect_db_fname"] = "Ga2O3_Varley_all_defects_new_072924.mat"

if not conditions["defect_db_fname"]:
    conditions["defect_db_fname"] = "Ga2O3_Varley_all_defects_new_072924.mat"

if not conditions["defect_db_pname"]:
    conditions["defect_db_pname"] = os.getcwd() + os.sep

# Load .mat file
defects = scipy.io.loadmat(os.path.join(conditions["defect_db_pname"], conditions["defect_db_fname"]))

defect_db_name_root = conditions["defect_db_fname"].rsplit('.', 1)[0]

if len(defects.keys()) < 18:
    raise ValueError("Defects database file seems to be missing some required parts - carefully check it and try again")

# Modify defect database values on the fly (example modification)
# Manually change dHo for Vga and complexes
for ii in list(range(38, 244)) + list(range(252, 560)) + list(range(568, 606)) + list(range(632, 676)):
    defects["cs_dHo"][ii] -= 0.5

# Choose folder and base filename to save calculation run outputs
save_fname_root = ""
save_fname_root_length = len(save_fname_root)

if not save_fname_root:
    save_fname_root = defect_db_name_root + "_" + datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    conditions["save_pname"] = conditions["defect_db_pname"]
elif save_fname_root[-4] == ".":
    save_fname_root = save_fname_root[:-4]
    conditions["save_pname"] = conditions["defect_db_pname"]

conditions.update({
    "conditions_save_fname": save_fname_root + "_calculation_conditions",
    "equilib_save_fname": save_fname_root + "_equilib_dark_sol",
    "fullquench_save_fname": save_fname_root + "_fullquench_dark_sol",
    "elements_save_fname": save_fname_root + "_element_totals",
    "grouping_save_fname": save_fname_root + "_grouped_defects",
})

# Calc and Display Options
conditions.update({
    "plot_log10_min": 12,
    "plot_log10_max": 20,
    "save_min": 1e12,
    "stoich_flag": "Ga2O3",
    "save_files_flag": "Sig_Only",
    "defect_group_flag": "Off",
    "Boltz_or_FD_flag": "FD",
    "site_blocking_flag": "Off",
    "vib_ent_flag": "Quantum",
    "T_dep_bands_flag": "On",
    "sth_flag": 0,
    "E_relax_sth1": 0.0,
    "E_relax_sth2": 0.0,
    "T_dep_matrix_mu_flag": "On",
    "T_dep_fixed_defect_flag": "Off",
    "paraequilibrium_flag": "On",
    "fullquench_EF_search_step_divisor": 5,
    "search_method_flag": "particleswarm_pattern_simplex"
})

if conditions["search_method_flag"] == "grid_fminsearch":
    conditions.update({
        "fixed_elements_fmin_MaxFunEvals": 1e5,
        "fixed_elements_fmin_MaxIter": 1e5,
        "fixed_elements_fmin_TolX": 1e-4,
        "fixed_elements_fmin_TolFun": 1e-4,
    })

elif conditions["search_method_flag"] in ["particleswarm_pattern", "particleswarm_pattern_simplex"]:
    conditions.update({
        "fixed_elements_swarm_iterlimit_base": 20,
        "fixed_elements_swarm_stall_lim": 15,
        "fixed_elements_swarm_display_int": 5,
        "fixed_elements_swarm1_fine_factor": 3,
        "fixed_elements_swarm1_min_size": 350,
        "fixed_elements_swarm1_max_size": 15000,
        "fixed_elements_swarm2_fine_factor": 3,
        "fixed_elements_swarm2_search_band_kB": 2,
        "fixed_elements_swarm2_min_size": 300,
        "fixed_elements_swarm2_max_size": 15000,
    })
    
    if conditions["search_method_flag"] == "particleswarm_pattern_simplex":
        conditions.update({
            "fixed_elements_fmin_MaxFunEvals": 1e4,
            "fixed_elements_fmin_MaxIter": 7500,
            "fixed_elements_fmin_TolX": 1e-5,
            "fixed_elements_fmin_TolFun": 1e-5,
        })
