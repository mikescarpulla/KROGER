import numpy as np

def n_Fermi_Dirac(eta, Nc3D):
    """
    Computes carrier density using the full Fermi-Dirac integral for a 3D density of states.

    Parameters:
        eta: array-like or scalar
            Eta is defined as (Ef - Ec) / kBT. It can be a vector or scalar.
        Nc3D: float
            3D density of states, computed as:
            Nc3D = (1e-6) * 2 * ((2 * pi * mstar * kBeV * q * T) / h^2)^(3/2)

    Returns:
        nFD: array-like
            Carrier density using the Fermi-Dirac integral.
        nBoltz: array-like
            Carrier density using the Boltzmann approximation.
    """
    aj = 1 / 2  # FD integral of 1/2 order

    if np.isscalar(eta):
        ans = Fermi_Dirac(aj, eta)
        nFD = 2 / np.sqrt(np.pi) * Nc3D * ans
        nBoltz = Nc3D * np.exp(eta)
    else:
        ans = np.zeros_like(eta)
        for i in range(len(eta)):
            ans[i] = Fermi_Dirac(1 / 2, eta[i])

            nFD = 2 / np.sqrt(np.pi) * Nc3D * ans
            nBoltz = Nc3D * np.exp(eta)

    return nFD, nBoltz


def Fermi_Dirac(aj, eta):
    """
    Computes the half-order Fermi-Dirac integral using trapezoidal integration with residue correction.

    Parameters:
        aj: float
            Half-order of the Fermi-Dirac integral (e.g., -1/2, 1/2, 3/2, 5/2).
        eta: float
            Eta value, defined as (Ef - Ec) / kBT.

    Returns:
        FD_int: float
            The computed Fermi-Dirac integral value.
    """
    # Program begins
    range_val = 8.0
    if eta > 0.0:
        range_val = np.sqrt(eta + 64.0)

    h = 0.5
    nmax = int(range_val / h)
    sum_val = 0.0

    if aj == -0.5:
        sum_val = 1.0 / (1.0 + np.exp(-eta))

    for i in range(1, nmax + 1):
        u = i * h
        ff = 2.0 * (u ** (2.0 * aj + 1)) / (1.0 + np.exp(u * u - eta))
        sum_val += ff

    # Pole correction for trapezoidal sum
    pol = 0.0
    npole = 0
    bk1 = 0
    while bk1 <= 14.0 * np.pi:
        npole += 1
        bk = (2 * npole - 1) * np.pi
        rho = np.sqrt(eta * eta + bk * bk)

        if eta < 0:
            tk = -aj * (np.arctan(-bk / eta) + np.pi)
        elif eta == 0:
            tk = 0.5 * np.pi * aj
        else:
            tk = aj * np.arctan(bk / eta)

        rk = -(rho ** aj)
        tk += 0.5 * np.arctan(0.0)

        if eta < 0:
            rk = -rk

        ak = (2.0 * np.pi / h) * np.sqrt(0.5 * (rho + eta))
        bk1 = (2.0 * np.pi / h) * np.sqrt(0.5 * (rho - eta))

        if bk1 <= (14.0 * np.pi):
            gama = np.exp(bk1)
            t1 = gama * np.sin(ak + tk) - np.sin(tk)
            t2 = 1.0 - 2.0 * gama * np.cos(ak) + gama * gama
            pol += 4.0 * np.pi * rk * t1 / t2

    FD_int = sum_val * h + pol
    return FD_int
