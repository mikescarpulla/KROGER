import numpy as np
from Dirac_Delta_w0_dSvib_EDwF import Dirac_Delta_w0_dSvib

def Quantum_dSvib(TempK, w0_added, w0_removed, dummy_defects):
    """
    Computes the quantum vibrational entropy difference (ΔS_vib) for adding and
    removing phonon modes while forming a charge state.

    Parameters:
    - TempK: scalar temperature in Kelvin
    - w0_added: 2D array (rows = charge states) of frequencies (Hz) added
    - w0_removed: 2D array (rows = charge states) of frequencies (Hz) removed
    - dummy_defects: dict that must contain 'num_chargestates'

    Modes are treated as Dirac delta peaks in the phonon density of states.
    Returns a column vector (NumPy array) of ΔS_vib values.
    """

    hbar = 1.05457182e-34  # Planck's constant over 2π [J·s]
    kB = 1.380649e-23      # Boltzmann constant [J/K]

    dSvib = np.zeros((dummy_defects['num_chargestates'], 1))

    for i in range(dummy_defects['num_chargestates']):
        # Extract non-zero frequency values for the i-th charge state
        w_added_row = w0_added[i, :]
        w_removed_row = w0_removed[i, :]

        x_added_vec = hbar * w_added_row[w_added_row != 0] / (kB * TempK)
        x_removed_vec = hbar * w_removed_row[w_removed_row != 0] / (kB * TempK)

        # Calculate ΔS_vib using Dirac delta entropy approximation
        dSvib[i] = Dirac_Delta_w0_dSvib(x_added_vec) - Dirac_Delta_w0_dSvib(x_removed_vec)

    return dSvib
