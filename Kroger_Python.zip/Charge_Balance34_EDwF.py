from Carrier_Concentrations_EDwF import Carrier_Concentrations
from Expand_Fixed_Mu_Vec_To_Full_Mu_Vec_EDwF import Expand_Fixed_Mu_Vec_To_Full_Mu_Vec
from Chargestate_Concentrations_EDwF import Chargestate_Concentrations
import numpy as np

def Charge_Balance34(EF_fixed_mu_vec_dummy, Tloop_conditions, dummy_defects):
    """
    Function to calculate signed charge balance for methods 3 and 4.
    This gets called a lot, so don't put any logic checks inside—
    do checking outside before calling this.
    """

    # Deal with carriers first using only EF (the first value in the vector)
    n, p, sth1, sth2 = Carrier_Concentrations(EF_fixed_mu_vec_dummy[0])

    # Expand the reduced mu vector to the full EF_mu vector before defect calculations
    EF_full_mu_vec_dummy = Expand_Fixed_Mu_Vec_To_Full_Mu_Vec(EF_fixed_mu_vec_dummy)

    # Calculate charged defect state concentrations from full EF_mu vector
    N_chargestates = Chargestate_Concentrations(EF_full_mu_vec_dummy)

    # Compute the total signed charge balance (absolute)
    charge_bal34 = (
        np.sum(dummy_defects['cs_charge'] * N_chargestates.T)
        + p + sth1 + sth2 - n
        + Tloop_conditions['Nd'] - Tloop_conditions['Na']
    )

    # Alternative (commented out) version from original MATLAB code
    # charge_bal34 = (
    #     (np.sum(dummy_defects['cs_charge'] * N_chargestates.T) + p - n + Tloop_conditions['Nd'] - Tloop_conditions['Na'])
    #     / np.sqrt(Tloop_conditions['Nc'] * Tloop_conditions['Nv'])
    # )

    return charge_bal34
