import numpy as np
from fullquench_charge_bal_DFD import fullquench_charge_bal

# Function that uses grid search to get EF close to the charge balance solution.
# It will output two values for EF that bracket the solution unless something is strange
# about the charge_bal vs EF (i.e., it's not monotonic).
# Could change this to just guess based on net doping rather than grid search.

def FQ_EF_guess(conditions_dummy):
    # keep kBT and Eg as local variables in this function

    EF_int = conditions_dummy['kBT_fullquench'] / conditions_dummy['fullquench_EF_search_step_divisor']  
    # This guarantees you can't miss the solution, which should be within kBT/2 of the guess

    # This makes a grid to check over the range -5kBT to Eg+5kBT.
    # This is ok since we have Fermi-Dirac stats
    start = conditions_dummy['EvT_fullquench'] - 5 * conditions_dummy['kBT_fullquench']
    stop = np.ceil(conditions_dummy['EgT_fullquench'] / EF_int) * EF_int + 5 * conditions_dummy['kBT_fullquench']
    EF_grid = np.arange(start, stop + EF_int, EF_int)  

    nn = EF_grid.size
    errs = np.zeros(nn)

    for i in range(nn):
        guess = EF_grid[i]
        errs[i] = fullquench_charge_bal(guess, conditions_dummy)

    # This finds the rising/falling edge where error changes sign
    sign_changes = np.diff(np.sign(errs))
    edge_index = np.where(sign_changes != 0)[0]

    if edge_index.size == 1:
        min_index = [edge_index[0], edge_index[0] + 1]  # two guesses that bracket the solution
    elif edge_index.size == 2:
        min_index = edge_index.tolist()
    else:
        raise RuntimeError("Something strange about charge balance error vs EF - solutions may not be valid")

    guess = EF_grid[min_index]
    return guess

# %%%% Plot the charge balance error function vs EF if desired:
# import matplotlib.pyplot as plt
# plt.figure()
# plt.plot(EF_grid, errs)
# plt.plot(EF_grid[min_index], errs[min_index], 'ro')  # plot the EF_guess
