# A large list of imports to the main calculation function - defect_equilibrium_dark_with_frozen. 

import numpy as np # imports the numpy database
from scipy.optimize import root_scalar # replaces fzero in matlab; optimizes a non-linear equ
from pyswarms.single.global_best import GlobalBestPSO
from Vectorize_Scalar_Function import Vectorize_Scalar_Function # vectorizes a scalar function in order to use pyswarms
from scipy.optimize import minimize # acts the same as fminsearch (when using the 'Nelder-Mead' method)

# The following are subroutines that equilibrium_dark_with_frozen uses in its calculation.
#   - Functions called with dummy names for conditions
from Calc_Method_EDwF import Calc_Method
from EF_Guess12_EDwF import EF_Guess12
from EF_Fixed_Mu_Guess34_EDwF import EF_Fixed_Mu_Guess34
from Fixed_Mu_Grid_Maker_EDwF import Fixed_Mu_Grid_Maker
from EF_Grid_Maker_EDwF import EF_Grid_Maker
#   - Functions called to count the number of things
from Charge_Balance12_EDwF import Charge_Balance12
from Charge_Balance34_EDwF import Charge_Balance34
from Carrier_Concentrations_EDwF import Carrier_Concentrations
from Total_Balance34_EDwF import Total_Balance34 
from Fixed_Element_Balance34_EDwF import Fixed_Element_Balance34
from Chargestate_Concentrations_EDwF import Chargestate_Concentrations
from Expand_Fixed_Mu_Vec_To_Full_Mu_Vec_EDwF import Expand_Fixed_Mu_Vec_To_Full_Mu_Vec
from dSvib_quantum_per_mode_EDwF import dSvib_quantum_per_mode
#   - Functions that MAY be needed to count the number of things
from Quantum_dSvib_EDwF import Quantum_dSvib
from Dirac_Delta_w0_dSvib_EDwF import Dirac_Delta_w0_dSvib