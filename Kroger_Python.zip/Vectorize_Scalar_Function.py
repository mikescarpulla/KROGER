# In python we must vectorize our functions in order to use pyswarms

import numpy as np

# This function takes a function that takes a 1D numpy array as input
#   and it produces a vectorized function compatible with pyswarms

def Vectorize_Scalar_Function(function): 
    # Wraps any scalar function to be used with pyswarms
    def Vectorize(X):
        return np.array([function(x) for x in X])
    return Vectorize