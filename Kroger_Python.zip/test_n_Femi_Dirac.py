import numpy as np
import matplotlib.pyplot as plt
from n_Fermi_Dirac import n_Fermi_Dirac

# Constants
kB = 8.61733e-5  # [eV/K]

# Function Call (Scalar Values)
Ef = 3.3  # [eV]
Ec = 2.0  # [eV]
T = 500  # [K]
eta = (Ef - Ec) / (kB * T)
Nc3D = 20
nFD, nBoltz = n_Fermi_Dirac(eta, Nc3D)
print(f"nFD: {nFD:.3f}")
print(f"nBoltz: {nBoltz:.3f}")

# Function Call (Vector Values)
Ef_vec = np.array([3.3, 3.4, 2.2, 5.5, 2.3])  # [eV]
Ec_vec = np.array([2.2, 3.2, 3.1, 4.0, 3.0])  # [eV]
T = 1000  # [K]
eta_vec = (Ef_vec - Ec_vec) / (kB * T)
nFD_vec, nBoltz_vec = n_Fermi_Dirac(eta_vec, Nc3D)
print("nFD:")
print(nFD_vec)
print("nBoltz:")
print(nBoltz_vec)

# Function Call (Range with Graphs)
T = 1000  # [K]
Ef_range = np.linspace(-0.2, 0.2, 500)  # [eV]
Ec_range = np.linspace(0, 0.3, 500)  # [eV]
eta_range = (Ef_range - Ec_range) / (kB * T)
nFD_range, nBoltz_range = n_Fermi_Dirac(eta_range, Nc3D)

# Plot results
plt.figure()
plt.plot(Ef_range, nFD_range, label="nFD")
plt.plot(Ef_range, nBoltz_range, label="nBoltz")
plt.title("Calculating Carrier Density (Python)")
plt.xlabel("Fermi Energy (Ef) [eV]")
plt.ylabel("Carrier Density [#/cm^3]")
plt.legend()
plt.grid(True)
plt.show()