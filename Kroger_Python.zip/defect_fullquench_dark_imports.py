# Built in imports
import numpy as np
from scipy.optimize import root_scalar
# User defined nested subroutine functions 
from FQ_EF_guess_DFD import FQ_EF_guess
from fullquench_charge_bal_DFD import fullquench_charge_bal
from fullquench_chargestate_concentrations_DFD import fullquench_chargestate_concentrations
from fullquench_carrier_concentrations_DFD import fullquench_carrier_concentrations