import numpy as np

def G0_GaO_gv(T, P_tot, X_i, P_units):
    """
    Gives the thermodynamic variables of GaO as a function of T, P based on:
    Matvei Zinkevich and Fritz Aldinger J. Am. Ceram. Soc., 87 [4] 683–91 (2004).

    T in K, P in atm or Torr (must specify with 'atm', 'Torr', etc.).
    G computed in kJ/mol, then converted to eV.
    T and P should be vectors.

    Parameters:
    - T: Temperature array (K)
    - P_tot: Total pressure array (same shape as T)
    - X_i: Mole fraction
    - P_units: Pressure units ('atm', 'Torr', etc.)

    Returns:
    - G0_GaO_gv: Gibbs free energy in eV per GaO molecule
    """

    # Constants
    q = 1.602176634e-19  # J/eV
    avo = 6.0221409e+23  # formula units/mol
    kB_eV = 8.617333262e-5  # Boltzmann constant in eV/K

    # Select reference pressure based on units
    if P_units == 'atm':
        P_ref = 1
    elif P_units == 'Torr':
        P_ref = 760
    elif P_units == 'Bar':
        P_ref = 1
    elif P_units == 'Pa':
        P_ref = 1e5
    else:
        raise ValueError('Units of pressure must be atm, Torr, Pa, or Bar unless the ln(P/Pref) term is changed')

    # Ensure T is a column vector (nT x 1)
    T = np.array(T).reshape(-1, 1)  
    nT = T.shape[0]

    # Ensure P_tot is a row vector (1 x nP)
    P_tot = np.array(P_tot).reshape(1, -1)
    nP = P_tot.shape[1]

    # Shape T and P_tot to both be 2D arrays so that all calculations are vectorized
    T = T * np.ones((1, nP))  # Expanding T to match P_tot
    P_tot = np.ones((nT, 1)) * P_tot  # Expanding P_tot to match T

    # Initialize G0_GaO_gv as a zero matrix
    G0_GaO_gv = np.zeros_like(T)

    # Define masks based on temperature ranges
    mask1 = (T > 0) & (T <= 800)   # 0 to 800K
    mask2 = (T > 800) & (T <= 1500)  # 800 to 1500K
    mask3 = (T > 1500) & (T <= 4000)  # 1500 to 4000K

    # Up to 800 K
    G0_GaO_gv += np.where(mask1, 
                           136904.191 - 22.25862 * T - 30.49045 * T * np.log(T) 
                           - 0.0048738965 * (T**2) - 2.51268E-7 * (T**3) + 57767.3 / T, 
                           0)

    # 800 to 1500 K
    G0_GaO_gv += np.where(mask2, 
                           137661.642 - 54.439509 * T - 25.24208 * T * np.log(T) 
                           - 0.01210693 * (T**2) + 1.273842E-6 * (T**3) + 207293.6 / T, 
                           0)

    # 1500 to 4000 K
    G0_GaO_gv += np.where(mask3, 
                           109485.47 + 175.498025 * T - 57.18317 * T * np.log(T) 
                           + 0.0036644975 * (T**2) - 1.63582983E-7 * (T**3) + 4743017 / T, 
                           0)

    # Convert units to eV per GaO
    G0_GaO_gv = G0_GaO_gv / (avo * q)  # eV/GaO molecule

    # Add in pressure and mole fraction adjustments  
    G0_GaO_gv += kB_eV * T * (np.log(P_tot / P_ref) + np.log(X_i))

    # Set any values that are zero due to masking to infinity for error indication
    G0_GaO_gv[G0_GaO_gv == 0] = np.inf

    return G0_GaO_gv
