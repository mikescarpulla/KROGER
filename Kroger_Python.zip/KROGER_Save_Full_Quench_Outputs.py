import numpy as np
import scipy.io
import pandas as pd
import global_data

# Reference the data structure to the global database
conditions = global_data.conditions
defects = global_data.defects
equilib_dark_sol = global_data.equilib_dark_sol
fullquench_dark_sol = global_data.fullquench_dark_sol

# %% Task Trange 2: quenching from the annealing temperatures from example 1  %%%%%%%%%%%%%%%
# %%% note this assumes equilib_dark_sol is still in memory - could also
# %%% add a line here to load a prior solution from a .mat file.

# these variables don't exist for quenching so set them to zero to keep the
# file format the same with the full equilibrium calc
fullquench_dark_sol['element_bal_err'] = np.zeros_like(fullquench_dark_sol['charge_bal_err'])
fullquench_dark_sol['tot_bal_err']     = np.zeros_like(fullquench_dark_sol['charge_bal_err'])
fullquench_dark_sol['mu']              = np.zeros_like(equilib_dark_sol['mu'])
EvT_fullquench_vec = conditions['EvT_fullquench'] * np.ones_like(fullquench_dark_sol['charge_bal_err'])
EcT_fullquench_vec = conditions['EcT_fullquench'] * np.ones_like(fullquench_dark_sol['charge_bal_err'])

# %%%%%%%%%%% save the outputs for quenching.  Yes some of these are the
# %%%%%%%%%%% same as computed for the equilibrium solution but for sake
# %%%%%%%%%%% of debugging/proofreading were just doing it here again
all_defects_out = np.column_stack((
    fullquench_dark_sol['T_equilibrium'],
    fullquench_dark_sol['charge_bal_err'],
    fullquench_dark_sol['element_bal_err'],
    fullquench_dark_sol['tot_bal_err'],
    fullquench_dark_sol['mu'],
    conditions['EvT_equilibrium'],
    conditions['EcT_equilibrium'],
    fullquench_dark_sol['EFn'],
    fullquench_dark_sol['EFp'],
    fullquench_dark_sol['Nd'],
    fullquench_dark_sol['Na'],
    fullquench_dark_sol['n'],
    fullquench_dark_sol['p'],
    fullquench_dark_sol['sth1'],
    fullquench_dark_sol['sth2'],
    fullquench_dark_sol['defects']
))
all_chargestates_out = np.column_stack((
    fullquench_dark_sol['T_equilibrium'],
    fullquench_dark_sol['charge_bal_err'],
    fullquench_dark_sol['element_bal_err'],
    fullquench_dark_sol['tot_bal_err'],
    fullquench_dark_sol['mu'],
    conditions['EvT_equilibrium'],
    conditions['EcT_equilibrium'],
    fullquench_dark_sol['EFn'],
    fullquench_dark_sol['EFp'],
    fullquench_dark_sol['Nd'],
    fullquench_dark_sol['Na'],
    fullquench_dark_sol['n'],
    fullquench_dark_sol['p'],
    fullquench_dark_sol['sth1'],
    fullquench_dark_sol['sth2'],
    fullquench_dark_sol['chargestates']
))

all_defect_headers = (
    ['T_equilibrium (K)', 'charge_bal_err', 'element_bal_err', 'tot_bal_err']
    + defects['mu_names_with_units']
    + ['Ev(T) (eV)', 'Ec(T) (eV)', 'Efn(eV)', 'Efp (eV)',
       'Nd (#/cm3)', 'Na (#/cm3)', 'n (#/cm3)', 'p (#/cm3)',
       'sth1 (#/cm3)', 'sth2 (#/cm3)']
    + defects['defect_names']
)
all_chargestate_headers = (
    ['T_equilibrium (K)', 'charge_bal_err', 'element_bal_err', 'tot_bal_err']
    + defects['mu_names_with_units']
    + ['Ev(T) (eV)', 'Ec(T) (eV)', 'Efn(eV)', 'Efp (eV)',
       'Nd (#/cm3)', 'Na (#/cm3)', 'n (#/cm3)', 'p (#/cm3)',
       'sth1 (#/cm3)', 'sth2 (#/cm3)']
    + defects['chargestate_names']
)

df_all_defects      = pd.DataFrame(all_defects_out,      columns=all_defect_headers)
df_all_chargestates = pd.DataFrame(all_chargestates_out, columns=all_chargestate_headers)

# throw out all the ones with insignificant concentrations and save
sig_defects_index      = np.where(np.max(fullquench_dark_sol['defects'],      axis=0) >= conditions['save_min'])[0]
sig_chargestates_index = np.where(np.max(fullquench_dark_sol['chargestates'], axis=0) >= conditions['save_min'])[0]

sig_defects_out = np.column_stack((
    fullquench_dark_sol['T_equilibrium'],
    fullquench_dark_sol['charge_bal_err'],
    fullquench_dark_sol['element_bal_err'],
    fullquench_dark_sol['tot_bal_err'],
    fullquench_dark_sol['mu'],
    conditions['EvT_equilibrium'],
    conditions['EcT_equilibrium'],
    fullquench_dark_sol['EFn'],
    fullquench_dark_sol['EFp'],
    fullquench_dark_sol['Nd'],
    fullquench_dark_sol['Na'],
    fullquench_dark_sol['n'],
    fullquench_dark_sol['p'],
    fullquench_dark_sol['sth1'],
    fullquench_dark_sol['sth2'],
    fullquench_dark_sol['defects'][:, sig_defects_index]
))
sig_chargestates_out = np.column_stack((
    fullquench_dark_sol['T_equilibrium'],
    fullquench_dark_sol['charge_bal_err'],
    fullquench_dark_sol['element_bal_err'],
    fullquench_dark_sol['tot_bal_err'],
    fullquench_dark_sol['mu'],
    conditions['EvT_equilibrium'],
    conditions['EcT_equilibrium'],
    fullquench_dark_sol['EFn'],
    fullquench_dark_sol['EFp'],
    fullquench_dark_sol['Nd'],
    fullquench_dark_sol['Na'],
    fullquench_dark_sol['n'],
    fullquench_dark_sol['p'],
    fullquench_dark_sol['sth1'],
    fullquench_dark_sol['sth2'],
    fullquench_dark_sol['chargestates'][:, sig_chargestates_index]
))

sig_defect_headers = (
    ['T_equilibrium (K)', 'charge_bal_err', 'element_bal_err', 'tot_bal_err']
    + defects['mu_names_with_units']
    + ['Ev(T) (eV)', 'Ec(T) (eV)', 'Efn(eV)', 'Efp (eV)',
       'Nd (#/cm3)', 'Na (#/cm3)', 'n (#/cm3)', 'p (#/cm3)',
       'sth1 (#/cm3)', 'sth2 (#/cm3)']
    + [defects['defect_names'][i] for i in sig_defects_index]
)
sig_chargestate_headers = (
    ['T_equilibrium (K)', 'charge_bal_err', 'element_bal_err', 'tot_bal_err']
    + defects['mu_names_with_units']
    + ['Ev(T) (eV)', 'Ec(T) (eV)', 'Efn(eV)', 'Efp (eV)',
       'Nd (#/cm3)', 'Na (#/cm3)', 'n (#/cm3)', 'p (#/cm3)',
       'sth1 (#/cm3)', 'sth2 (#/cm3)']
    + [defects['chargestate_names'][i] for i in sig_chargestates_index]
)

df_sig_defects      = pd.DataFrame(sig_defects_out,      columns=sig_defect_headers)
df_sig_chargestates = pd.DataFrame(sig_chargestates_out, columns=sig_chargestate_headers)

# write to a tab-delimited text file
if conditions['save_files_flag'] == 'All':
    df_all_defects.to_csv(
        conditions['save_pname'] + conditions['fullquench_save_fname'] + '_all_defects',
        sep='\t', index=False
    )
    df_all_chargestates.to_csv(
        conditions['save_pname'] + conditions['fullquench_save_fname'] + '_all_chargestates',
        sep='\t', index=False
    )
elif conditions['save_files_flag'] == 'Sig_Only':
    df_sig_defects.to_csv(
        conditions['save_pname'] + conditions['fullquench_save_fname'] + '_sig_defects',
        sep='\t', index=False
    )
    df_sig_chargestates.to_csv(
        conditions['save_pname'] + conditions['fullquench_save_fname'] + '_sig_chargestates',
        sep='\t', index=False
    )

print('Wrote full quench dark solution as text files')

# write the whole solution structure to a .mat file
scipy.io.savemat(
    conditions['save_pname'] + conditions['fullquench_save_fname'],
    {'fullquench_dark_sol': fullquench_dark_sol}
)
print('Wrote full quench dark solution to .mat file')

# clean up memory
del (
    all_defects_out, all_chargestates_out,
    df_all_defects, df_all_chargestates,
    sig_defects_index, sig_chargestates_index,
    sig_defects_out, sig_chargestates_out,
    df_sig_defects, df_sig_chargestates,
    EvT_fullquench_vec, EcT_fullquench_vec
)
