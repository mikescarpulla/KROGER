import numpy as np
from Charge_Balance34_EDwF import Charge_Balance34
from Fixed_Element_Balance34_EDwF import Fixed_Element_Balance34

def Total_Balance34(EF_fixed_mu_vec_dummy):
    """
    Constructs the objective function that is to be minimized (ideally zeroed out).
    Takes in the reduced EF_mu vector and returns a scalar total error:
    - The sum of the absolute charge balance error
    - And the sum of the absolute fixed element balance error.
    """

    # Optionally, you could use log10 here if you want error on a log scale:
    # tot_bal34 = np.log10(
    #     abs(Charge_Balance34(EF_fixed_mu_vec_dummy)) + 
    #     np.sum(np.abs(Fixed_Element_Balance34(EF_fixed_mu_vec_dummy)))
    # )

    tot_bal34 = abs(Charge_Balance34(EF_fixed_mu_vec_dummy)) + \
                np.sum(np.abs(Fixed_Element_Balance34(EF_fixed_mu_vec_dummy)))

    return tot_bal34
