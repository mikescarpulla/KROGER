import numpy as np
from Test_Funct import Test_Funct

########### Testing n_Fermi_Dirac ###############

# Import the function
'''
from n_Fermi_Dirac import Fermi_Dirac
from n_Fermi_Dirac import n_Fermi_Dirac 

# Test values
Ef = np.array([4.0, 5.0, 3.0]) # in eV
Ec = np.array([1.0, 2.0, 2.2]) # in eV
Kb = 8.617 * 10**(-5) # in eV/K
T = 1500 # in K
eta = (Ef - Ec)/(Kb*T) # unitless
Nc3D = 15

# Test function
nFD, nBoltz = n_Fermi_Dirac(eta, Nc3D)
print(nFD)
print(nBoltz)
'''

######################### G0_ZrO2_ls Function ##########################
'''
from G0_ZrO2_ls import G0_ZrO2_ls

# Variables
T = np.array([3000, 1000, 2000])  # Temperatures in Kelvin
P_tot = np.array([10, 20, 30])
P_partial = 3  # Partial pressure
P_units = 'Torr'  # Pressure units
X_i = P_partial / P_tot  # Mole fraction
print(X_i)

# Function Call
G0_ZrO2_ls_result = G0_ZrO2_ls(T, P_tot, X_i, P_units)

# Output result
print(G0_ZrO2_ls_result)
'''
######################### G0_ZrO2_gv Function ##########################
'''
from G0_ZrO2_gv import G0_ZrO2_gv

#T = np.array([3000, 1000, 2000])  # Temperatures in Kelvin
T = 300
#P_tot = np.array([10, 20, 30])
P_tot = 7
P_partial = 3  # Partial pressure
P_units = 'Torr'  # Pressure units
X_i = P_partial / P_tot  # Mole fraction
print(X_i)

# Function Call
G0_ZrO2_gv_result = G0_ZrO2_gv(T, P_tot, X_i, P_units)
print(G0_ZrO2_gv_result)
'''

######################### G0_TiO_ls Function ##########################
'''
from G0_TiO_ls import G0_TiO_ls

# Variables
T = np.array([3000, 1000, 2000])  # Temperatures in Kelvin
#T = 300
P_tot = np.array([10, 20, 30])
#P_tot = 7
P_partial = 3  # Partial pressure
P_units = 'atm'  # Pressure units
X_i = P_partial / P_tot  # Mole fraction
print(X_i)

# Function Call
G0_TiO_ls_result = G0_TiO_ls(T, P_tot, X_i, P_units)
print(G0_TiO_ls_result)
'''
######################### G0_TiO_gv Function ##########################
'''
from G0_TiO_gv import G0_TiO_gv

# Variables
#T = np.array([3000, 1000, 2000])  # Temperatures in Kelvin
T = 300
#P_tot = np.array([10, 20, 30])
P_tot = 7
P_partial = 3  # Partial pressure
P_units = 'Torr'  # Pressure units
X_i = P_partial / P_tot  # Mole fraction
print(X_i)

# Function Call
G0_TiO_gv_result = G0_TiO_gv(T, P_tot, X_i, P_units)
print(G0_TiO_gv_result)
'''

######################### G0_TiO2_ls Function ##########################
'''
from G0_TiO2_ls import G0_TiO2_ls

# Variables
T = np.array([3000, 1000, 2000])  # Temperatures in Kelvin
#T = 300
P_tot = np.array([10, 20, 30])
#P_tot = 7
P_partial = 3  # Partial pressure
P_units = 'Torr'  # Pressure units
X_i = P_partial / P_tot  # Mole fraction
print(X_i)

# Function Call
G0_TiO2_ls_result = G0_TiO2_ls(T, P_tot, X_i, P_units)
print(G0_TiO2_ls_result)
'''
######################### G0_TiO2_gv Function ##########################
'''
from G0_TiO2_gv import G0_TiO2_gv

# Variables
#T = np.array([3000, 1000, 2000])  # Temperatures in Kelvin
T = 300
#P_tot = np.array([10, 20, 30])
P_tot = 7
P_partial = 3  # Partial pressure
P_units = 'Torr'  # Pressure units
X_i = P_partial / P_tot  # Mole fraction
print(X_i)

# Function Call
G0_TiO2_gv_result = G0_TiO2_gv(T, P_tot, X_i, P_units)
print(G0_TiO2_gv_result)
'''
######################### G0_Ti2O3_ls Function ##########################
'''
from G0_Ti2O3_ls import G0_Ti2O3_ls

# Variables
T = np.array([3000, 1000, 2000])  # Temperatures in Kelvin
#T = 300
P_tot = np.array([10, 20, 30])
#P_tot = 7
P_partial = 3  # Partial pressure
P_units = 'Torr'  # Pressure units
X_i = P_partial / P_tot  # Mole fraction
print(X_i)

# Function Call
G0_Ti2O3_ls_result = G0_Ti2O3_ls(T, P_tot, X_i, P_units)
print(G0_Ti2O3_ls_result)
'''
######################### G0_SnO_ls Function ##########################
'''
from G0_SnO_ls import G0_SnO_ls

# Variables
#T = np.array([3000, 1000, 2000])  # Temperatures in Kelvin
#P_tot = np.array([10, 20, 30])
T = 300
P_tot = 7
P_partial = 3  # Partial pressure
P_units = 'Torr'  # Pressure units
X_i = P_partial / P_tot  # Mole fraction
print(X_i)

# Function Call
G0_SnO_ls_result = G0_SnO_ls(T, P_tot, X_i, P_units)
print(G0_SnO_ls_result)
'''
######################### G0_02_gv Function ##########################
'''
from G0_O2_gv import G0_O2_gv

funct = G0_O2_gv

# Function Call
Test_Funct(funct)
'''

######################### G0_Ga2O3_ls Function ##########################
'''
from G0_Ga2O3_ls import G0_Ga2O3_ls

funct = G0_Ga2O3_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_Ga_gv Function ##########################
'''
from G0_Ga_ls import G0_Ga_ls

funct = G0_Ga_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_Ga_ls Function ##########################
'''
from G0_Ga_gv import G0_Ga_gv

funct = G0_Ga_gv

# Function Call
Test_Funct(funct)
'''
######################### G0_SnO_gv Function ##########################
'''
from G0_SnO_gv import G0_SnO_gv

funct = G0_SnO_gv

# Function Call
Test_Funct(funct)
'''
######################### G0_SnO2_gv Function ##########################
'''
from G0_SnO2_gv import G0_SnO2_gv

funct = G0_SnO2_gv

# Function Call
Test_Funct(funct)
'''
######################### G0_SnO2_ls Function ##########################
'''
from G0_SnO2_ls import G0_SnO2_ls

funct = G0_SnO2_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_GaO_gv Function ##########################
'''
from G0_GaO_gv import G0_GaO_gv

funct = G0_GaO_gv

# Function Call
Test_Funct(funct)
'''
######################### G0_Ga2O_gv Function #########################
'''
from G0_SiO_gv import G0_SiO_gv

funct = G0_SiO_gv

# Function Call
Test_Funct(funct)
'''
######################### G0_Ga2O_gv Function #########################
'''
from G0_SiO2_ls import G0_SiO2_ls

funct = G0_SiO2_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_RhO_ls Function #########################
'''
from G0_RhO_ls import G0_RhO_ls

funct = G0_RhO_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_RhO_gv Function #########################
'''
from G0_RhO_gv import G0_RhO_gv

funct = G0_RhO_gv

# Function Call
Test_Funct(funct)
'''

######################### G0_RhO2_ls Function #########################
'''
from G0_RhO2_ls import G0_RhO2_ls

funct = G0_RhO2_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_RhO2_gv Function #########################
'''
from G0_RhO2_gv import G0_RhO2_gv

funct = G0_RhO2_gv

# Function Call
Test_Funct(funct)
'''
######################### G0_Rh_ls Function #########################
'''
from G0_Rh_ls import G0_Rh_ls

funct = G0_Rh_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_Rh2O_ls Function #########################
'''
from G0_Rh2O_ls import G0_Rh2O_ls

funct = G0_Rh2O_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_Rh2O3_ls Function #########################
'''
from G0_Rh2O3_ls import G0_Rh2O3_ls

funct = G0_Rh2O3_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_PtO2_gv Function #########################
'''
from G0_PtO2_gv import G0_PtO2_gv

funct = G0_PtO2_gv

# Function Call
Test_Funct(funct)
'''
######################### G0_Pt_ls Function #########################
'''
from G0_Pt_ls import G0_Pt_ls

funct = G0_Pt_ls

# Function Call
Test_Funct(funct)
'''

######################### G0_MgO_ls Function #########################
'''
from G0_MgO_ls import G0_MgO_ls

funct = G0_MgO_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_MgO_gv Function #########################
'''
from G0_MgO_gv import G0_MgO_gv

funct = G0_MgO_gv

# Function Call
Test_Funct(funct)
'''
######################### G0_IrO3_gv Function #########################
'''
from G0_IrO3_gv import G0_IrO3_gv

funct = G0_IrO3_gv

# Function Call
Test_Funct(funct)
'''
######################### G0_IrO2_ls Function #########################
'''
from G0_IrO2_ls import G0_IrO2_ls

funct = G0_IrO2_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_IrO2_gv Function #########################
'''
from G0_IrO2_gv import G0_IrO2_gv

funct = G0_IrO2_gv

# Function Call
Test_Funct(funct)
'''
######################### G0_HfO2_ls Function #########################
'''
from G0_HfO2_ls import G0_HfO2_ls

funct = G0_HfO2_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_H2O_ls Function #########################
'''
from G0_H2O_ls import G0_H2O_ls

funct = G0_H2O_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_H2O_gv Function #########################
'''
from G0_H2O_gv import G0_H2O_gv

funct = G0_H2O_gv

# Function Call
Test_Funct(funct)
'''
######################### G0_GaO_gv Function #########################
'''
from G0_GaO_gv import G0_GaO_gv

funct = G0_GaO_gv

# Function Call
Test_Funct(funct)
'''
######################### G0_Fe2O3_ls Function #########################
'''
from G0_Fe2O3_ls import G0_Fe2O3_ls

funct = G0_Fe2O3_ls

# Function Call
Test_Funct(funct)
'''
######################### G0_CrO2_gv Function #########################

from G0_CrO2_gv import G0_CrO2_gv

funct = G0_CrO2_gv

# Function Call
Test_Funct(funct)