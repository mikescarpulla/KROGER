import numpy as np

def G0_Cd_gv(T, P_tot, X_i, P_units):
    """
    Calculate G0 for cadmium.

    Parameters:
    - T: Temperature in Kelvin (array-like).
    - P_tot: Total pressure (array-like).
    - X_i: Mole fraction (partial pressure/total pressure).
    - P_units: Units of pressure ('atm', 'Torr', 'Pa', 'Bar').

    Returns:
    - G0_Cd_gv: Gibbs free energy per Cd atom (in eV).
    """
    # Define constants
    q = 1.602176634e-19
    avo = 6.0221409e+23
    kB_eV = 8.617333262e-5

    # Select the P_ref based on the specified pressure units
    if P_units == 'atm':
        P_ref = 1
    elif P_units == 'Torr':
        P_ref = 760
    elif P_units == 'Bar':
        P_ref = 1
    elif P_units == 'Pa':
        P_ref = 1e5
    else:
        raise ValueError("Units of pressure must be 'atm', 'Torr', 'Pa', or 'Bar'.")

    # Reshape T and P_tot to ensure they are column and row vectors respectively
    T = np.array(T).reshape(-1, 1)  # Column vector
    P_tot = np.array(P_tot).reshape(1, -1)  # Row vector

    # Expand T and P_tot into 2D arrays for vectorized computations
    T_matrix = np.dot(T, np.ones_like(P_tot))  # T as a matrix
    P_tot_matrix = np.dot(np.ones_like(T), P_tot)  # P_tot as a matrix

    # Initialize G0_Cd_gv array
    G0_Cd_gv = np.zeros_like(T_matrix)

    # Define masks based on T ranges for the expressions for G0
    mask = (T_matrix > 298) & (T_matrix <= 1500)
    G0_Cd_gv = mask * (105599.101 - 28.4149645 * T_matrix - 20.7861120 * T_matrix * np.log(T_matrix))

    # Convert units to eV per Cd
    G0_Cd_gv = G0_Cd_gv / (avo * q)

    # Take P_tot and X_i into account
    G0_Cd_gv += kB_eV * T_matrix * (np.log(P_tot_matrix / P_ref) + np.log(X_i))

    # Set values of 0 or NaN in G0_Cd_gv to infinity
    G0_Cd_gv[G0_Cd_gv == 0] = np.inf
    G0_Cd_gv[np.isnan(G0_Cd_gv)] = np.inf

    return G0_Cd_gv

'''
View Data  Cd     Units:  T(K) P(atm) Energy(J) Quantity(mol) 
Name: Cadmium

  G(T) J/mol - 1 atm  

             G(T)                  G(T)                     G(T)                     T(K)        
____________ _____________________ ________________________ ________________________ ___________ 

S1         1 - 7083.46898          + 99.5061986     T       - 6.273908000E-03 T^ 2   298 - 594   
S1         1 - 6966.36000     T^-1 - 22.0442408     T ln(T)                          298 - 594   
S1         2 - 20064.9716          + 256.812234     T       + 8.832011496E-03 T^ 2   594 - 1500  
S1         2 + 1241289.61     T^-1 - 8.996036074E-07 T^ 3   - 45.1611543     T ln(T) 594 - 1500  
S1         3 - 9027.48876          + 148.205481     T       - 29.7064000     T ln(T) 1500 - 1600 
L1         4 - 955.024687          + 89.2092822     T       - 6.273908000E-03 T^ 2   298 - 400   
L1         4 - 6966.36000     T^-1 - 22.0442408     T ln(T)                          298 - 400   
L1         5 21716.8836            - 371.046869     T       - 0.115159917     T^ 2   400 - 594   
L1         5 - 1271815.45     T^-1 + 2.889978116E-05 T^ 3   + 53.1313898     T ln(T) 400 - 594   
L1         6 - 3252.30331          + 138.251107     T       - 29.7064000     T ln(T) 594 - 1600  
G1         7 105599.101            - 28.4149645     T       - 20.7861120     T ln(T) 298 - 1500  
____________ _____________________ ________________________ ________________________ ___________ 
'''