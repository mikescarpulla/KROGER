import numpy as np

def G0_Te3_gv(T, P_tot, X_i, P_units):
    """
    Calculate the Gibbs free energy for Te3 in eV per Ga2O molecule.
    
    Parameters:
    T : array-like
        Temperature in Kelvin.
    P_tot : array-like
        Total pressure.
    X_i : array-like
        Mole fraction.
    P_units : str
        Pressure units ("atm", "Torr", "Pa", "Bar").
    
    Returns:
    G0_Te3_gv : array-like
        Gibbs free energy values.
    """
    # Define constants
    q = 1.602176634e-19
    avo = 6.0221409e+23
    kB_eV = 8.617333262e-5
    
    # Select the Pref for specified units of pressure
    P_ref_dict = {'atm': 1, 'Torr': 760, 'Bar': 1, 'Pa': 1e5}
    
    if P_units not in P_ref_dict:
        raise ValueError("Units of pressure must be atm, Torr, Pa, or Bar")
    
    P_ref = P_ref_dict[P_units]
    
    # Ensure T and P_tot are numpy arrays and reshape for vectorized computation
    T = np.array(T).reshape(-1, 1)  # Column vector
    P_tot = np.array(P_tot).reshape(1, -1)  # Row vector
    
    # Create 2D meshgrid for vectorized operations
    T_matrix = np.tile(T, (1, P_tot.shape[1]))
    T_matrix = T_matrix.astype(float)  # Ensure floating-point division
    P_tot_matrix = np.tile(P_tot, (T.shape[0], 1))
    
    # Initialize Gibbs free energy array
    G0_Te3_gv = np.zeros_like(T_matrix,dtype=float)
    
    # Define mask based on temperature range
    mask = (T_matrix >= 298) & (T_matrix <= 1500)
    
    # Compute Gibbs free energy using given expression
    G0_Te3_gv += mask * (
        185431.713 + 53.6393822 * T_matrix - 2.010756493e-4 * T_matrix**2 
        + 71384.0826 * T_matrix**(-1) + 5.264657021e-8 * T_matrix**3 
        - 7.086788178e-12 * T_matrix**4 - 58.0151825 * T_matrix * np.log(T_matrix)
    )
    
    # Convert units to eV per Ga2O molecule
    G0_Te3_gv /= (avo * q)
    
    # Apply pressure and mole fraction corrections
    G0_Te3_gv += kB_eV * T_matrix * (np.log(P_tot_matrix / P_ref) + np.log(X_i))
    
    # Handle zero or NaN values by setting them to infinity
    G0_Te3_gv[G0_Te3_gv == 0] = np.inf
    G0_Te3_gv[np.isnan(G0_Te3_gv)] = np.inf
    
    return G0_Te3_gv

'''
View Data: Te3     
Units: T(K), P(atm), Energy(J), Quantity(mol)  

Name: Te3  

  G(T) J/mol - 1 atm  

              G(T)                     G(T)                   G(T)                   T(K)       
 ____________ ________________________ ______________________ ______________________ __________ 

 G1         1 185431.713               + 53.6393822     T     - 2.010756493E-04 T^ 2 298 - 1500 
 G1         1 + 71384.0826     T^-1    + 5.264657021E-08 T^ 3 - 7.086788178E-12 T^ 4 298 - 1500 
 G1         1 - 58.0151825     T ln(T)                                               298 - 1500 
 ____________ ________________________ ______________________ ______________________ __________ 
'''