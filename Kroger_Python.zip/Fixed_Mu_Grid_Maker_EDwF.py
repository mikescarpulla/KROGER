import numpy as np

def Fixed_Mu_Grid_Maker(FMGM_conditions):
    """
    This gets called only for methods 3 & 4, and gets called before
    anything else to create a list holding vectors of mu values for each
    frozen element (and no others). The fixed elements will be in order in
    the list, but not the same absolute element numbers. So if there are
    6 elements, and 1, 3, and 5 are frozen, this will have 3 entries:
    1st = for element 1, 2nd = for element 3, 3rd = for element 5.

    Future possible improvement:
    - Can just make holder a matrix directly rather than making a list here
      and turning it back into a vector when used in EF_Fixed_Mu_Guess34.
    - Could move this task into the script instead and include this object
      in the conditions variable sent. In that case, it would be better to
      have it as a list so some entries can be `None` rather than needing
      zeros (as would be required if this were a matrix).
    """

    # Create an empty list with enough entries to hold a vector of mu values for each fixed element
    fixed_mu_grids = [None] * FMGM_conditions['num_fixed_elements']

    counter = 0
    # Loop over the indices of frozen elements — only executes for frozen ones
    for i16 in FMGM_conditions['indices_of_fixed_elements']:
        # Decide up front to divide the range into a fixed number of increments
        mu_start = FMGM_conditions['fixed_elements_mu_ranges'][i16, 0]
        mu_end = FMGM_conditions['fixed_elements_mu_ranges'][i16, 1]
        npoints = FMGM_conditions['fixed_elements_mu_npoints']
        mu_inc = (mu_end - mu_start) / npoints

        # Create the grid for this frozen element
        fixed_mu_grids[counter] = np.arange(mu_start, mu_end + mu_inc/2, mu_inc)  # add a bit to ensure inclusive upper bound
        counter += 1

    return fixed_mu_grids
