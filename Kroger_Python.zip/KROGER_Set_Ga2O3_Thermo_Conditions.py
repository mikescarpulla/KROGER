# %% set Temperatures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# vector of T values at which to calculate for equilibrium
# start at the highest T you want and then work down in order to fully
# exploit the adaptive guessing.  Also, for fixed elements the major time
# is spent finding the first guess, the optimization is fast by comparison once you fix 2 or more elements.
# So it's worth doing a fine T grid for long calcuations so you dont have
# to ever do it over.

import numpy as np
import global_data
from Ga_O_Ga2O3_chem_potentials_from_conditions import Ga_O_Ga2O3_chem_potentials_from_conditions
from impurity_mu_limit_imposed_by_pO2 import impurity_mu_limit_imposed_by_pO2

# Reference the conditions and defects structure to the global database
conditions = global_data.conditions
defects = global_data.defects

# row vector of T in K at which to compute the equilibrium
conditions["T_equilibrium"] = np.arange(2100, 499, -100)  

conditions["num_T_equilibrium"] = len(conditions["T_equilibrium"])
conditions["kBT_equilibrium"] = conditions["kB"] * conditions["T_equilibrium"]

# set final T for full quenching from the T_equilibrium values above
conditions["T_fullquench"] = 300   # scalar temperature at which to compute the defect concentrations after quenching from T_equilibrium
conditions["kBT_fullquench"] = conditions["kB"] * conditions["T_fullquench"]

# logic checks on temperatures
if conditions["T_equilibrium"].ndim != 1:
    raise ValueError("T_equilibrium should be a row vector")
elif not np.isscalar(conditions["T_fullquench"]):
    raise ValueError("quench temperature has to be a scalar")

# %%% end setting temperatures  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

# %%%%% Determine how to set pressures, chemical potentials, concentrations.. of the elements

# %% set total pressure and units %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# set total pressure
# conditions.P_tot = 1e-4;   # total pressure in atm
conditions["P_tot"] = 1   # total pressure in atm
# conditions["P_tot"] = 0.025   # total pressure in atm

conditions["P_units"] = 'atm'  # p_ref set inside each G0 file

# conditions["P_tot"] = 30e-3
# conditions["P_units"] = 'Torr'

# %% Set up the elements to use in the model %%%%%%%%%%%%% 
# note: later below some elements or individual defects' concentrations can
# be fixed.  This overrides setting chemical potentials up here so it's OK
# to have entries here for elements fixed later.

# conditions["num_elements"] = 17

# if conditions.num_elements is not explicitly set, set it to the number of
# columns in defects.cs_dm
if "num_elements" not in conditions or conditions["num_elements"] is None:
    cs_dm_array = np.array(defects["cs_dm"]) # convert the defect["cs_dm"] from a list to an array
    conditions["num_elements"] = cs_dm_array.shape[1]

# %% Set the scenario used to determine the chemical potential of the host material.
# %%% different options for setting the host material's chemical potentials according to equilibrium equations or other

# for T-independent mu conditions (set one mu like mu=0 for rich/poor conditions)
# conditions["mu_Ga2O3"] = -10.22        # formation energy of Ga2O3 in eV/FU from Joel

conditions["mu_conditions_flag"] = 'pO2-variable'   # equilibrium with pO2 set to arbitrary value.  you must also set pO2.
# conditions["mu_conditions_flag"] = 'O-rich'
# conditions["mu_conditions_flag"] = 'Ga-rich'
# conditions["mu_conditions_flag"] = 'O2-1atm'       # pure O2 gas at 1 atm
# conditions["mu_conditions_flag"] = 'air-1atm'      # 1 atm of 80/20 N2/O2
# conditions["mu_conditions_flag"] = 'pGa_vap-variable'   # equilibrium with pGa_vapor set to arbitrary value.  you must also set pGa_vap.
# conditions["mu_conditions_flag"] = 'Ga_equilib_vap_pressure'    # set pGa_vap to equilibrium vapor pressure of Ga over Ga
# conditions["mu_conditions_flag"] = 'Ga_ls-rich'    # use this to mean Ga2O3 in direct contact with pure Ga liq or solid
# conditions["mu_conditions_flag"] = 'pGa2O_vap-variable'
# conditions["mu_conditions_flag"] = 'pGaO_vap-variable'

# if using "pO2-variable", need to also set pO2
# conditions["pO2"] = 1
conditions["pO2"] = 0.2
# conditions["pO2"] = 0.02
# conditions["pO2"] = 0.2 * conditions["P_tot"]    # for MOCVD
# conditions["pO2"] = 1e-4
# conditions["pO2"] = 1e-6
# conditions["pO2"] = 1e-8

# if using "pGa_vap-variable", need to also set a value
# conditions["pGa_vap"] = 1e-4
# conditions["pGa_vap"] = 1e-8
# conditions["pGa_vap"] = 1e-10

# specify partial pressures of Ga2O or GaO
# conditions["pGa2O_vap"] = 1e-4
# conditions["pGaO_vap"] = 1e-4

if conditions["mu_conditions_flag"] == 'O2-1atm':  # equilibrium with O2 at pO2=ptot=1 atm. This overrides anything you set accidentally above.
    conditions["pO2"] = 1
    conditions["P_tot"] = 1

# %% end setting scenario for host material

# %% Set chemical potentials depending on the method for each element

# Set default that all elements have fixed value of mu that is
# very negative like -30 eV. Make a matrix with rows for each T and columns for each
# element (including matrix ones).
conditions["mu_constant_flag"] = np.ones(conditions["num_elements"])

# Initialize a flag for mu set by phase boundaries - this should be mutually
# exclusive with the constant mu flag above.
conditions["mu_from_2nd_phases_flag"] = np.zeros(conditions["num_elements"])  # set all to zero/False first then overwrite if needed

# Both of these options will overwrite entries in this variable initialized here -
# this is the one the actual calc uses (so don’t change its name unless doing it inside the main calc too)
conditions["muT_equilibrium"] = -30 * np.ones((conditions["num_T_equilibrium"], defects["numelements"]))

# %% Matrix elements: set mu values first (first 2 columns for a binary, first 3 for a ternary, etc)
''' # Edited this to get the same dimensions as matlab in python, we use np.squeeze to get the same behavior. 
mu_Ga, mu_O = Ga_O_Ga2O3_chem_potentials_from_conditions(conditions) #
conditions["muT_equilibrium"][:, 0] = mu_Ga  # these 3 lines not combined to keep it explicit that first 2 columns are Ga and O
conditions["muT_equilibrium"][:, 1] = mu_O
'''
mu_Ga, mu_O = Ga_O_Ga2O3_chem_potentials_from_conditions(conditions)
conditions["muT_equilibrium"][:, 0] = np.squeeze(mu_Ga)
conditions["muT_equilibrium"][:, 1] = np.squeeze(mu_O)


# %% Impurity elements
# Calculate the values of all elements' limiting mu values based on the conditions
# We use only some of them as needed - use them by overwriting the muT_equilibrium
# For Ga2O3, we are using limits based on oxygen, but other limits can also
# be calculated and imposed, sequentially even (O can exclude some ranges for some elements,
# Ga can exclude other ranges for some elements, ..)
impurity_mu_boundary_limits = impurity_mu_limit_imposed_by_pO2(
    conditions["T_equilibrium"], conditions["P_tot"], conditions["P_units"], mu_O
)
# Note this function’s output first column is the first impurity element

# Set either constant mu values, T-dependent mu values, or mu values from equilibrium with 2nd phases.
# Flip the flag values from 0/1 for fixed mu and mu from 2nd phases

# Example for setting Si to -4 for all T. The const mu flag is already 1 and from_2nd_phases flag = 0
# since this is how they're initialized, but explicitly set here for clarity:
# conditions["mu_constant_flag"][2] = 1
# conditions["mu_from_2nd_phases_flag"][2] = 0
# mu_Si = -4
# conditions["muT_equilibrium"][:, 2] = mu_Si * np.ones(conditions["num_T_equilibrium"])

# Example for setting H to value set by 2nd phase equilibrium based on mu_O
# H_mu_num = 4
# conditions["mu_from_2nd_phases_flag"][H_mu_num - 1] = 1
# conditions["mu_constant_flag"][H_mu_num - 1] = 0  # flip the other flag too
# conditions["muT_equilibrium"][:, H_mu_num - 1] = impurity_mu_boundary_limits[:, H_mu_num - 3]  
# # Use the right precomputed column. Column numbers for impurity_mu variable are smaller by 2 because first 2 columns are Ga and O

# mu_Sn set by 2nd phase equilibrium based on mu_O
# Sn_mu_num = 6
# conditions["mu_from_2nd_phases_flag"][Sn_mu_num - 1] = 1
# conditions["mu_constant_flag"][Sn_mu_num - 1] = 0  # flip the other flag too
# conditions["muT_equilibrium"][:, Sn_mu_num - 1] = impurity_mu_boundary_limits[:, Sn_mu_num - 3]  
# # Use the right precomputed column. Column numbers for impurity_mu variable are smaller by 2 because first 2 columns are Ga and O

# Logic checks
mu_set_exclusively_by_one_method_check = ((conditions["mu_constant_flag"] + conditions["mu_from_2nd_phases_flag"]) - 1) != 0
conditions["mu_set_flag"] = (conditions["mu_constant_flag"] + conditions["mu_from_2nd_phases_flag"]) > 0

if np.any(mu_set_exclusively_by_one_method_check):
    print(mu_set_exclusively_by_one_method_check)
    raise ValueError("mu for each element has to be set either as a constant or by a phase boundary. "
                     "The line above has a 1 in the position of the element causing the problem")

# %%%%%%% finished specifying all mu values for elements controlled by mu rather than total conc.

# %% Set elements with fixed concentrations and the target values %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# If an element is fixed, it means the chemical potential for that element
# is floated (rather than fixed) and optimized (along with Ef and those of
# any others fixed) to get the desired total number over all the defects
# containing that element. List any fixed elements by putting a 1 in its
# position in the vector conditions["fixed_conc_flag"].
# This is mutually exclusive with setting chem potential for the element

# Element order for reference:
# 1=Ga 2=O 3=Si 4=H 5=Fe 6=Sn 7=Cr 8=Ti 9=Ir 10=Mg 11=Ca 12=Zn 13=Co 14=Zr 15=Hf 16=Ta 17=Ge

# Initialize flag and value pair for elements set by total concentrations -
# since this is a more unusual option this supersedes any mu values set
# (mu values determined in the calc self consistently). This should be
# mutually exclusive with setting mu value flags though.
conditions["fixed_conc_flag"] = np.zeros(conditions["num_elements"])
conditions["fixed_conc_values"] = np.zeros(conditions["num_elements"])  # This will hold target values of elements

# Initialize holder for the ranges over which to search for mu for frozen elements.
# Convention for now is that this matrix should be the size for all the elements,
# not just the fixed ones. We specify ranges for all the elements.
# Since either a direct grid search or particle swarm is used to generate the first guess,
# there are HUGE time savings if you can narrow down this range manually first using
# a series of calcs with constant mu values to estimate mu for each element you want to freeze.
# Or you can brute force it and just wait forever...
conditions["fixed_elements_mu_ranges"] = np.zeros((conditions["num_elements"], 2))  # Right size for ALL the elements

# Example for fixing Si:
# conditions["fixed_conc_flag"][2] = 1          # fix Si concentration (index 3 in MATLAB = 2 in Python)
# conditions["mu_set_flag"][2] = 0              # flip the flag saying Si is set by mu
# conditions["fixed_conc_values"][2] = 5e16     # specify the value
# lo_mu_Si = -10  # set range to search for the unknown mu
# hi_mu_Si = -2
# conditions["fixed_elements_mu_ranges"][2, :] = [lo_mu_Si, hi_mu_Si]

# %% Loop over Si doping -
# Si_doping = [1e15, 1e16, 1e17, 1e18, 1e19]
# conditions["fixed_conc_flag"][2] = 1          # fix Si concentration
# conditions["mu_set_flag"][2] = 0              # flip the flag saying Si is set by mu
#
# for index in range(len(Si_doping)):
#     save_fname_root = f"Si_OMVPE_{Si_doping[index]}"
#     conditions_save_fname = save_fname_root + "_calculation_conditions"
#     equilib_save_fname = save_fname_root + "_equilib_dark_sol"
#     fullquench_save_fname = save_fname_root + "_fullquench_dark_sol"
#
#     conditions["fixed_conc_values"][2] = Si_doping[index]

# Example values
# conditions["fixed_conc_flag"][2] = 1    # fix Si
# conditions["mu_set_flag"][2] = 0
# conditions["fixed_conc_values"][2] = 1e17
# lo_mu_Si = -9
# hi_mu_Si = -6
# conditions["fixed_elements_mu_ranges"][2, :] = [lo_mu_Si, hi_mu_Si]

# conditions["fixed_conc_flag"][3] = 1    # fix H
# conditions["mu_set_flag"][3] = 0
# conditions["fixed_conc_values"][3] = 1e17
# # H is about -2 to -4 eV for 4.5e18 Sn and 1e17 H
# lo_mu_H = -4
# hi_mu_H = -2
# conditions["fixed_elements_mu_ranges"][3, :] = [lo_mu_H, hi_mu_H]

# conditions["fixed_conc_flag"][4] = 1    # fix Fe
# conditions["mu_set_flag"][4] = 0
# conditions["fixed_conc_values"][4] = 2.8e16
# # 1e16 to 1e17 Fe is about -6 to -5 eV with 2e18 Sn doping
# lo_mu_Fe = -7
# hi_mu_Fe = -4
# conditions["fixed_elements_mu_ranges"][4, :] = [lo_mu_Fe, hi_mu_Fe]

# Fix Sn
conditions["fixed_conc_flag"][5] = 1    # fix Sn (index 6 in MATLAB => 5 in Python)
conditions["mu_set_flag"][5] = 0        # flip the flag saying Sn is set by mu
conditions["fixed_conc_values"][5] = 4.5e18
# 2e18 Sn is about -5.5 eV at 2100K to -5 eV at 500 K
lo_mu_Sn = -6.5  # set range to search for the unknown mu
hi_mu_Sn = -3
conditions["fixed_elements_mu_ranges"][5, :] = [lo_mu_Sn, hi_mu_Sn]

# conditions["fixed_conc_flag"][6] = 1    # fix Cr
# conditions["mu_set_flag"][6] = 0
# conditions["fixed_conc_values"][6] = 1.9e16
# 1e16 Cr is about -8 to -9 for 500–2100 K
# lo_mu_Cr = -10
# hi_mu_Cr = -4
# conditions["fixed_elements_mu_ranges"][6, :] = [lo_mu_Cr, hi_mu_Cr]

# conditions["fixed_conc_flag"][7] = 1    # fix Ti at 1e16
# conditions["mu_set_flag"][7] = 0
# conditions["fixed_conc_values"][7] = 1e16
# 1e16 Ti
# lo_mu_Ti = -10
# hi_mu_Ti = -5
# conditions["fixed_elements_mu_ranges"][7, :] = [lo_mu_Ti, hi_mu_Ti]

# conditions["fixed_conc_flag"][8] = 1    # fix Ir at 1.7e17
# conditions["mu_set_flag"][8] = 0
# conditions["fixed_conc_values"][8] = 1.7e17
# lo_mu_Ir = -3
# hi_mu_Ir = -1.5
# conditions["fixed_elements_mu_ranges"][8, :] = [lo_mu_Ir, hi_mu_Ir]

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

# The if loop below implements a batch loop to make 8 scenarios, permuting Fe, Sn, Mg,
# and UID doping with f = 0.5, 0.75. "index" is the index variable used in
# overall for loop

# if index == 1 or index == 5:

#     # Sn KURAMATA 2016
#     conditions["fixed_conc_flag"][2] = 1    # fix Si
#     conditions["mu_set_flag"][2] = 0        # flip the flag saying Si is set by mu
#     conditions["fixed_conc_values"][2] = 2.0e17
#     conditions["fixed_conc_flag"][5] = 1    # fix Sn
#     conditions["mu_set_flag"][5] = 0
#     conditions["fixed_conc_values"][5] = 4.5e18
#     conditions["fixed_conc_flag"][4] = 1    # fix Fe
#     conditions["mu_set_flag"][4] = 0
#     conditions["fixed_conc_values"][4] = 6.4e16

# elif index == 2 or index == 6:

#     # Mg
#     conditions["fixed_conc_flag"][2] = 1    # fix Si
#     conditions["mu_set_flag"][2] = 0
#     conditions["fixed_conc_values"][2] = 2.3e17
#     # conditions["fixed_conc_flag"][5] = 1    # fix Sn
#     # conditions["mu_set_flag"][5] = 0
#     # conditions["fixed_conc_values"][5] = 6.3e15
#     # conditions["fixed_conc_flag"][4] = 1    # fix Fe
#     # conditions["mu_set_flag"][4] = 0
#     # conditions["fixed_conc_values"][4] = 3.0e16

# elif index == 3 or index == 7:

# Fe
# conditions["fixed_conc_flag"][2] = 1    # fix Si
# conditions["mu_set_flag"][2] = 0
# conditions["fixed_conc_values"][2] = 2.3e17
# conditions["fixed_conc_flag"][5] = 1    # fix Sn
# conditions["mu_set_flag"][5] = 0
# conditions["fixed_conc_values"][5] = 6.5e15
# conditions["fixed_conc_flag"][4] = 1    # fix Fe
# conditions["mu_set_flag"][4] = 0
# conditions["fixed_conc_values"][4] = 2.5e18

# elif index == 4 or index == 8:
#     # UID
#     conditions["fixed_conc_flag"][2] = 1    # fix Si
#     conditions["mu_set_flag"][2] = 0
#     conditions["fixed_conc_values"][2] = 2.3e17
#     conditions["fixed_conc_flag"][5] = 1    # fix Sn
#     conditions["mu_set_flag"][5] = 0
#     conditions["fixed_conc_values"][5] = 6.5e15
#     conditions["fixed_conc_flag"][4] = 1    # fix Fe
#     conditions["mu_set_flag"][4] = 0
#     conditions["fixed_conc_values"][4] = 3.0e16

# to do: add in ability to import T-dependent Ef and mu's from a prior simulation.
# Let's say you fixed 2 elements, got a good solution, and next want to freeze a 3rd one.
# The best place to start is that last solution then ramp up the fixed concentration on
# the new element from 0 to its target value.
# actually could make it automatically do this for multi-element problems —
# start with the largest target concentration element, then add the next as a perturbing one
# especially if it forms complexes with that first one, then go to the next element...

# Default is no elements fixed - catch if nothing entered
if "fixed_conc_flag" not in conditions or np.sum(conditions["fixed_conc_flag"]) == 0:
    conditions["fixed_conc_flag"] = np.zeros((defects["numelements"],), dtype=int)
elif "fixed_conc_values" not in conditions or np.sum(conditions["fixed_conc_values"]) == 0:
    conditions["fixed_conc_values"] = np.zeros((defects["numelements"],), dtype=float)

# If something is not fixed but by accident it has a target conc set,
# just set its target concentration to zero also, using the fixed elements vector as a mask
conditions["fixed_conc_values"] = (
    conditions["fixed_conc_values"] * conditions["fixed_conc_flag"]
)

# Find number of fixed elements and their indices
conditions["indices_of_fixed_elements"] = list(np.where(conditions["fixed_conc_flag"])[0])
conditions["num_fixed_elements"] = len(conditions["indices_of_fixed_elements"])

if conditions["num_fixed_elements"] != 0:
    for i in range(conditions["num_fixed_elements"]):
        msg = (
            "WARNING: Fixed concentration of element used for..."
            + defects["elementnames"][conditions["indices_of_fixed_elements"][i]]
            + "...Be sure you meant to do this."
        )
        print(msg)
else:
    print("No elements have fixed concentrations. Proceeding")

# we can use 'del' to remove unneeded variables
del (
    i,
    msg,
    impurity_mu_boundary_limits,
    mu_set_exclusively_by_one_method_check,
    # max_mu_range, start_kBT, fine_factor — uncomment if they exist in your context
)

# These may or may not have been used; if not, this will throw an error unless handled
for var_name in [
    "mu_Ga",
    "mu_O",
    "lo_mu_Ga",
    "hi_mu_Ga",
    "lo_mu_O",
    "hi_mu_O",
    "lo_mu_Si",
    "hi_mu_Si",
    "lo_mu_H",
    "hi_mu_H",
    "lo_mu_Fe",
    "hi_mu_Fe",
    "lo_mu_Sn",
    "hi_mu_Sn",
    "lo_mu_Cr",
    "hi_mu_Cr",
    "lo_mu_Ti",
    "hi_mu_Ti",
    "lo_mu_Ir",
    "hi_mu_Ir",
]:
    if var_name in locals():
        del locals()[var_name]

### End section on fixed elements ###################################################

# Logic checks on mu or concentrations set for each element
# Catch it if by accident the mu and defect conc are both set for any elements

neither_mu_nor_conc_flag = conditions["mu_set_flag"] * conditions["fixed_conc_flag"]
both_mu_and_conc_flag = (
    np.array(conditions["mu_set_flag"]) + np.array(conditions["fixed_conc_flag"]) == 0
)

if np.any(neither_mu_nor_conc_flag):
    print(neither_mu_nor_conc_flag)
    raise ValueError("Must set either the mu or concentration for each element.")
elif np.any(both_mu_and_conc_flag):
    print(both_mu_and_conc_flag)
    raise ValueError(
        "Must set either the mu or the concentration for each element, not both."
    )
elif conditions["muT_equilibrium"].shape[1] != conditions["num_elements"]:
    raise ValueError(
        "Number of columns in mu array not equal to number of elements declared"
    )
elif np.any(np.isinf(conditions["muT_equilibrium"])):
    raise ValueError(
        "Infinite mu detected - this happens when there is no model for G0 for the T requested for some substance(s)"
    )

# Clear temp flags
del both_mu_and_conc_flag, neither_mu_nor_conc_flag

### End handling matrix chemical potentials #########################################