import numpy as np

def Dirac_Delta_w0_dSvib(x_vec):
    """
    Computes the vibrational entropy per mode using a Dirac delta approximation
    to the phonon density of states. Frequencies near zero (x → 0) are excluded
    because the Bose-Einstein distribution diverges.

    Parameters:
        x_vec : array-like
            Array of x = ħω / kBT values (dimensionless)

    Returns:
        dSvib : float
            Total vibrational entropy contribution from all modes
    """

    x_vec = np.asarray(x_vec)

    # Avoid division by zero or very small x by masking out invalid entries
    x_vec = x_vec[x_vec > 1e-12]

    # Main calculation: vectorized version of the MATLAB expression
    exp_x = np.exp(x_vec)
    dSvib_vec = (
        (exp_x / (exp_x - 1)) * np.log((1 + 1 / np.tanh(x_vec / 2)) / 2)
        - (1 / (exp_x - 1)) * np.log(1 / (exp_x - 1))
    )

    dSvib = np.sum(dSvib_vec)
    return dSvib
