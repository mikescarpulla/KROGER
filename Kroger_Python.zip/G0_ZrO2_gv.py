import numpy as np

def G0_ZrO2_gv(T, P_tot, X_i, P_units):
    """
    This function gives the standard Gibbs energy G0 of a substance as a function of T, P_tot, and mole fraction.
    It uses a Showmate equation to compute G0 and converts units to eV/formula unit.
    T and P_tot can be vectors; the output will be a 2D array.
    T in K, P in atm, Torr etc (must put in string argument 'atm' or 'Torr' etc)
    Logical masks are used like step functions vs T, allowing the whole expression to be built up piecewise over the list of T values  
    For a gas/vapor or mechanical mixture of phases such as ideal solution, mu(T,Ptot,Xi) = {Go(T,Pref) from Showmate equation} + kBT[ln(Ptot/Pref) + ln(X_i)]
        the total Gibbs energy of a mixture is Gmixture = Sum(Xi*mu_i) . Note how you end up with the xlnx terms this way, giving the ideal entropy of mixing
    
    Handy preformated Showmate templates
    Go = mask1.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    Go = Go + mask2.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    Go = Go + mask3.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    Go = Go + mask4.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
    """

    # Define constants
    q = 1.602176634e-19  # Charge of an electron in Coulombs
    avo = 6.0221409e+23  # Avogadro's number
    kB_eV = 8.617333262e-5  # Boltzmann constant in eV/K

    # Select the reference pressure (P_ref) for specified units of pressure
    if P_units == 'atm':
        P_ref = 1
    elif P_units == 'Torr':
        P_ref = 760
    elif P_units == 'Bar':
        P_ref = 1
    elif P_units == 'Pa':
        P_ref = 1e5
    else:
        raise ValueError("Units of pressure must be 'atm', 'Torr', 'Pa', or 'Bar'.")

    # Ensure T and P_tot are column and row vectors, respectively
    T = np.array(T).reshape(-1, 1)  # Convert T to a column vector
    P_tot = np.array(P_tot).reshape(1, -1)  # Convert P_tot to a row vector

    # Create 2D arrays of T and P_tot for vectorized calculations
    T_matrix = T * np.ones_like(P_tot)
    P_tot_matrix = np.ones_like(T) * P_tot

    # Initialize G0_ZrO2_gv
    G0_ZrO2_gv = np.zeros_like(T_matrix)

    # Define mask for the gas/vapor phase based on T ranges
    mask1 = (T_matrix > 298) & (T_matrix <= 6000)

    # Calculate G0 for gas/vapor phase
    G0_ZrO2_gv = mask1 * (
        -309428.051
        + 124.420897 * T_matrix
        + 1196235.07 * T_matrix**(-1.0)
        + 7.18939396 * T_matrix**0.5
        - 64971632.0 * T_matrix**(-2.0)
        - 58.1863462 * T_matrix * np.log(T_matrix)
    )

    # Convert units to eV per Ga2O
    G0_ZrO2_gv = G0_ZrO2_gv / (avo * q)  # Convert to eV/Ga2O molecule

    # Account for P_tot and X_i
    G0_ZrO2_gv = G0_ZrO2_gv + kB_eV * T_matrix * (np.log(P_tot_matrix / P_ref) + np.log(X_i))

    # Set any zero values caused by masking to infinity
    G0_ZrO2_gv[G0_ZrO2_gv == 0] = np.inf

    return G0_ZrO2_gv

'''
%% for referecne, it's nice to copy the original data here in comments to allow proofreading.  For exaple this is the text file from FactSage for H2O.  
% % % 
% % % View Data  ZrO2     Units:  T(K) P(atm) Energy(J) Quantity(mol) 
% % % Name: zirconium dioxide
% % % 
% % %   G(T) J/mol - 1 atm  
% % % 
% % %              G(T)                   G(T)                     G(T)                     T(K)        
% % % ____________ ______________________ ________________________ ________________________ ___________ 
% % % 
% % % S1         1 - 1106167.26           + 652.588280     T       - 2337.90322     T^0.5   298 - 1478  
% % % S1         1 + 20068472.3     T^-2  - 94.6211600     T ln(T)                          298 - 1478  
% % % S1         2 - 1121304.04           + 454.989704     T       - 74.4752000     T ln(T) 1478 - 2950 
% % % S1         3 - 1160801.00           + 575.349131     T       - 87.8640000     T ln(T) 2950 - 3500 
% % % S2         4 - 1115350.77           + 450.968857     T       - 74.4752000     T ln(T) 298 - 2950  
% % % S2         5 - 1154847.73           + 571.328284     T       - 87.8640000     T ln(T) 2950 - 3500 
% % % S3         6 - 1104765.78           + 446.948857     T       - 74.4752000     T ln(T) 298 - 2950  
% % % S3         7 - 1144262.74           + 567.308284     T       - 87.8640000     T ln(T) 2950 - 3500 
% % % L1         8 - 1057215.65           + 537.807469     T       - 87.8640000     T ln(T) 298 - 3500  
% % % G1         9 - 309428.051           + 124.420897     T       + 1196235.07     T^-1    298 - 6000  
% % % G1         9 + 7.18939396     T^0.5 - 64971632.0     T^-2    - 58.1863462     T ln(T) 298 - 6000  
% % % ____________ ______________________ ________________________ ________________________ ___________ 
% % % 
'''