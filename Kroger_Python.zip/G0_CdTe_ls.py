import numpy as np

def G0_CdTe_ls(T, P_tot, X_i, P_units):
    # Define constants
    q = 1.602176634e-19
    avo = 6.0221409e+23
    kB_eV = 8.617333262e-5
    
    # Select Pref based on pressure units
    P_ref_dict = {'atm': 1, 'Torr': 760, 'Bar': 1, 'Pa': 1e5}
    if P_units not in P_ref_dict:
        raise ValueError("Units of pressure must be atm, Torr, Pa, or Bar")
    P_ref = P_ref_dict[P_units]
    
    # Ensure T and P_tot are numpy arrays
    T = np.atleast_1d(T).reshape(-1, 1)  # Column vector
    P_tot = np.atleast_1d(P_tot).reshape(1, -1)  # Row vector
    
    # Create matrices for vectorized operations
    T_mat = np.tile(T, (1, P_tot.shape[1]))
    P_tot_mat = np.tile(P_tot, (T.shape[0], 1))
    
    # Initialize Gibbs free energy arrays
    G0_CdTe_s = np.zeros_like(T_mat,dtype=float)
    G0_CdTe_l = np.zeros_like(T_mat,dtype=float)
    
    # Define masks for temperature ranges
    masks_s = [(T_mat >= 298) & (T_mat <= 723),
               (T_mat > 723) & (T_mat <= 833),
               (T_mat > 833) & (T_mat <= 1150),
               (T_mat > 1150) & (T_mat <= 2000)]
    
    masks_l = [(T_mat > 298) & (T_mat <= 400),
               (T_mat > 400) & (T_mat <= 594),
               (T_mat > 594) & (T_mat <= 626),
               (T_mat > 626) & (T_mat <= 723),
               (T_mat > 723) & (T_mat <= 1150),
               (T_mat > 1150) & (T_mat <= 2000)]
    
    # Gibbs energy calculations for solid phase
    G0_CdTe_s += masks_s[0] * (-114886.039 + 209.434630*T_mat - 9.089e-3*T_mat**2 - 44.635*T_mat*np.log(T_mat))
    G0_CdTe_s += masks_s[1] * (100923.919 - 2107.20451*T_mat - 0.21037*T_mat**2 - 24238450.0/T_mat + 1.612973333e-5*T_mat**3 + 289.783*T_mat*np.log(T_mat))
    G0_CdTe_s += masks_s[2] * (59805.1601 - 1443.24743*T_mat - 0.151105*T_mat**2 - 24238450.0/T_mat + 1.612973333e-5*T_mat**3 + 191.053*T_mat*np.log(T_mat))
    G0_CdTe_s += masks_s[3] * (-114193.112 + 206.039964*T_mat - 9.089e-3*T_mat**2 - 44.2496*T_mat*np.log(T_mat))
    
    # Gibbs energy calculations for liquid phase
    G0_CdTe_l += masks_l[0] * (-93325.7245 + 780.722169*T_mat + 0.215669452*T_mat**2 + 820961.290/T_mat - 9.420746e-5*T_mat**3 - 148.362261*T_mat*np.log(T_mat))
    G0_CdTe_l += masks_l[1] * (-70653.8162 + 320.466017*T_mat + 0.106783443*T_mat**2 - 443887.796/T_mat - 6.530767884e-5*T_mat**3 - 73.1866302*T_mat*np.log(T_mat))
    G0_CdTe_l += masks_l[2] * (-95623.0031 + 829.763994*T_mat + 0.221943360*T_mat**2 + 827927.650/T_mat - 9.420746e-5*T_mat**3 - 156.024420*T_mat*np.log(T_mat))
    G0_CdTe_l += masks_l[3] * (-3243831.54 + 46900.2366*T_mat + 7.097749*T_mat**2 + 258051100/T_mat - 1.3069278e-3*T_mat**3 - 7226.1154*T_mat*np.log(T_mat))
    G0_CdTe_l += masks_l[4] * (102258.578 - 1356.69279*T_mat - 0.142016*T_mat**2 - 24238450.0/T_mat + 1.612973333e-5*T_mat**3 + 173.0366*T_mat*np.log(T_mat))
    G0_CdTe_l += masks_l[5] * (-71739.6946 + 292.594604*T_mat - 62.266*T_mat*np.log(T_mat))
    
    # Select minimum Gibbs energy for phase selection
    G0_CdTe_ls = np.minimum(G0_CdTe_s, G0_CdTe_l)
    
    # Convert to eV per molecule
    G0_CdTe_ls /= (avo * q)
    
    # Incorporate pressure and composition effects
    G0_CdTe_ls += kB_eV * T_mat * np.log(X_i)
    
    # Replace zeros with infinity to indicate errors
    G0_CdTe_ls[G0_CdTe_ls == 0] = np.inf
    
    return G0_CdTe_ls

'''
View Data  CdTe     Units:  T(K) P(atm) Energy(J) Quantity(mol) 
Name: Cadmium Telluride

G(T) J/mol - 1 atm  

             G(T)                     G(T)                   G(T)                     T(K)        
____________ ________________________ ______________________ ________________________ ___________ 

S1         1 - 114886.039             + 209.434630     T     - 9.089000000E-03 T^ 2   298 - 723   
S1         1 - 44.6350000     T ln(T)                                                 298 - 723   
S1         2 100923.919               - 2107.20451     T     - 0.210370000     T^ 2   723 - 833   
S1         2 - 24238450.0     T^-1    + 1.612973333E-05 T^ 3 + 289.783000     T ln(T) 723 - 833   
S1         3 59805.1601               - 1443.24743     T     - 0.151105000     T^ 2   833 - 1150  
S1         3 - 24238450.0     T^-1    + 1.612973333E-05 T^ 3 + 191.053000     T ln(T) 833 - 1150  
S1         4 - 114193.112             + 206.039964     T     - 9.089000000E-03 T^ 2   1150 - 2000 
S1         4 - 44.2496000     T ln(T)                                                 1150 - 2000 
L1         5 - 93325.7245             + 780.722169     T     + 0.215669452     T^ 2   298 - 400   
L1         5 + 820961.290     T^-1    - 9.420746000E-05 T^ 3 - 148.362261     T ln(T) 298 - 400   
L1         6 - 70653.8162             + 320.466017     T     + 0.106783443     T^ 2   400 - 594   
L1         6 - 443887.796     T^-1    - 6.530767884E-05 T^ 3 - 73.1866302     T ln(T) 400 - 594   
L1         7 - 95623.0031             + 829.763994     T     + 0.221943360     T^ 2   594 - 626   
L1         7 + 827927.650     T^-1    - 9.420746000E-05 T^ 3 - 156.024420     T ln(T) 594 - 626   
L1         8 - 3243831.54             + 46900.2366     T     + 7.09774900     T^ 2    626 - 723   
L1         8 + 258051100.     T^-1    - 1.306927800E-03 T^ 3 - 7226.11540     T ln(T) 626 - 723   
L1         9 102258.578               - 1356.69279     T     - 0.142016000     T^ 2   723 - 1150  
L1         9 - 24238450.0     T^-1    + 1.612973333E-05 T^ 3 + 173.036600     T ln(T) 723 - 1150  
L1        10 - 71739.6946             + 292.594604     T     - 62.2660000     T ln(T) 1150 - 1600 
____________ ________________________ ______________________ ________________________ ___________ 
'''