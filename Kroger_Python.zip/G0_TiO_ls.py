import numpy as np

def G0_TiO_ls(T, P_tot, X_i, P_units):
    """
    This function gives the standard Gibbs energy G0 of a substance as a function of T, P_tot, and mole fraction.
    It uses a Showmate equation to compute G0 and converts units to eV/formula unit.
    T and P_tot can be vectors; the output will be a 2D array.
    T in K, P in atm, Torr etc (must put in string argument 'atm' or 'Torr' etc)
    G computed in kJ/mol becasue tables are this way then we convert to eV/formula unit at the end
    Logical masks are used like step functions vs T, allowing the whole expression to be built up piecewise over the list of T values
    For a gas/vapor or mechanical mixture of phases such as ideal solution, mu(T,Ptot,Xi) = {Go(T,Pref) from Showmate equation} + kBT[ln(Ptot/Pref) + ln(X_i)]
        the total Gibbs energy of a mixture is Gmixture = Sum(Xi*mu_i) . Note how you end up with the xlnx terms this way, giving the ideal entropy of mixing

     Handy preformated Showmate templates
     Go = mask1.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
     Go = Go + mask2.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
     Go = Go + mask3.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));
     Go = Go + mask4.*(A + B*T.^(-2) + C*T.^(-1) + D*T.^(0.5) + E*T + F*T.^(2) + G*T.^(3) + H*T.^(4) + J*T.*log(T));

    """

    # Define constants
    q = 1.602176634e-19  # Charge of an electron in Coulombs
    avo = 6.0221409e+23  # Avogadro's number
    kB_eV = 8.617333262e-5  # Boltzmann constant in eV/K

    # Select the reference pressure (P_ref) for specified units of pressure
    if P_units == 'atm':
        P_ref = 1
    elif P_units == 'Torr':
        P_ref = 760
    elif P_units == 'Bar':
        P_ref = 1
    elif P_units == 'Pa':
        P_ref = 1e5
    else:
        raise ValueError("Units of pressure must be 'atm', 'Torr', 'Pa', or 'Bar'.")

    # Ensure T and P_tot are column and row vectors, respectively
    T = np.array(T).reshape(-1, 1)  # Convert T to a column vector
    P_tot = np.array(P_tot).reshape(1, -1)  # Convert P_tot to a row vector

    # Create 2D arrays of T and P_tot for vectorized calculations
    T_matrix = T * np.ones_like(P_tot)
    P_tot_matrix = np.ones_like(T) * P_tot

    # Initialize G0 matrices
    G0_TiO_s1 = np.zeros_like(T_matrix)
    G0_TiO_s2 = np.zeros_like(T_matrix)
    G0_TiO_liquid = np.zeros_like(T_matrix)
    G0_TiO_ls = np.zeros_like(T_matrix)

    # Define masks for temperature ranges
    mask1 = (T_matrix >= 298) & (T_matrix <= 2500)  # solid 1
    mask2 = (T_matrix >= 298) & (T_matrix <= 2500)  # solid 2
    mask3 = (T_matrix >= 298) & (T_matrix <= 1200)  # liquid
    mask4 = (T_matrix > 1200) & (T_matrix <= 4500)  # liquid continuation

    # solid1
    G0_TiO_s1 = mask1 * (
        -558169.702
        + 255.475182 * T_matrix
        - 8.898664224e-3 * T_matrix**2
        + 327010.589 * T_matrix**(-1.0)
        + 1.105968351e-8 * T_matrix**3
        - 41.9944927 * T_matrix * np.log(T_matrix)
    )

    # solid2
    G0_TiO_s2 = mask2 * (
        -553971.140
        + 252.162502 * T_matrix
        - 8.899251973e-3 * T_matrix**2
        + 327074.648 * T_matrix**(-1.0)
        + 1.121961627e-8 * T_matrix**3
        - 41.9953178 * T_matrix * np.log(T_matrix)
    )

    # liquid
    G0_TiO_liquid = mask3 * (
        -509468.783
        + 230.218069 * T_matrix
        - 8.858076521e-3 * T_matrix**2
        + 326982.846 * T_matrix**(-1.0)
        - 42.0139010 * T_matrix * np.log(T_matrix)
    )
    G0_TiO_liquid += mask4 * (
        -526084.300
        + 410.418030 * T_matrix
        - 66.9440000 * T_matrix * np.log(T_matrix)
    )

    # Choose the minimum G0, automatically selecting the correct phase
    G0_TiO_ls = np.min(np.stack([G0_TiO_s1, G0_TiO_s2, G0_TiO_liquid], axis=2), axis=2)

    # Convert units to eV per TiO
    G0_TiO_ls = G0_TiO_ls / (avo * q)  # Convert to eV/TiO molecule

    # Account for P_tot and X_i
    G0_TiO_ls = G0_TiO_ls + kB_eV * T_matrix * np.log(X_i)

    # Set any zero values caused by masking to infinity
    G0_TiO_ls[G0_TiO_ls == 0] = np.inf

    return G0_TiO_ls

'''
%% for referecne, it's nice to copy the original data here in comments to allow proofreading.  For exaple this is the text file from FactSage for H2O.  
% % % 
% % % View Data  TiO     Units:  T(K) P(atm) Energy(J) Quantity(mol) 
% % % Name: Titanium Oxide
% % % 
% % %   G(T) J/mol - 1 atm  
% % % 
% % %              G(T)                     G(T)                     G(T)                     T(K)        
% % % ____________ ________________________ ________________________ ________________________ ___________ 
% % % 
% % % S1         1 - 558169.702             + 255.475182     T       - 8.898664224E-03 T^ 2   298 - 2500  
% % % S1         1 + 327010.589     T^-1    + 1.105968351E-08 T^ 3   - 41.9944927     T ln(T) 298 - 2500  
% % % S1         2 - 565010.826             + 431.292509     T       - 66.9440000     T ln(T) 2500 - 2501 
% % % S2         3 - 553971.140             + 252.162502     T       - 8.899251973E-03 T^ 2   298 - 2500  
% % % S2         3 + 327074.648     T^-1    + 1.121961627E-08 T^ 3   - 41.9953178     T ln(T) 298 - 2500  
% % % S2         4 - 560811.474             + 427.972597     T       - 66.9440000     T ln(T) 2500 - 2501 
% % % L1         5 - 509468.783             + 230.218069     T       - 8.858076521E-03 T^ 2   298 - 1200  
% % % L1         5 + 326982.846     T^-1    - 42.0139010     T ln(T)                          298 - 1200  
% % % L1         6 - 526084.300             + 410.418030     T       - 66.9440000     T ln(T) 1200 - 4500 
% % % G1         7 78198.9955               + 125.670094     T       + 4.329207354E-03 T^ 2   298 - 1400  
% % % G1         7 - 423001.463     T^-1    - 3.836878386E-07 T^ 3   - 7615.16143     ln(T)   298 - 1400  
% % % G1         7 - 50.8736187     T ln(T)                                                   298 - 1400  
% % % G1         8 225627.296               - 728.339114     T       - 3.858717941E-03 T^ 2   1400 - 3700 
% % % G1         8 - 416191.214     T^-1    - 61603.3296     ln(T)   + 15770.0655     T^0.5   1400 - 3700 
% % % G1         8 + 34.3386587     T ln(T)                                                   1400 - 3700 
% % % G1         9 6685469.59               - 1273.18812     T       - 463897667.     T^-1    3700 - 6000 
% % % G1         9 - 1202306.56     ln(T)   + 86731.5508     T^0.5   + 56.8468382     T ln(T) 3700 - 6000 
% % % ____________ ________________________ ________________________ ________________________ ___________ 
% % % 
'''